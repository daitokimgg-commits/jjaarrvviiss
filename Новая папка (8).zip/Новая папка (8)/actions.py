"""Инструменты Джарвиса (Windows).

Каждая функция с декоратором @tool доступна сразу трём «пользователям»:
голосовым правилам, сценариям из config.yaml и нейросети (Ollama tool-calling).
Важное исправление: все горячие клавиши (Ctrl+V, Ctrl+F, Ctrl+A, Ctrl+K, Win+D, Enter, Esc)
отправляются через аппаратные виртуальные коды клавиш Windows API (VK_*), поэтому они
100% работают даже при включённой РУССКОЙ раскладке клавиатуры!
"""
import ast
import ctypes
import datetime
import glob
import inspect
import math
import operator
import os
import re
import shutil
import socket
import subprocess
import tempfile
import threading
import time
import webbrowser
import zipfile
from urllib.parse import quote_plus

import psutil
import pyautogui
import pyperclip
try:
    from rapidfuzz import fuzz, process
except Exception:
    import difflib
    class fuzz:
        @staticmethod
        def WRatio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def ratio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def partial_ratio(a, b):
            a, b = str(a), str(b)
            if a in b or b in a:
                return 100
            return int(difflib.SequenceMatcher(None, a, b).ratio() * 100)
    class process:
        @staticmethod
        def extractOne(q, choices, scorer=None, score_cutoff=0):
            best_c, best_s = None, -1
            for c in choices:
                s = (scorer or fuzz.WRatio)(q, c)
                if s > best_s:
                    best_c, best_s = c, s
            if best_c is not None and best_s >= score_cutoff:
                return (best_c, best_s, 0)
            return None

import database

try:                                   # DirectInput — для игр (необязательно)
    import pydirectinput
    pydirectinput.PAUSE = 0.02
except Exception:                      # noqa
    pydirectinput = None

pyautogui.FAILSAFE = True              # курсор в левый верхний угол = аварийная остановка
pyautogui.PAUSE = 0.04

CFG: dict = {}
STATE = {"game_input": False, "memory": "", "last_folder": "", "last_notepad": ""}
RUNTIME: dict = {}                     # сюда Brain кладёт run_scenario, speaker и т.п.
NOTIFY = lambda kind, text: print(f"[{kind}] {text}")   # переопределяется в Brain

# Активные таймеры: [{id, end_time, label, timer_obj}]
_TIMERS: list = []
_TIMERS_LOCK = threading.Lock()
_TIMER_SEQ = 0


def configure(cfg: dict):
    CFG.clear()
    CFG.update(cfg or {})
    STATE["game_input"] = bool(CFG.get("game_input", False))
    APPS.reset()


def trace(msg: str):
    """Служебное сообщение: видно в окне Джарвиса и в консоли, но не озвучивается."""
    NOTIFY("sys", msg)


# ───────────────────────── аппаратный ввод клавиш Windows (не зависит от RU/EN раскладки!) ─────────────────────────
_VK_MAP = {
    "backspace": 0x08, "tab": 0x09, "enter": 0x0D, "return": 0x0D,
    "shift": 0x10, "ctrl": 0x11, "control": 0x11, "alt": 0x12,
    "pause": 0x13, "capslock": 0x14, "esc": 0x1B, "escape": 0x1B,
    "space": 0x20, "pageup": 0x21, "pagedown": 0x22, "end": 0x23, "home": 0x24,
    "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
    "printscreen": 0x2C, "insert": 0x2D, "delete": 0x2E,
    "win": 0x5B, "lwin": 0x5B, "rwin": 0x5C,
    "numpad0": 0x60, "numpad1": 0x61, "numpad2": 0x62, "numpad3": 0x63, "numpad4": 0x64,
    "numpad5": 0x65, "numpad6": 0x66, "numpad7": 0x67, "numpad8": 0x68, "numpad9": 0x69,
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74, "f6": 0x75,
    "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
    "volumemute": 0xAD, "volumedown": 0xAE, "volumeup": 0xAF,
    "nexttrack": 0xB0, "prevtrack": 0xB1, "stop": 0xB2, "playpause": 0xB3,
    "+": 0xBB, "=": 0xBB, ",": 0xBC, "-": 0xBD, ".": 0xBE, "/": 0xBF, "`": 0xC0,
}
for _c in "0123456789":
    _VK_MAP[_c] = ord(_c)
for _c in "abcdefghijklmnopqrstuvwxyz":
    _VK_MAP[_c] = ord(_c.upper())


def _vk_code(key_name: str):
    return _VK_MAP.get((key_name or "").lower().strip())


def win_press(key: str):
    """Нажимает одну клавишу через аппаратный VK-код Windows (не зависит от русской раскладки)."""
    k = (key or "").lower().strip()
    vk = _vk_code(k)
    if os.name == "nt" and vk is not None:
        u = ctypes.windll.user32
        scan = u.MapVirtualKeyW(vk, 0)
        u.keybd_event(vk, scan, 0, 0)
        time.sleep(0.025)
        u.keybd_event(vk, scan, 2, 0)
    else:
        pyautogui.press(k)


def win_hotkey(*keys: str):
    """Нажимает сочетание клавиш (например 'ctrl', 'v' или 'ctrl', 'f') через аппаратные VK-коды Windows.
    В отличие от pyautogui.hotkey, 100% работает при включённой РУССКОЙ раскладке клавиатуры!"""
    clean_keys = [k.lower().strip() for k in keys if k and k.strip()]
    if not clean_keys:
        return
    vks = [_vk_code(k) for k in clean_keys]
    if os.name == "nt" and all(v is not None for v in vks):
        u = ctypes.windll.user32
        for vk in vks:
            scan = u.MapVirtualKeyW(vk, 0)
            u.keybd_event(vk, scan, 0, 0)
            time.sleep(0.02)
        time.sleep(0.03)
        for vk in reversed(vks):
            scan = u.MapVirtualKeyW(vk, 0)
            u.keybd_event(vk, scan, 2, 0)
            time.sleep(0.015)
    else:
        pyautogui.hotkey(*clean_keys)


def set_clipboard_unicode(text: str):
    """Надёжно кладёт Unicode-текст (русский/английский) в буфер обмена Windows."""
    s = str(text or "")
    try:
        pyperclip.copy(s)
    except Exception:
        pass
    if os.name == "nt":
        try:
            CF_UNICODETEXT = 13
            GMEM_MOVEABLE = 0x0002
            u32 = ctypes.windll.user32
            k32 = ctypes.windll.kernel32
            k32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
            k32.GlobalAlloc.restype = ctypes.c_void_p
            k32.GlobalLock.argtypes = [ctypes.c_void_p]
            k32.GlobalLock.restype = ctypes.c_void_p
            k32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            u32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]

            data = s.encode("utf-16-le") + b"\x00\x00"
            if u32.OpenClipboard(None):
                try:
                    u32.EmptyClipboard()
                    h_mem = k32.GlobalAlloc(GMEM_MOVEABLE, len(data))
                    if h_mem:
                        ptr = k32.GlobalLock(h_mem)
                        if ptr:
                            ctypes.memmove(ptr, data, len(data))
                            k32.GlobalUnlock(h_mem)
                            u32.SetClipboardData(CF_UNICODETEXT, h_mem)
                finally:
                    u32.CloseClipboard()
        except Exception:
            pass


# ───────────────────────── утилиты ─────────────────────────
def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower().replace("ё", "е")).strip()


_TR = dict(zip("абвгдежзийклмнопрстуфхцчшщъыьэюя",
               ["a", "b", "v", "g", "d", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p",
                "r", "s", "t", "u", "f", "h", "c", "ch", "sh", "sh", "", "y", "", "e", "u", "ya"]))


def translit(s: str) -> str:
    """'дискорд' -> 'diskord' — помогает находить английские названия программ."""
    return "".join(_TR.get(c, c) for c in (s or "").lower())


_NUM = {
    "ноль": 0, "нуль": 0,
    "один": 1, "одна": 1, "одну": 1, "одной": 1, "раз": 1,
    "два": 2, "две": 2, "двух": 2, "пару": 2, "пара": 2,
    "три": 3, "трех": 3, "трёх": 3,
    "четыре": 4, "четырех": 4, "четырёх": 4,
    "пять": 5, "пяти": 5,
    "шесть": 6, "шести": 6,
    "семь": 7, "семи": 7,
    "восемь": 8, "восьми": 8,
    "девять": 9, "девяти": 9,
    "десять": 10, "десяти": 10,
    "одиннадцать": 11, "двенадцать": 12, "тринадцать": 13, "четырнадцать": 14,
    "пятнадцать": 15, "пятнадцати": 15, "шестнадцать": 16, "семнадцать": 17,
    "восемнадцать": 18, "девятнадцать": 19,
    "двадцать": 20, "двадцати": 20,
    "тридцать": 30, "тридцати": 30,
    "сорок": 40, "сорока": 40,
    "пятьдесят": 50, "пятидесяти": 50, "полтинник": 50,
    "шестьдесят": 60, "шестидесяти": 60,
    "семьдесят": 70, "семидесяти": 70,
    "восемьдесят": 80, "восьмидесяти": 80,
    "девяносто": 90, "девяноста": 90,
    "сто": 100, "ста": 100, "сотку": 100,
    "двести": 200, "триста": 300, "четыреста": 400, "пятьсот": 500,
    "шестьсот": 600, "семьсот": 700, "восемьсот": 800, "девятьсот": 900,
    "тысяча": 1000, "тысячу": 1000,
}


def parse_number(text: str):
    """'пятьдесят пять' / '55' -> 55. Нет числа -> None."""
    if text is None:
        return None
    s = normalize(str(text))
    m = re.search(r"-?\d+", s)
    if m:
        return int(m.group())
    total, found = 0, False
    for w in re.findall(r"[а-яa-z0-9]+", s):
        if w in _NUM:
            total += _NUM[w]
            found = True
    return total if found else None


def parse_duration_seconds(text: str):
    """Парсит длительность из фразы: '5 минут 30 секунд', 'полчаса', '10 сек', '2 часа' -> секунды."""
    s = normalize(text)
    if "полчаса" in s or "пол часа" in s:
        return 1800
    if "полминуты" in s or "пол минуты" in s:
        return 30
    total = 0
    found = False
    words = s.split()
    out_words = []
    acc = 0
    has_acc = False
    for w in words:
        if w in _NUM:
            acc += _NUM[w]
            has_acc = True
        else:
            if has_acc:
                out_words.append(str(acc))
                acc = 0
                has_acc = False
            out_words.append(w)
    if has_acc:
        out_words.append(str(acc))
    s_norm = " ".join(out_words)

    for m in re.finditer(r"(\d+)\s*(час(?:а|ов)?|ч|мин(?:ут(?:ы|у)?)?|м|сек(?:унд(?:ы|у)?)?|с)\b", s_norm):
        val = int(m.group(1))
        unit = m.group(2)
        if unit.startswith("ч"):
            total += val * 3600
        elif unit.startswith("м"):
            total += val * 60
        else:
            total += val
        found = True

    if found:
        return total

    if re.search(r"\bчас\b", s_norm):
        return 3600
    if re.search(r"\bминут[уы]?\b", s_norm):
        return 60

    n = parse_number(s_norm)
    if n is not None and n > 0:
        if "мин" in s_norm:
            return n * 60
        if "час" in s_norm:
            return n * 3600
        if "сек" in s_norm:
            return n
        return n * 60 if n <= 15 else n
    return None


def _safety(flag: str, default=True):
    return (CFG.get("safety") or {}).get(flag, default)


def _lvl(flag, cond=None):
    """Уровень подтверждения: 'confirm', если включено в config.yaml safety.<flag> и выполнено условие."""
    def f(args):
        if not _safety(flag):
            return "safe"
        return "confirm" if (cond is None or cond(args)) else "safe"
    return f


# ───────────────────────── реестр инструментов ─────────────────────────
REGISTRY: dict = {}


def tool(desc: str, level="safe", **param_docs):
    """Регистрирует функцию как инструмент. Схема для нейросети строится по сигнатуре функции."""
    def deco(fn):
        props, req = {}, []
        for pname, p in inspect.signature(fn).parameters.items():
            t = {str: "string", int: "integer", float: "number", bool: "boolean"}.get(p.annotation, "string")
            props[pname] = {"type": t, "description": param_docs.get(pname, pname)}
            if p.default is inspect.Parameter.empty:
                req.append(pname)
        REGISTRY[fn.__name__] = {
            "fn": fn, "level": level, "desc": desc,
            "schema": {"type": "function", "function": {
                "name": fn.__name__, "description": desc,
                "parameters": {"type": "object", "properties": props, "required": req}}},
        }
        return fn
    return deco


def coerce_args(fn, args: dict) -> dict:
    """Нейросеть иногда присылает числа строками — приводим типы по сигнатуре."""
    sig, out = inspect.signature(fn), {}
    for k, v in (args or {}).items():
        p = sig.parameters.get(k)
        if p is None:
            continue
        try:
            if p.annotation is int:
                if isinstance(v, str) and not re.search(r"-?\d+", v):
                    pn = parse_number(v)
                    v = pn if pn is not None else int(float(v))
                else:
                    v = int(float(v))
            elif p.annotation is float:
                v = float(str(v).replace(",", "."))
            elif p.annotation is bool:
                v = v if isinstance(v, bool) else str(v).strip().lower() in ("1", "true", "yes", "да", "вкл", "on")
            elif p.annotation is str:
                v = str(v)
        except (TypeError, ValueError):
            raise ValueError(f"параметр {k}: неверное значение {v!r}")
        out[k] = v
    return out


def tool_level(name: str, args: dict) -> str:
    lvl = REGISTRY[name]["level"]
    return lvl(args or {}) if callable(lvl) else lvl


# ───────────────────────── защита ─────────────────────────
_SHELL_BLOCK = [
    r"\bformat(\.com)?\s+[a-z]:", r"\bdiskpart\b", r"\bbcdedit\b", r"\bvssadmin\b.*delete",
    r"\bcipher\s+/w", r"\breg(\.exe)?\s+delete", r"\bdel\b.*\s/[sfq]\b", r"\b(rd|rmdir)\b.*\s/s\b",
    r"remove-item.*-recurse", r"\brm\s+-[a-z]*r", r"format-volume|clear-disk|initialize-disk|remove-partition",
    r"\bnet\s+user\b.*/(add|delete)", r"\bsc(\.exe)?\s+delete\b", r"\bwmic\b.*\bdelete\b",
    r"powershell.*\s-enc(odedcommand)?\b", r"\biex\b|invoke-expression|downloadstring|\|\s*(sh|bash|iex)\b",
]


def _protected(path: str) -> bool:
    p = os.path.abspath(path).rstrip("\\/").lower()
    for k in ("SystemRoot", "ProgramFiles", "ProgramFiles(x86)", "ProgramData"):
        r = os.environ.get(k, "").lower().rstrip("\\/")
        if r and (p == r or p.startswith(r + os.sep)):
            return True
    if re.fullmatch(r"[a-z]:?", p) or p == os.path.expanduser("~").lower().rstrip("\\/"):
        return True
    return False


def _outside_roots(path: str) -> bool:
    roots = (CFG.get("safety") or {}).get("allow_roots") or []
    if not roots:
        return False
    p = os.path.abspath(path).lower()
    return not any(p.startswith(os.path.abspath(os.path.expandvars(os.path.expanduser(r))).lower()) for r in roots)


def blocked_reason(name: str, args: dict):
    """Причина, по которой действие не выполняется даже с подтверждением (или None)."""
    args = args or {}
    if name == "run_shell":
        cmd = str(args.get("command", "")).lower()
        extra = (CFG.get("safety") or {}).get("extra_blocked_shell") or []
        for pat in _SHELL_BLOCK + list(extra):
            if re.search(pat, cmd):
                return "эта команда слишком опасна для голосового управления — выполните её вручную"
    if name in ("write_file", "delete_path", "move_path", "make_dir"):
        for key in ("path", "src", "dst"):
            if args.get(key):
                real = resolve_path(str(args[key]))
                if _protected(real):
                    return f"папка {real} защищена"
                if _outside_roots(real):
                    return f"путь {real} вне разрешённых папок (safety.allow_roots)"
    if name == "copy_path" and args.get("dst"):
        real = resolve_path(str(args["dst"]))
        if _protected(real) or _outside_roots(real):
            return f"папка {real} защищена"
    return None


# ───────────────────────── пути, реальный Рабочий стол Windows и папки ─────────────────────────
def _expand(p: str) -> str:
    return os.path.abspath(os.path.expandvars(os.path.expanduser(p)))


def sanitize_win_name(name: str, default: str = "") -> str:
    """Очищает имя файла или папки от запрещённых в Windows символов (<>:"/\\|?*«») и точек на конце,
    предотвращая ошибку [WinError 123] при голосовом вводе со знаками препинания."""
    s = (name or "").strip()
    s = re.sub(r'[<>:"/\\|?*«»„“”`\x00-\x1f]+', "", s)
    s = re.sub(r"\s{2,}", " ", s).strip(" .,!?;:—-\'")
    return s or default


def _sanitize_rel_subpath(tail: str) -> str:
    if not tail:
        return ""
    parts = [sanitize_win_name(seg) for seg in re.split(r"[\\/]+", tail) if sanitize_win_name(seg)]
    return os.sep.join(parts)


def _get_windows_shell_folder(csidl: int, reg_name: str, fallback_rel: str) -> str:
    """Определяет 100% реальный путь к системной папке Windows (включая OneDrive Рабочий стол!)."""
    if os.name == "nt":
        # 1. Запрос к Windows Shell API (SHGetFolderPathW) — возвращает именно ту папку, которую рисует Explorer!
        try:
            buf = ctypes.create_unicode_buffer(260)
            res = ctypes.windll.shell32.SHGetFolderPathW(None, int(csidl), None, 0, buf)
            if res == 0 and buf.value and os.path.isdir(buf.value):
                return os.path.abspath(buf.value)
        except Exception:
            pass
        # 2. Проверка реестра User Shell Folders
        try:
            import winreg
            key_path = r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_READ) as k:
                val, _ = winreg.QueryValueEx(k, reg_name)
                if val:
                    exp = _expand(val)
                    if os.path.isdir(exp):
                        return exp
        except Exception:
            pass
        # 3. Если это Рабочий стол — проверяем папки OneDrive, если они активны
        if csidl == 0x0010:
            for od_env in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
                od_base = os.environ.get(od_env, "")
                if od_base and os.path.isdir(od_base):
                    for sub in ("Рабочий стол", "Desktop"):
                        cand = os.path.join(od_base, sub)
                        if os.path.isdir(cand):
                            return os.path.abspath(cand)
            home = os.path.expanduser("~")
            for sub in ("OneDrive\Рабочий стол", "OneDrive\Desktop", "Desktop", "Рабочий стол"):
                cand = os.path.join(home, sub)
                if os.path.isdir(cand):
                    return os.path.abspath(cand)

    fallback = _expand(fallback_rel)
    return fallback


def get_real_desktop_path() -> str:
    """Возвращает реальную папку Рабочего стола, отображаемую на экране пользователя."""
    desk = _get_windows_shell_folder(0x0010, "Desktop", "~/Desktop")
    os.makedirs(desk, exist_ok=True)
    return desk


def refresh_windows_desktop():
    """Мгновенно обновляет иконки на Рабочем столе Windows (SHChangeNotify), чтобы созданная папка или блокнот сразу появились на экране."""
    if os.name == "nt":
        try:
            ctypes.windll.shell32.SHChangeNotify(0x08000000, 0x0000, None, None)
        except Exception:
            pass


def resolve_path(p: str) -> str:
    """'загрузки' / 'рабочий стол\\Новая папка' / 'C:\\Users\\...' -> точный абсолютный путь."""
    p = (p or "").strip().strip('"«»')
    if not p:
        return _expand("~")

    # Если передана фраза "на рабочем столе\..." или "в папке рабочий стол\..."
    p = re.sub(r"^(?:на\s+рабочем\s+столе|в\s+папке\s+рабочий\s+стол|рабочем\s+столе)(?=$|[\\/])", "рабочий стол", p, flags=re.IGNORECASE)
    p = re.sub(r"^(?:в\s+загрузках|в\s+папке\s+загрузки)(?=$|[\\/])", "загрузки", p, flags=re.IGNORECASE)
    p = re.sub(r"^(?:в\s+документах|в\s+папке\s+документы)(?=$|[\\/])", "документы", p, flags=re.IGNORECASE)

    parts = re.split(r"[\\/]", p, maxsplit=1)
    head, tail = normalize(parts[0]), _sanitize_rel_subpath(parts[1] if len(parts) > 1 else "")

    # Системные папки определяем через реальный Windows Shell API (не зависит от чужого имени пользователя в config.yaml!)
    shell_map = {
        "рабочий стол": (0x0010, "Desktop", "~/Desktop"),
        "рабочем столе": (0x0010, "Desktop", "~/Desktop"),
        "десктоп":      (0x0010, "Desktop", "~/Desktop"),
        "desktop":      (0x0010, "Desktop", "~/Desktop"),
        "документы":    (0x0005, "Personal", "~/Documents"),
        "загрузки":     (0x0000, "{374DE290-123F-4565-9164-39C4925E467B}", "~/Downloads"),
        "картинки":     (0x0027, "My Pictures", "~/Pictures"),
        "изображения":  (0x0027, "My Pictures", "~/Pictures"),
        "музыка":       (0x000D, "My Music", "~/Music"),
        "видео":        (0x000E, "My Video", "~/Videos"),
    }
    if head in shell_map:
        csidl, reg_name, fb = shell_map[head]
        base_dir = get_real_desktop_path() if csidl == 0x0010 else _get_windows_shell_folder(csidl, reg_name, fb)
        return _expand(os.path.join(base_dir, tail)) if tail else base_dir

    folders = CFG.get("folders") or {}
    norm = {normalize(k): v for k, v in folders.items()}
    target = norm.get(head)
    if target is None and norm and not re.match(r"^[a-zA-Z]:", p):
        m = process.extractOne(head, list(norm), scorer=fuzz.WRatio, score_cutoff=85)
        if m:
            matched_k = m[0]
            if matched_k in shell_map:
                csidl, reg_name, fb = shell_map[matched_k]
                base_dir = get_real_desktop_path() if csidl == 0x0010 else _get_windows_shell_folder(csidl, reg_name, fb)
                return _expand(os.path.join(base_dir, tail)) if tail else base_dir
            target = norm[matched_k]
    if target is not None:
        base_expanded = os.path.expandvars(os.path.expanduser(target))
        return _expand(os.path.join(base_expanded, tail)) if tail else _expand(base_expanded)

    # Если указан относительный путь без диска — считаем относительно Рабочего стола!
    if not re.match(r"^[a-zA-Z]:", p) and not p.startswith(("~", "%", "\\", "/")):
        clean_rel = _sanitize_rel_subpath(p)
        return _expand(os.path.join(get_real_desktop_path(), clean_rel))
    return _expand(p)


# ───────────────────────── приложения ─────────────────────────
_KNOWN_FALLBACK_PATHS = {
    "телеграм": [
        r"%AppData%\Telegram Desktop\Telegram.exe",
        r"%LocalAppData%\Telegram Desktop\Telegram.exe",
        r"%ProgramFiles%\Telegram Desktop\Telegram.exe",
        r"%ProgramFiles(x86)%\Telegram Desktop\Telegram.exe",
    ],
    "дискорд": [
        r"%LocalAppData%\Discord\Update.exe",
    ],
    "стим": [
        r"C:\Program Files (x86)\Steam\steam.exe",
        r"C:\Program Files\Steam\steam.exe",
    ],
    "браузер": [
        r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
        r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe",
        r"%LocalAppData%\Google\Chrome\Application\chrome.exe",
    ],
    "эдж": [
        r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe",
        r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe",
    ],
    "код": [
        r"%LocalAppData%\Programs\Microsoft VS Code\Code.exe",
        r"%ProgramFiles%\Microsoft VS Code\Code.exe",
        r"%ProgramFiles(x86)%\Microsoft VS Code\Code.exe",
    ],
    "ворд": [
        r"%ProgramFiles%\Microsoft Office\root\Office16\WINWORD.EXE",
        r"%ProgramFiles(x86)%\Microsoft Office\root\Office16\WINWORD.EXE",
    ],
    "павер поинт": [
        r"%ProgramFiles%\Microsoft Office\root\Office16\POWERPNT.EXE",
        r"%ProgramFiles(x86)%\Microsoft Office\root\Office16\POWERPNT.EXE",
    ],
}


def _find_zapret_bat(configured_path: str = ""):
    """Находит батник обхода блокировок (ALT13 / general.bat), даже если версия папки обновилась."""
    if configured_path:
        exp = os.path.expandvars(os.path.expanduser(configured_path))
        if os.path.isfile(exp):
            return exp
    # Ищем на Рабочем столе и в Загрузках папки zapret*
    search_roots = [
        resolve_path("рабочий стол"),
        os.path.expanduser("~/Desktop"),
        os.path.expanduser("~/OneDrive/Desktop"),
        resolve_path("загрузки"),
    ]
    for root in search_roots:
        if not os.path.isdir(root):
            continue
        for pat in ("*zapret*/*ALT13*.bat", "*zapret*/*general*.bat", "*zapret*/*.bat"):
            hits = sorted(glob.glob(os.path.join(root, pat)))
            if hits:
                return hits[0]
    return None


class _Apps:
    def __init__(self):
        self.ready, self.lock = False, threading.Lock()
        self.apps, self.names, self.start = {}, {}, {}

    def load(self):
        with self.lock:
            if self.ready:
                return
            self.apps = CFG.get("apps") or {}
            self.names = {}
            for key, e in self.apps.items():
                for n in [key] + list((e or {}).get("aliases", [])):
                    self.names[normalize(n)] = key
            self.start = self._index_start_menu()
            self.ready = True

    def load_uwp_async(self):
        self.load()
        uwp = self._index_uwp()
        if uwp:
            with self.lock:
                for k, v in uwp.items():
                    self.start.setdefault(k, v)

    def reset(self):
        with self.lock:
            self.ready = False

    @staticmethod
    def _index_start_menu() -> dict:
        roots = [
            os.path.expandvars(r"%ProgramData%\Microsoft\Windows\Start Menu\Programs"),
            os.path.expandvars(r"%AppData%\Microsoft\Windows\Start Menu\Programs"),
            get_real_desktop_path(),
            os.path.expandvars(r"%PUBLIC%\Desktop"),
            os.path.expanduser("~/Desktop"),
        ]
        idx = {}
        for r in roots:
            if not r or not os.path.isdir(r):
                continue
            for dp, _, files in os.walk(r):
                for f in files:
                    fl = f.lower()
                    if fl.endswith((".lnk", ".url", ".exe", ".bat")):
                        stem = os.path.splitext(fl)[0].strip()
                        if stem:
                            idx.setdefault(stem, os.path.join(dp, f))
        # Индексируем также все программы из реестра Windows App Paths (Chrome, Yandex, Opera, OBS, Photoshop, Blender и т.д.)
        if os.name == "nt":
            try:
                import winreg
                for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                    try:
                        with winreg.OpenKey(hive, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths") as k:
                            sub_count = winreg.QueryInfoKey(k)[0]
                            for i in range(sub_count):
                                sub_name = winreg.EnumKey(k, i)
                                try:
                                    with winreg.OpenKey(k, sub_name) as sk:
                                        val, _ = winreg.QueryValueEx(sk, "")
                                        if val:
                                            clean_p = os.path.expandvars(str(val).strip().strip('"'))
                                            if os.path.isfile(clean_p):
                                                stem = os.path.splitext(sub_name.lower())[0]
                                                idx.setdefault(stem, clean_p)
                                except Exception:
                                    pass
                    except Exception:
                        pass
            except Exception:
                pass
        # Индексируем установленные игры Steam из steamapps/appmanifest_*.acf
        try:
            steam_roots = [
                r"C:\Program Files (x86)\Steam",
                r"C:\Program Files\Steam",
                r"D:\Steam",
                r"D:\SteamLibrary",
                r"C:\SteamLibrary",
                r"E:\SteamLibrary",
            ]
            for sr in steam_roots:
                sa = os.path.join(sr, "steamapps")
                if not os.path.isdir(sa):
                    continue
                for mf in glob.glob(os.path.join(sa, "appmanifest_*.acf")):
                    try:
                        with open(mf, "r", encoding="utf-8", errors="ignore") as f_acf:
                            txt_acf = f_acf.read(4096)
                        m_id = re.search(r'"appid"\s+"(\d+)"', txt_acf)
                        m_nm = re.search(r'"name"\s+"([^"]+)"', txt_acf)
                        if m_id and m_nm:
                            gname = m_nm.group(1).strip().lower()
                            idx.setdefault(gname, f"steam://rungameid/{m_id.group(1)}")
                    except Exception:
                        pass
        except Exception:
            pass
        return idx

    @staticmethod
    def _index_uwp() -> dict:
        if os.name != "nt":
            return {}
        import json
        try:
            ps = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8; "
                  "Get-StartApps | ConvertTo-Json -Compress")
            out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True,
                                 text=True, encoding="utf-8", timeout=6, creationflags=0x08000000).stdout
            data = json.loads(out) if out.strip() else []
        except Exception:
            return {}
        if isinstance(data, dict):
            data = [data]
        return {d["Name"].lower(): "shell:AppsFolder\\" + d["AppID"]
                for d in data if d.get("Name") and d.get("AppID")}

    def best_start(self, q: str):
        best = None
        for qq in {q, translit(q)}:
            if not self.start:
                break
            m = process.extractOne(qq, list(self.start), scorer=fuzz.WRatio, score_cutoff=78)
            if m and (best is None or m[1] > best[1]):
                best = m
        return best[0] if best else None

    def resolve(self, query: str):
        self.load()
        q = normalize(query)
        if self.names:
            if q in self.names:
                key = self.names[q]
                return ("cfg", key, self.apps[key] or {})
            m = process.extractOne(q, list(self.names), scorer=fuzz.WRatio, score_cutoff=80)
            if m:
                key = self.names[m[0]]
                return ("cfg", key, self.apps[key] or {})
        hit = self.best_start(q)
        return ("lnk", hit, self.start[hit]) if hit else None

    @staticmethod
    def is_running(process_name: str) -> bool:
        target = process_name.lower()
        return any((p.info.get("name") or "").lower() == target for p in psutil.process_iter(["name"]))

    @staticmethod
    def find_running_exe(process_name: str):
        """Если процесс уже запущен (например в трее), возвращает путь к его .exe."""
        if not process_name:
            return None
        target = process_name.lower()
        for p in psutil.process_iter(["name", "exe"]):
            try:
                if (p.info.get("name") or "").lower() == target and p.info.get("exe"):
                    return p.info["exe"]
            except (psutil.Error, OSError):
                continue
        return None

    def launch(self, res) -> str:
        kind, name, data = res
        if kind == "lnk":
            os.startfile(data)
            return name
        e = data or {}
        proc_check = e.get("process")
        if proc_check and self.is_running(proc_check):
            # Для фонового обхода блокировок (winws.exe) просто сообщаем, что он уже активен
            if e.get("unique") and normalize(name) == "обход":
                return name
            # Если приложение уже запущено — сначала пробуем вывести его окно на передний план!
            found_win = find_window(name, proc=proc_check, include_hidden=True)
            if found_win and focus_hwnd(found_win[0]):
                return name
            if e.get("unique"):
                return name

        # 1) Прямой URI (steam://, https://, roblox://)
        if "uri" in e:
            os.startfile(e["uri"])
            return name

        # 2) Путь к файлу или .bat (включая автопоиск батника обхода zapret)
        if "path" in e or normalize(name) == "обход":
            raw_path = e.get("path", "")
            path = os.path.expandvars(os.path.expanduser(raw_path)) if raw_path else ""
            if not os.path.exists(path) and normalize(name) == "обход":
                found_bat = _find_zapret_bat(raw_path)
                if found_bat:
                    path = found_bat
            if path and os.path.exists(path):
                workdir = os.path.dirname(path) or None
                # Для .bat/.cmd файлов используем ShellExecuteW (поддерживает UAC, рабочую папку и свернутый режим)
                if path.lower().endswith((".bat", ".cmd")) and os.name == "nt":
                    show_cmd = 7 if e.get("minimized") else 1
                    ctypes.windll.shell32.ShellExecuteW(None, "open", path, None, workdir, show_cmd)
                elif e.get("args"):
                    subprocess.Popen([path, *e["args"]], cwd=workdir, creationflags=0x08000000)
                else:
                    si = subprocess.STARTUPINFO()
                    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                    si.wShowWindow = 7 if e.get("minimized") else 1
                    si.cb = 68
                    subprocess.Popen([path], cwd=workdir, startupinfo=si, creationflags=0x08000000)
                return name

        # 3) Стандартные пути установки (VS Code, Word, PowerPoint, Telegram, Discord, Steam, Chrome)
        for cand in _KNOWN_FALLBACK_PATHS.get(normalize(name), []):
            expanded = os.path.expandvars(os.path.expanduser(cand))
            if os.path.isfile(expanded):
                args = e.get("args") or []
                subprocess.Popen([expanded, *args], cwd=os.path.dirname(expanded) or None, creationflags=0x08000000)
                return name

        # 4) Поиск в меню Пуск / Microsoft Store (надёжнее голого cmd)
        queries = ([e["find"]] if e.get("find") else []) + [name, *e.get("aliases", [])]
        for qn in queries:
            hit = self.best_start(normalize(qn))
            if hit:
                os.startfile(self.start[hit])
                return name

        # 5) Если процесс уже запущен в фоне/трее — запускаем его .exe
        proc_name = e.get("process")
        running_exe = self.find_running_exe(proc_name)
        if running_exe and os.path.isfile(running_exe):
            subprocess.Popen([running_exe], cwd=os.path.dirname(running_exe) or None, creationflags=0x08000000)
            return name

        # 6) Команда cmd (если задана)
        if "cmd" in e:
            subprocess.Popen(e["cmd"], shell=True)
            return name

        # 7) Для Telegram — fallback через URI протокол tg://
        if normalize(name) == "телеграм" or (proc_name and proc_name.lower() == "telegram.exe"):
            try:
                os.startfile("tg://")
                return name
            except Exception:
                pass

        raise RuntimeError(f"не нашёл, как запустить «{name}» — укажите path/uri в config.yaml")


APPS = _Apps()


def prewarm():
    """Мгновенно загружает список приложений из config.yaml и меню Пуск, а UWP-индекс строит в фоне без блокировки."""
    try:
        APPS.load()
    except Exception:
        pass
    threading.Thread(target=APPS.load_uwp_async, daemon=True).start()


_APP_CASE_FIXES = {
    "телеграма": "телеграм", "телеграме": "телеграм", "телегу": "телеграм",
    "дискорда": "дискорд", "дискорде": "дискорд",
    "стима": "стим", "стиме": "стим",
    "браузера": "браузер", "браузере": "браузер", "хрома": "хром",
    "блокнота": "блокнот", "калькулятора": "калькулятор", "проводника": "проводник",
    "ворда": "ворд", "кода": "код", "обхода": "обход",
}


def _clean_app_query(raw: str) -> str:
    s = (raw or "").strip().strip('"«»\'')
    s = re.sub(r"^(?:окно|программу|программа|приложение|утилиту|игру|сайт|папку)\s+", "", s, flags=re.IGNORECASE).strip()
    low = normalize(s)
    return _APP_CASE_FIXES.get(low, s)


# Популярные программы и системные утилиты Windows (работают даже без настройки config.yaml!)
_UNIVERSAL_APP_COMMANDS = {
    "блокнот": "notepad.exe",
    "notepad": "notepad.exe",
    "калькулятор": "calc.exe",
    "calc": "calc.exe",
    "проводник": "explorer.exe",
    "explorer": "explorer.exe",
    "пейнт": "mspaint.exe",
    "paint": "mspaint.exe",
    "диспетчер задач": "taskmgr.exe",
    "taskmgr": "taskmgr.exe",
    "командная строка": "cmd.exe",
    "cmd": "cmd.exe",
    "терминал": "wt.exe",
    "powershell": "powershell.exe",
    "параметры": "ms-settings:",
    "настройки": "ms-settings:",
    "настройки windows": "ms-settings:",
    "панель управления": "control.exe",
    "ножницы": "snippingtool.exe",
    "экранная клавиатура": "osk.exe",
    "редактор реестра": "regedit.exe",
    "обс": "obs64.exe",
    "obs": "obs64.exe",
    "obs studio": "obs64.exe",
    "яндекс браузер": r"%LocalAppData%\Yandex\YandexBrowser\Application\browser.exe",
    "яндекс": r"%LocalAppData%\Yandex\YandexBrowser\Application\browser.exe",
    "опера": r"%LocalAppData%\Programs\Opera\opera.exe",
    "opera": r"%LocalAppData%\Programs\Opera\opera.exe",
    "опера гх": r"%LocalAppData%\Programs\Opera GX\opera.exe",
    "opera gx": r"%LocalAppData%\Programs\Opera GX\opera.exe",
    "брейв": r"%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe",
    "brave": r"%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe",
    "хром": r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
    "chrome": r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
    "спотифай": r"%AppData%\Spotify\Spotify.exe",
    "spotify": r"%AppData%\Spotify\Spotify.exe",
    "эпик геймс": r"%ProgramFiles(x86)%\Epic Games\Launcher\Portal\Binaries\Win32\EpicGamesLauncher.exe",
    "epic games": r"%ProgramFiles(x86)%\Epic Games\Launcher\Portal\Binaries\Win32\EpicGamesLauncher.exe",
}


def _launch_single_path_or_uri(p: str) -> bool:
    """Безопасно открывает любой файл (.exe, .lnk, .bat, .url), папку или URI."""
    try:
        if p.startswith(("http://", "https://")):
            _open_url(p)
            return True
        if p.startswith(("steam://", "ms-settings:", "tg://", "discord://", "shell:")):
            if os.name == "nt":
                os.startfile(p)
            return True
        exp = os.path.expandvars(os.path.expanduser(p.strip().strip('"«»\'')))
        if os.path.exists(exp):
            if os.name == "nt":
                if exp.lower().endswith((".bat", ".cmd")):
                    ctypes.windll.shell32.ShellExecuteW(None, "open", exp, None, os.path.dirname(exp) or None, 1)
                elif exp.lower().endswith(".exe"):
                    subprocess.Popen([exp], cwd=os.path.dirname(exp) or None, creationflags=0x08000000)
                else:
                    os.startfile(exp)
            return True
    except Exception as e:
        trace(f"_launch_single_path_or_uri({p}): {e}")
    return False


@tool("Открыть любое приложение, игру (по названию, ярлыку или пути .exe), окно, сайт или папку.",
      name="Название программы, игры, сайта, папки или путь к .exe/.lnk (можно несколько через запятую или «и»)")
def open_app(name: str) -> str:
    raw_full = (name or "").strip().strip('"«»\'')
    if not raw_full:
        return "Что открыть?"

    # Поддержка открытия сразу НЕСКОЛЬКИХ приложений/сайтов в одной команде: «открой ютуб, вк и дискорд»
    if not os.path.exists(os.path.expandvars(os.path.expanduser(raw_full))):
        multi_parts = [
            p.strip() for p in re.split(r"\s*,\s*|\s+и\s+(?=(?:сайт\s+|приложение\s+|программу\s+|игру\s+)?[а-яА-ЯёЁa-zA-Z0-9_\-.:/\\]{2,})", raw_full)
            if p and p.strip()
        ]
        if len(multi_parts) > 1:
            results = [open_app(part) for part in multi_parts]
            return " ".join(results)

    raw = _clean_app_query(raw_full)
    if not raw:
        return "Что открыть?"

    # 1. Прямой путь к любому .exe, .lnk, .bat, .url или папке на ПК пользователя (даже если его нет в config.yaml!)
    if _launch_single_path_or_uri(raw_full) or _launch_single_path_or_uri(raw):
        return f"Открываю {os.path.basename(os.path.normpath(raw)) or raw}."

    # 2. Если это URL или домен сайта (например youtube.com, ozon.ru, https://...)
    if re.match(r"^https?://", raw, flags=re.IGNORECASE) or re.match(r"^[a-zA-Z0-9\-]+(\.[a-zA-Z0-9\-]+)+(/\S*)?$", raw):
        if not raw.lower().endswith((".exe", ".bat", ".cmd", ".lnk", ".url", ".txt", ".py")):
            return open_site(raw)

    qn = normalize(raw)

    # 3. Проверяем приложения из config.yaml и расширенного индекса (Пуск + Рабочий стол + Реестр App Paths + Steam)
    res = APPS.resolve(raw)
    if res:
        try:
            APPS.launch(res)
            return f"Открываю {res[1]}."
        except Exception as e:
            trace(f"open_app({raw}): {e}")

    # 4. Проверяем универсальный словарь популярных программ и системных утилит Windows
    if qn in _UNIVERSAL_APP_COMMANDS:
        cmd_target = _UNIVERSAL_APP_COMMANDS[qn]
        if _launch_single_path_or_uri(cmd_target):
            return f"Открываю {raw}."
        which_hit = shutil.which(cmd_target)
        if which_hit and _launch_single_path_or_uri(which_hit):
            return f"Открываю {raw}."
        if os.name == "nt":
            try:
                os.startfile(cmd_target)
                return f"Открываю {raw}."
            except Exception:
                pass

    # 5. Проверяем исполняемый файл через PATH / shutil.which (для любых установленных программ по имени .exe)
    for cand_exe in (raw, translit(raw), f"{raw}.exe", f"{translit(raw)}.exe"):
        w_path = shutil.which(cand_exe)
        if w_path and _launch_single_path_or_uri(w_path):
            return f"Открываю {raw}."

    # 6. Проверяем игры Steam из config.yaml
    steam_apps = CFG.get("steam_apps") or {}
    for skey, sinfo in steam_apps.items():
        saliases = [skey] + list((sinfo or {}).get("aliases", []))
        if qn in [normalize(a) for a in saliases]:
            return open_steam_game(raw)

    # 7. Проверяем сайты (из config.yaml + встроенный каталог 50+ популярных сайтов)
    url = resolve_site(raw, cutoff=78)
    if url:
        _open_url(url)
        return f"Открываю сайт {raw}."

    # 8. Проверяем папки из config.yaml или на Рабочем столе
    folders = CFG.get("folders") or {}
    if qn in {normalize(k) for k in folders}:
        return open_path(raw)
    desk_cand = os.path.join(get_real_desktop_path(), raw)
    if os.path.exists(desk_cand) and _launch_single_path_or_uri(desk_cand):
        return f"Открываю {raw} с Рабочего стола."

    # 9. Поиск .exe/.lnk в стандартных папках программ (Program Files, LocalAppData\Programs, Games)
    search_dirs = [
        os.path.expandvars(r"%LocalAppData%\Programs"),
        os.path.expandvars(r"%ProgramFiles%"),
        os.path.expandvars(r"%ProgramFiles(x86)%"),
        r"C:\Games",
        r"D:\Games",
    ]
    q_tokens = [tok for tok in re.split(r"\s+", qn) if len(tok) >= 2]
    q_tr_tokens = [translit(tok) for tok in q_tokens]
    for sdir in search_dirs:
        if not sdir or not os.path.isdir(sdir):
            continue
        try:
            for entry in os.listdir(sdir):
                el = entry.lower()
                if any(tok in el for tok in q_tokens + q_tr_tokens):
                    full_dir = os.path.join(sdir, entry)
                    if os.path.isdir(full_dir):
                        exes = glob.glob(os.path.join(full_dir, "*.exe")) + glob.glob(os.path.join(full_dir, "*", "*.exe"))
                        exes = [x for x in exes if not any(bad in os.path.basename(x).lower() for bad in ("unins", "crash", "update", "setup", "helper"))]
                        if exes and _launch_single_path_or_uri(exes[0]):
                            return f"Открываю {entry}."
        except Exception:
            pass

    # 10. Если окно с таким названием уже открыто — выводим его на передний план
    win_hit = find_window(raw, include_hidden=True)
    if win_hit and focus_hwnd(win_hit[0]):
        return f"Переключился на окно «{win_hit[1]}»."

    # 11. Интуитивный фоллбэк через Tesseract OCR: если эта кнопка/вкладка есть на экране — нажимаем на неё!
    try:
        import screen
        pos = screen.find_text(raw)
        if pos:
            x, y = int(pos[0]), int(pos[1])
            pyautogui.click(x, y)
            return f"Нажал на элемент экрана «{raw}» ({x}, {y})."
    except Exception:
        pass
    return f"Не нашёл приложение «{name}». Вы можете указать полный путь к .exe или выбрать файл через кнопку «📂 Выбрать .exe» в конструкторе сценариев."


@tool("Закрыть приложение или окно по названию.", name="Название программы")
def close_app(name: str) -> str:
    res = APPS.resolve(name)
    if res and res[0] == "cfg" and (res[2] or {}).get("process"):
        target, n = res[2]["process"].lower(), 0
        for p in psutil.process_iter(["name"]):
            if (p.info.get("name") or "").lower() == target:
                try:
                    p.terminate()
                    n += 1
                except psutil.Error:
                    pass
        if n:
            return f"Закрыл {res[1]}."
    found = find_window(name)
    if found:
        _u32().PostMessageW(found[0], 0x0010, 0, 0)   # WM_CLOSE
        return f"Закрыл окно «{found[1]}»."
    return f"Не смог закрыть «{name}»."


# ───────────────────────── звук, яркость, медиа ─────────────────────────
def _endpoint():
    from ctypes import POINTER, cast
    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
    try:
        import comtypes
        comtypes.CoInitialize()
    except Exception:
        pass
    dev = AudioUtilities.GetSpeakers()
    if hasattr(dev, "EndpointVolume"):
        return dev.EndpointVolume
    iface = dev.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    return cast(iface, POINTER(IAudioEndpointVolume))


def _volume_now() -> int:
    return round(_endpoint().GetMasterVolumeLevelScalar() * 100)


@tool("Установить громкость системы в процентах.", percent="Громкость от 0 до 100")
def set_volume(percent: int) -> str:
    p = max(0, min(100, int(percent)))
    try:
        _endpoint().SetMasterVolumeLevelScalar(p / 100, None)
    except Exception as e:
        return f"Не удалось изменить громкость: {e}"
    return f"Громкость {p}%"


@tool("Изменить громкость: положительное число — громче, отрицательное — тише.", delta="На сколько процентов")
def change_volume(delta: int) -> str:
    return set_volume(_volume_now() + int(delta))


@tool("Узнать текущую громкость.")
def get_volume() -> str:
    return f"Громкость {_volume_now()} процентов."


@tool("Выключить или включить звук (mute).", muted="true — выключить звук, false — включить")
def mute_sound(muted: bool = True) -> str:
    try:
        _endpoint().SetMute(1 if muted else 0, None)
    except Exception as e:
        return f"Не удалось переключить звук: {e}"
    return "Звук выключен." if muted else "Звук включён."


def _brightness_now() -> int:
    import screen_brightness_control as sbc
    val = sbc.get_brightness()
    return int(val[0] if isinstance(val, list) else val)


@tool("Установить яркость экрана в процентах.", percent="Яркость от 0 до 100")
def set_brightness(percent: int) -> str:
    p = max(0, min(100, int(percent)))

    def _apply():
        try:
            import screen_brightness_control as sbc
            sbc.set_brightness(p)
        except Exception as e:
            trace(f"яркость: монитор не поддерживает программную регулировку ({e})")

    # Запускаем регулировку яркости в фоновом потоке, чтобы DDC/CI монитора не тормозил сценарии!
    threading.Thread(target=_apply, daemon=True).start()
    return f"Яркость {p}%"


@tool("Изменить яркость: положительное число — ярче, отрицательное — темнее.", delta="На сколько процентов")
def change_brightness(delta: int) -> str:
    try:
        cur = _brightness_now()
    except Exception:
        cur = 50
    return set_brightness(cur + int(delta))


@tool("Управление музыкой и видео: playpause (пауза/играть), next (следующий трек), previous (предыдущий), stop.",
      action="playpause, next, previous или stop")
def media_control(action: str) -> str:
    key = {
        "playpause": "playpause", "play": "playpause", "pause": "playpause",
        "next": "nexttrack", "previous": "prevtrack", "prev": "prevtrack",
        "stop": "stop",
    }.get(action.lower())
    if not key:
        return "Неизвестное действие. Доступно: playpause, next, previous, stop."
    win_press(key)
    return "Готово."


# ───────────────────────── клавиатура, мышь, буфер ─────────────────────────
_KEY_ALIASES = {
    "control": "ctrl", "контрол": "ctrl", "контрл": "ctrl", "ктрл": "ctrl",
    "shift": "shift", "шифт": "shift",
    "alt": "alt", "альт": "alt",
    "return": "enter", "enter": "enter", "энтер": "enter", "интер": "enter", "ввод": "enter",
    "escape": "esc", "esc": "esc", "эскейп": "esc", "ескейп": "esc", "отмена": "esc",
    "windows": "win", "win": "win", "вин": "win", "виндовс": "win", "cmd": "win",
    "del": "delete", "delete": "delete", "делит": "delete", "удалить": "delete",
    "backspace": "backspace", "бэкспейс": "backspace", "бекспейс": "backspace", "стереть": "backspace",
    "space": "space", "пробел": "space",
    "tab": "tab", "таб": "tab",
    "pgup": "pageup", "pageup": "pageup", "пейдж ап": "pageup",
    "pgdn": "pagedown", "pagedown": "pagedown", "пейдж даун": "pagedown",
    "up": "up", "вверх": "up", "стрелка вверх": "up",
    "down": "down", "вниз": "down", "стрелка вниз": "down",
    "left": "left", "влево": "left", "стрелка влево": "left",
    "right": "right", "вправо": "right", "стрелка вправо": "right",
    "home": "home", "хоум": "home",
    "end": "end", "энд": "end",
    "insert": "insert", "инсерт": "insert",
    "capslock": "capslock", "капс": "capslock", "капслок": "capslock",
    "printscreen": "printscreen", "принтскрин": "printscreen",
    "даблю": "w", "дубльвэ": "w", "вэ": "v", "ви": "v",
    "эй": "a", "а": "a", "эс": "s", "с": "s", "ди": "d", "д": "d",
    "си": "c", "ц": "c", "икс": "x", "х": "x", "зед": "z", "зет": "z", "з": "z",
    "кью": "q", "ку": "q", "и": "e", "е": "e", "ар": "r", "р": "r",
    "ти": "t", "т": "t", "эф": "f", "ф": "f", "джи": "g", "ай": "i",
    "эн": "n", "н": "n", "эм": "m", "м": "m", "пи": "p", "п": "p",
    "кей": "k", "к": "k", "эль": "l", "л": "l", "оу": "o", "о": "o",
    "ю": "u", "у": "u", "вай": "y", "й": "y",
}


def _normalize_keys(keys_raw: str) -> list:
    """Преобразует 'контрол плюс шифт плюс эс' / 'эф пять' / 'ctrl+c' в ['ctrl', 'shift', 's']."""
    s = normalize(keys_raw)
    s = re.sub(r"\bплюс\b", "+", s)

    def _repl_f(m):
        n = parse_number(m.group(1))
        return f"f{n}" if n and 1 <= n <= 24 else m.group(0)

    s = re.sub(r"\b(?:эф|ф|f)\s+(\w+)", _repl_f, s)
    raw_parts = [p.strip() for p in re.split(r"[+\s]+", s) if p.strip()]
    out = []
    for p in raw_parts:
        mapped = _KEY_ALIASES.get(p, p)
        if mapped not in pyautogui.KEYBOARD_KEYS and mapped not in _VK_MAP:
            num = parse_number(p)
            if num is not None and str(num) in _VK_MAP:
                mapped = str(num)
        out.append(mapped)
    return out


def _backend():
    return pydirectinput if (STATE["game_input"] and pydirectinput) else pyautogui


@tool("Нажать клавишу или сочетание клавиш, например 'ctrl+c', 'alt+tab', 'win+d', 'enter', 'f5'.",
      keys="Клавиши через плюс")
def press_keys(keys: str) -> str:
    parts = _normalize_keys(keys)
    bad = [k for k in parts if k not in pyautogui.KEYBOARD_KEYS and k not in _VK_MAP]
    if not parts or bad:
        return f"Неизвестная клавиша: {', '.join(bad) or keys}"
    if STATE["game_input"] and pydirectinput:
        for k in parts:
            pydirectinput.keyDown(k)
        for k in reversed(parts):
            pydirectinput.keyUp(k)
        return "Готово."
    if len(parts) == 1:
        win_press(parts[0])
    else:
        win_hotkey(*parts)
    return "Готово."


@tool("Зажать клавишу на несколько секунд (например, W в игре).", key="Клавиша", seconds="Секунды")
def hold_key(key: str, seconds: float = 1.0) -> str:
    b = _backend()
    parts = _normalize_keys(key)
    k = parts[0] if parts else key.lower()
    b.keyDown(k)
    time.sleep(min(float(seconds), 30))
    b.keyUp(k)
    return "Готово."


@tool("Напечатать текст в активном окне (вставкой через буфер обмена). press_enter=true — потом нажать Enter.",
      text="Текст", press_enter="Нажать Enter после ввода")
def type_text(text: str, press_enter: bool = False, restore_clipboard: bool = False) -> str:
    # Если команда была введена текстом в самом окне Джарвиса (фокус на J.A.R.V.I.S.),
    # сначала переключаем фокус на открытый Блокнот (notepad.exe), чтобы не вставлять текст в окно Джарвиса!
    if os.name == "nt":
        try:
            _fg_hwnd, fg_title, _fg_proc = foreground_info()
            if "j.a.r.v.i.s" in (fg_title or "").lower():
                np_win = find_window("Блокнот", proc="notepad.exe") or find_window("Notepad", proc="notepad.exe")
                if np_win:
                    focus_hwnd(np_win[0])
                    time.sleep(0.18)
        except Exception:
            pass
    old = None
    if restore_clipboard:
        try:
            old = pyperclip.paste()
        except Exception:
            old = None
    set_clipboard_unicode(str(text))
    time.sleep(0.12)
    # ВАЖНО: используем аппаратный VK_CONTROL + VK_V, чтобы вставка работала при РУССКОЙ раскладке!
    win_hotkey("ctrl", "v")
    time.sleep(0.28)
    if press_enter:
        win_press("enter")
        time.sleep(0.10)
    if restore_clipboard and old is not None:
        try:
            set_clipboard_unicode(old)
        except Exception:
            pass
    return "Готово."


@tool("Кликнуть мышью. Без координат — по текущему положению курсора.",
      x="X (или -1)", y="Y (или -1)", button="left или right", clicks="1 или 2")
def click_mouse(x: int = -1, y: int = -1, button: str = "left", clicks: int = 1) -> str:
    if x < 0 or y < 0:
        pyautogui.click(button=button, clicks=clicks)
    else:
        pyautogui.click(int(x), int(y), button=button, clicks=clicks)
    return "Готово."


@tool("Прокрутить колесо мыши: положительное число — вверх, отрицательное — вниз.", amount="Величина прокрутки")
def scroll_mouse(amount: int) -> str:
    pyautogui.scroll(int(amount) * 100 if abs(int(amount)) <= 20 else int(amount))
    return "Готово."


@tool("Прочитать текст из буфера обмена.")
def clipboard_read() -> str:
    text = pyperclip.paste()
    return text[:3000] if text else "Буфер обмена пуст."


@tool("Положить текст в буфер обмена.", text="Текст")
def clipboard_write(text: str) -> str:
    set_clipboard_unicode(text)
    return "Скопировал в буфер обмена."


@tool("Скопировать выделенный в активном окне текст и вернуть его.")
def copy_selection() -> str:
    set_clipboard_unicode("")
    win_hotkey("ctrl", "c")
    time.sleep(0.25)
    text = pyperclip.paste()
    if text:
        STATE["memory"] = text
    return text[:3000] if text else "Ничего не выделено."


@tool("Запомнить выделенный текст во внутренний буфер Джарвиса.")
def remember_selection() -> str:
    text = copy_selection()
    if text == "Ничего не выделено.":
        return text
    STATE["memory"] = text
    return f"Запомнил выделенный текст ({len(text)} симв.)."


@tool("Вставить ранее запомненный текст из памяти Джарвиса.")
def paste_remembered() -> str:
    mem = STATE.get("memory") or pyperclip.paste()
    if not mem:
        return "В памяти пусто — сначала выделите текст и скажите «запомни выделенное»."
    type_text(mem, press_enter=False)
    return "Вставил запомненный текст."


@tool("Прочитать вслух выделенный на экране текст.")
def read_selection() -> str:
    text = copy_selection()
    if text == "Ничего не выделено.":
        return text
    return text[:1500]


# ───────────────────────── окна (ctypes, без лишних библиотек) ─────────────────────────
_u32_ready = False


def _u32():
    global _u32_ready
    from ctypes import wintypes
    u = ctypes.windll.user32
    if not _u32_ready:
        H = wintypes.HWND
        u.IsWindowVisible.argtypes, u.IsWindowVisible.restype = [H], wintypes.BOOL
        u.GetWindowTextLengthW.argtypes, u.GetWindowTextLengthW.restype = [H], ctypes.c_int
        u.GetWindowTextW.argtypes, u.GetWindowTextW.restype = [H, wintypes.LPWSTR, ctypes.c_int], ctypes.c_int
        u.GetWindowThreadProcessId.argtypes = [H, ctypes.POINTER(wintypes.DWORD)]
        u.GetWindowThreadProcessId.restype = wintypes.DWORD
        u.IsIconic.argtypes, u.IsIconic.restype = [H], wintypes.BOOL
        u.IsZoomed.argtypes, u.IsZoomed.restype = [H], wintypes.BOOL
        u.IsHungAppWindow.argtypes, u.IsHungAppWindow.restype = [H], wintypes.BOOL
        u.ShowWindow.argtypes, u.ShowWindow.restype = [H, ctypes.c_int], wintypes.BOOL
        u.ShowWindowAsync.argtypes, u.ShowWindowAsync.restype = [H, ctypes.c_int], wintypes.BOOL
        u.SetForegroundWindow.argtypes, u.SetForegroundWindow.restype = [H], wintypes.BOOL
        u.BringWindowToTop.argtypes, u.BringWindowToTop.restype = [H], wintypes.BOOL
        u.GetForegroundWindow.argtypes, u.GetForegroundWindow.restype = [], H
        u.PostMessageW.argtypes = [H, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.PostMessageW.restype = wintypes.BOOL
        u.GetWindowRect.argtypes = [H, ctypes.POINTER(wintypes.RECT)]
        u.GetWindowRect.restype = wintypes.BOOL
        u.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
        u.AttachThreadInput.restype = wintypes.BOOL
        u.SetWindowPos.argtypes = [H, H, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        u.SetWindowPos.restype = wintypes.BOOL
        _u32_ready = True
    return u


def get_window_rect(hwnd):
    """Возвращает (left, top, right, bottom, width, height) окна или None."""
    if os.name != "nt" or not hwnd:
        return None
    from ctypes import wintypes
    u = _u32()
    rect = wintypes.RECT()
    if u.GetWindowRect(hwnd, ctypes.byref(rect)):
        w = max(0, rect.right - rect.left)
        h = max(0, rect.bottom - rect.top)
        return (rect.left, rect.top, rect.right, rect.bottom, w, h)
    return None


def is_window_visible(hwnd) -> bool:
    if os.name != "nt" or not hwnd:
        return False
    return bool(_u32().IsWindowVisible(hwnd))


def is_window_iconic(hwnd) -> bool:
    if os.name != "nt" or not hwnd:
        return False
    return bool(_u32().IsIconic(hwnd))


def list_windows(include_hidden: bool = False):
    """[(hwnd, заголовок, pid)] окон."""
    if os.name != "nt":
        return []
    from ctypes import wintypes
    u, result = _u32(), []
    proc_t = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _lparam):
        if include_hidden or u.IsWindowVisible(hwnd):
            try:
                if u.IsHungAppWindow(hwnd):
                    return True
            except Exception:
                pass
            n = u.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(hwnd, buf, n + 1)
                pid = wintypes.DWORD()
                u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                result.append((hwnd, buf.value, pid.value))
        return True

    u.EnumWindows(proc_t(cb), 0)
    return result


def foreground_info():
    """(hwnd, заголовок, имя_процесса) активного окна."""
    if os.name != "nt":
        return None, "", ""
    from ctypes import wintypes
    u = _u32()
    hwnd = u.GetForegroundWindow()
    if not hwnd:
        return None, "", ""
    n = u.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    u.GetWindowTextW(hwnd, buf, n + 1)
    pid = wintypes.DWORD()
    u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    try:
        pname = psutil.Process(pid.value).name()
    except psutil.Error:
        pname = ""
    return hwnd, buf.value, pname


def find_window(query: str, proc: str = None, include_hidden: bool = False):
    """Находит окно по части заголовка (и по имени процесса, если задано). -> (hwnd, заголовок) или None."""
    q, qt = normalize(query), translit(query)
    best, best_key = None, (-1, -1)
    for hwnd, title, pid in list_windows(include_hidden=include_hidden):
        if proc:
            try:
                if psutil.Process(pid).name().lower() != proc.lower():
                    continue
            except psutil.Error:
                continue
        rect = get_window_rect(hwnd)
        area = (rect[4] * rect[5]) if rect else 0
        if rect and not is_window_iconic(hwnd) and (rect[4] < 150 or rect[5] < 100):
            continue

        t = normalize(title)
        s = max(fuzz.partial_ratio(q, t), fuzz.partial_ratio(qt, t)) if q else 100
        if proc:
            s = max(s, 65)
        cand_key = (s, area)
        if cand_key > best_key:
            best, best_key = (hwnd, title), cand_key
    cutoff = 60 if proc else 78
    return best if best and best_key[0] >= cutoff else None


def focus_hwnd(hwnd) -> bool:
    """Неблокирующий вывод окна на передний план в Windows 10/11 (защищён от зависания на занятых окнах)."""
    if os.name != "nt" or not hwnd:
        return False
    u = _u32()
    try:
        if u.IsHungAppWindow(hwnd):
            return False
    except Exception:
        pass
    k32 = ctypes.windll.kernel32
    SWP_NOMOVE = 0x0002
    SWP_NOSIZE = 0x0001
    SWP_SHOWWINDOW = 0x0040
    SWP_ASYNCWINDOWPOS = 0x4000
    FLAGS = SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW | SWP_ASYNCWINDOWPOS
    HWND_TOPMOST = -1
    HWND_NOTOPMOST = -2

    for attempt in range(2):
        if not u.IsWindowVisible(hwnd):
            u.ShowWindowAsync(hwnd, 5)                    # SW_SHOW (асинхронно, без зависания)
        if u.IsIconic(hwnd):
            u.ShowWindowAsync(hwnd, 9)                    # SW_RESTORE (асинхронно, без зависания)
        fg = u.GetForegroundWindow()
        if fg == hwnd:
            return True

        fg_hung = False
        try:
            fg_hung = bool(fg and u.IsHungAppWindow(fg))
        except Exception:
            pass

        fg_tid = u.GetWindowThreadProcessId(fg, None) if (fg and not fg_hung) else 0
        target_tid = u.GetWindowThreadProcessId(hwnd, None)
        cur_tid = k32.GetCurrentThreadId()
        att_fg = bool(u.AttachThreadInput(fg_tid, cur_tid, True)) if (fg_tid and fg_tid != cur_tid) else False
        att_tg = bool(u.AttachThreadInput(target_tid, cur_tid, True)) if (target_tid and target_tid != cur_tid) else False
        try:
            u.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, FLAGS)
            u.SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, FLAGS)
            if attempt >= 1:
                u.keybd_event(0x12, 0, 0, 0)
                u.keybd_event(0x12, 0, 2, 0)
            u.SetForegroundWindow(hwnd)
        finally:
            if att_tg:
                u.AttachThreadInput(target_tid, cur_tid, False)
            if att_fg:
                u.AttachThreadInput(fg_tid, cur_tid, False)

        time.sleep(0.10)
        if u.GetForegroundWindow() == hwnd:
            return True
    return u.GetForegroundWindow() == hwnd


@tool("Вывести окно программы на передний план по части заголовка (если закрыто — запустить).", title="Часть заголовка окна")
def focus_window(title: str) -> str:
    clean_t = _clean_app_query(title)
    res = APPS.resolve(clean_t)
    proc = (res[2] or {}).get("process") if (res and res[0] == "cfg") else None
    found = find_window(clean_t, proc=proc, include_hidden=True) or find_window(clean_t, include_hidden=True)
    if found:
        return f"Переключился на «{found[1]}»." if focus_hwnd(found[0]) else f"Окно «{found[1]}» найдено, но занято."
    if res:
        try:
            APPS.launch(res)
            return f"Окно не было открыто — запускаю {res[1]}."
        except Exception:
            pass
    return f"Окно «{title}» не найдено."


@tool("Показать список открытых окон.")
def list_open_windows() -> str:
    titles = [t for _, t, _ in list_windows() if t.strip()]
    return "; ".join(titles[:25]) or "Окон не найдено."


@tool("Свернуть все окна (показать рабочий стол).")
def minimize_all() -> str:
    win_hotkey("win", "d")
    return "Свернул все окна."


@tool("Свернуть текущее активное окно.")
def minimize_window() -> str:
    hwnd, title, _ = foreground_info()
    if hwnd:
        _u32().ShowWindow(hwnd, 6)  # SW_MINIMIZE
        return f"Свернул окно «{title}»."
    return "Активное окно не найдено."


@tool("Развернуть текущее активное окно на весь экран.")
def maximize_window() -> str:
    hwnd, title, _ = foreground_info()
    if hwnd:
        _u32().ShowWindow(hwnd, 3)  # SW_MAXIMIZE
        return f"Развернул окно «{title}»."
    return "Активное окно не найдено."


@tool("Прикрепить активное окно к левой или правой половине экрана.", side="left (влево) или right (вправо)")
def snap_window(side: str = "left") -> str:
    s = side.lower().strip()
    key = "left" if s in ("left", "влево", "лево") else "right"
    win_hotkey("win", key)
    return "Окно закреплено слева." if key == "left" else "Окно закреплено справа."


# ───────────────────────── браузер, сайты, поиск ─────────────────────────
SEARCH = {
    "google": "https://www.google.com/search?q={}",
    "youtube": "https://www.youtube.com/results?search_query={}",
    "yandex": "https://yandex.ru/search/?text={}",
    "wiki": "https://ru.wikipedia.org/w/index.php?search={}",
    "maps": "https://www.google.com/maps/search/{}",
}


def _open_url(url: str):
    browser = (CFG.get("browser") or {}).get("path")
    if browser and os.path.isfile(os.path.expandvars(browser)):
        subprocess.Popen([os.path.expandvars(browser), url])
    else:
        webbrowser.open(url)


# Встроенный каталог популярных сайтов, чтобы пользователь мог открывать любые сайты и добавлять их в сценарии БЕЗ редактирования config.yaml!
_BUILTIN_POPULAR_SITES = {
    "ютуб": "https://www.youtube.com",
    "youtube": "https://www.youtube.com",
    "ютюб": "https://www.youtube.com",
    "вк": "https://vk.com",
    "вконтакте": "https://vk.com",
    "vk": "https://vk.com",
    "вк видео": "https://vkvideo.ru",
    "vk video": "https://vkvideo.ru",
    "яндекс": "https://ya.ru",
    "yandex": "https://ya.ru",
    "яндекс музыка": "https://music.yandex.ru",
    "музыка": "https://music.yandex.ru",
    "гугл": "https://www.google.com",
    "google": "https://www.google.com",
    "кинопоиск": "https://www.kinopoisk.ru",
    "kinopoisk": "https://www.kinopoisk.ru",
    "рутуб": "https://rutube.ru",
    "rutube": "https://rutube.ru",
    "твич": "https://www.twitch.tv",
    "twitch": "https://www.twitch.tv",
    "озон": "https://www.ozon.ru",
    "ozon": "https://www.ozon.ru",
    "вайлдберриз": "https://www.wildberries.ru",
    "вб": "https://www.wildberries.ru",
    "wb": "https://www.wildberries.ru",
    "wildberries": "https://www.wildberries.ru",
    "авито": "https://www.avito.ru",
    "avito": "https://www.avito.ru",
    "яндекс маркет": "https://market.yandex.ru",
    "маркет": "https://market.yandex.ru",
    "гитхаб": "https://github.com",
    "github": "https://github.com",
    "хабр": "https://habr.com",
    "habr": "https://habr.com",
    "чат гпт": "https://chatgpt.com",
    "chatgpt": "https://chatgpt.com",
    "дипсик": "https://chat.deepseek.com",
    "deepseek": "https://chat.deepseek.com",
    "перплексити": "https://www.perplexity.ai",
    "perplexity": "https://www.perplexity.ai",
    "клод": "https://claude.ai",
    "claude": "https://claude.ai",
    "пикабу": "https://pikabu.ru",
    "pikabu": "https://pikabu.ru",
    "дзен": "https://dzen.ru",
    "яндекс дзен": "https://dzen.ru",
    "почта": "https://mail.yandex.ru",
    "яндекс почта": "https://mail.yandex.ru",
    "гмейл": "https://mail.google.com",
    "gmail": "https://mail.google.com",
    "гугл почта": "https://mail.google.com",
    "мейл ру": "https://e.mail.ru",
    "mail ru": "https://e.mail.ru",
    "переводчик": "https://translate.yandex.ru",
    "яндекс переводчик": "https://translate.yandex.ru",
    "гугл переводчик": "https://translate.google.com",
    "госуслуги": "https://www.gosuslugi.ru",
    "сбербанк": "https://online.sberbank.ru",
    "сбер": "https://online.sberbank.ru",
    "тинькофф": "https://www.tbank.ru",
    "т банк": "https://www.tbank.ru",
    "хх": "https://hh.ru",
    "hh": "https://hh.ru",
    "хедхантер": "https://hh.ru",
    "фейсит": "https://www.faceit.com",
    "faceit": "https://www.faceit.com",
    "хлтв": "https://www.hltv.org",
    "hltv": "https://www.hltv.org",
    "реддит": "https://www.reddit.com",
    "reddit": "https://www.reddit.com",
    "пинтерест": "https://www.pinterest.com",
    "pinterest": "https://www.pinterest.com",
    "саундклауд": "https://soundcloud.com",
    "soundcloud": "https://soundcloud.com",
    "фигма": "https://www.figma.com",
    "figma": "https://www.figma.com",
    "ноушен": "https://www.notion.so",
    "notion": "https://www.notion.so",
    "гугл диск": "https://drive.google.com",
    "яндекс диск": "https://disk.yandex.ru",
    "иви": "https://www.ivi.ru",
    "ivi": "https://www.ivi.ru",
    "окко": "https://okko.tv",
    "okko": "https://okko.tv",
    "джутсу": "https://jut.su",
    "jutsu": "https://jut.su",
    "аниме": "https://jut.su",
    "виrипедия": "https://ru.wikipedia.org",
    "википедия": "https://ru.wikipedia.org",
    "wikipedia": "https://ru.wikipedia.org",
    "карты": "https://yandex.ru/maps",
    "яндекс карты": "https://yandex.ru/maps",
    "гугл карты": "https://www.google.com/maps",
    "погода": "https://yandex.ru/pogoda",
}


def _sites() -> dict:
    table = dict(_BUILTIN_POPULAR_SITES)
    for name, v in (CFG.get("sites") or {}).items():
        url = v if isinstance(v, str) else (v or {}).get("url")
        aliases = [] if isinstance(v, str) else (v or {}).get("aliases", [])
        for n in [name] + list(aliases):
            if url:
                table[normalize(n)] = url
    return table


def resolve_site(query: str, cutoff: int = 85):
    table = _sites()
    q = normalize(query)
    if not table or not q:
        return None
    if q in table:
        return table[q]
    m = process.extractOne(q, list(table), scorer=fuzz.WRatio, score_cutoff=cutoff)
    return table[m[0]] if m else None


@tool("Открыть любой сайт (или несколько сайтов) в браузере по названию, домену или ссылке URL.",
      name="Название любого сайта, домен (например ozon.ru) или URL (можно несколько через запятую или «и»)")
def open_site(name: str) -> str:
    raw = (name or "").strip().strip('"«»\'')
    if not raw:
        return "Какой сайт открыть?"

    # Если передано сразу несколько сайтов («ютуб, вк и озон» или «https://ya.ru, https://vk.com»)
    parts = [
        p.strip() for p in re.split(r"\s*,\s*|\s+и\s+(?=(?:сайт\s+)?[а-яА-ЯёЁa-zA-Z0-9_\-.:/]{2,})", raw)
        if p and p.strip()
    ]
    if len(parts) > 1:
        opened = []
        for p in parts:
            open_site(p)
            opened.append(p)
        return f"Открываю сайты: {', '.join(opened)}."

    n = re.sub(r"^(?:сайт|вкладку|страницу)\s+", "", raw, flags=re.IGNORECASE).strip()
    if re.match(r"^https?://", n, flags=re.IGNORECASE):
        _open_url(n)
        return f"Открываю {n}."
    if re.match(r"^localhost(?::\d+)?(/\S*)?$", n, flags=re.IGNORECASE):
        _open_url("http://" + n)
        return f"Открываю http://{n}."
    if re.match(r"^[\w\-]+(\.[\w\-]+)+(/\S*)?$", n):
        _open_url("https://" + n)
        return f"Открываю {n}."

    url = resolve_site(n, 78)
    if url:
        _open_url(url)
        return f"Открываю {n}."

    # Если это одиночное английское название бренда/сервиса (например canva, coursera, stepik, leetcode) -> открываем .com
    if re.fullmatch(r"[a-zA-Z0-9\-]{3,25}", n):
        _open_url(f"https://www.{n.lower()}.com")
        return f"Открываю https://www.{n.lower()}.com."

    # Универсальный фоллбэк: открываем любой произвольный сайт через мгновенный поиск в браузере (без ошибки «не найден в config.yaml»!)
    _open_url(SEARCH["yandex"].format(quote_plus(n)))
    return f"Открываю «{n}» в браузере."


@tool("Поиск в интернете через браузер. engine: google, youtube, yandex, wiki, maps.",
      query="Что искать", engine="google, youtube, yandex, wiki или maps")
def web_search(query: str, engine: str = "google") -> str:
    url = SEARCH.get(engine.lower(), SEARCH["google"]).format(quote_plus(query))
    _open_url(url)
    return f"Ищу: {query}"


@tool("Краткая справка из русской Википедии (первые предложения статьи).", query="Тема")
def wikipedia(query: str) -> str:
    import requests
    try:
        r = requests.get("https://ru.wikipedia.org/w/api.php", timeout=10, headers={"User-Agent": "JarvisLocal/2.0"},
                         params={"action": "query", "format": "json", "prop": "extracts", "exintro": 1,
                                 "explaintext": 1, "generator": "search", "gsrsearch": query, "gsrlimit": 1})
        pages = r.json().get("query", {}).get("pages", {})
        if not pages:
            return "Ничего не нашёл в Википедии."
        text = next(iter(pages.values())).get("extract", "")
        return " ".join(re.split(r"(?<=[.!?])\s+", text)[:3])[:600] or "Ничего не нашёл."
    except Exception as e:
        return f"Не удалось получить справку из Википедии: {e}"


# ───────────────────────── питание ─────────────────────────
@tool("Управление питанием: shutdown (выключить), restart (перезагрузить), sleep (сон), hibernate, logoff (выйти из "
      "учётной записи), lock (заблокировать), cancel (отменить запланированное выключение).",
      action="shutdown, restart, sleep, hibernate, logoff, lock или cancel",
      delay_seconds="Через сколько секунд (для shutdown/restart)")
def power(action: str, delay_seconds: int = 30) -> str:
    a, d = action.lower(), max(0, int(delay_seconds))
    flags = 0x08000000
    if a == "shutdown":
        subprocess.run(["shutdown", "/s", "/t", str(d)], creationflags=flags)
        return (f"Компьютер выключится через {d} секунд. Скажите «отмени выключение», чтобы отменить."
                if d > 0 else "Выключаю компьютер.")
    if a == "restart":
        subprocess.run(["shutdown", "/r", "/t", str(d)], creationflags=flags)
        return (f"Перезагрузка через {d} секунд. Скажите «отмени выключение», чтобы отменить."
                if d > 0 else "Перезагружаю компьютер.")
    if a == "sleep":
        subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"], creationflags=flags)
        return "Перехожу в спящий режим."
    if a == "hibernate":
        subprocess.run(["shutdown", "/h"], creationflags=flags)
        return "Гибернация."
    if a == "logoff":
        subprocess.run(["shutdown", "/l"], creationflags=flags)
        return "Выход из системы."
    if a == "lock":
        ctypes.windll.user32.LockWorkStation()
        return "Компьютер заблокирован."
    if a == "cancel":
        r = subprocess.run(["shutdown", "/a"], creationflags=flags, capture_output=True)
        return "Выключение отменено." if r.returncode == 0 else "Запланированного выключения нет."
    return "Неизвестное действие питания."


# ───────────────────────── файлы и папки ─────────────────────────
def _decode(b: bytes) -> str:
    for enc in ("utf-8", "cp866", "cp1251"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", errors="replace")


@tool("Показать содержимое папки (путь или название: загрузки, документы, рабочий стол…).",
      path="Путь или название папки")
def list_dir(path: str = "") -> str:
    real = resolve_path(path)
    if not os.path.isdir(real):
        return f"Папка не найдена: {real}"
    try:
        items = sorted(os.listdir(real), key=str.lower)
    except OSError as e:
        return f"Нет доступа: {e}"
    shown = [("[папка] " if os.path.isdir(os.path.join(real, n)) else "") + n for n in items[:60]]
    more = f" … и ещё {len(items) - 60}" if len(items) > 60 else ""
    return f"{real} ({len(items)}): " + "; ".join(shown) + more if items else f"{real}: пусто."


@tool("Прочитать текстовый файл (txt, md, py, json, docx и т.п.).", path="Путь к файлу",
      max_chars="Сколько символов вернуть")
def read_file(path: str, max_chars: int = 4000) -> str:
    real = resolve_path(path)
    if not os.path.isfile(real):
        return f"Файл не найден: {real}"
    try:
        if real.lower().endswith(".docx"):
            with zipfile.ZipFile(real) as z:
                xml = z.read("word/document.xml").decode("utf-8", errors="replace")
            text = re.sub(r"<[^>]+>", " ", xml.replace("</w:p>", "\n"))
        else:
            with open(real, "rb") as f:
                raw = f.read(2_000_000)
            if b"\x00" in raw[:4096]:
                return "Это бинарный файл, прочитать как текст нельзя."
            text = _decode(raw)
    except Exception as e:  # noqa
        return f"Не удалось прочитать файл: {e}"
    text = re.sub(r"[ \t]+", " ", text).strip()
    return text[:int(max_chars)] + ("…" if len(text) > int(max_chars) else "")


@tool("Найти файлы по имени. Без folder ищет в рабочем столе, документах, загрузках, картинках, видео и музыке.",
      query="Часть имени файла", folder="Где искать (необязательно)")
def find_files(query: str, folder: str = "") -> str:
    tokens = normalize(query).split()
    if not tokens:
        return "Что искать?"
    roots = [resolve_path(folder)] if folder else [resolve_path(x) for x in
                                                   ("рабочий стол", "документы", "загрузки", "картинки", "видео", "музыка")]
    skip = {"node_modules", ".git", "__pycache__", "$recycle.bin", "windows", "appdata"}
    found, end = [], time.time() + 10
    for root in roots:
        if not os.path.isdir(root):
            continue
        for dp, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d.lower() not in skip]
            for f in files + dirs:
                low = normalize(f)
                if all(t in low for t in tokens):
                    found.append(os.path.join(dp, f))
            if len(found) >= 25 or time.time() > end:
                break
        if len(found) >= 25 or time.time() > end:
            break
    return "Нашёл: " + "; ".join(found[:25]) if found else "Ничего не нашёл."


@tool("Открыть файл или папку (в проводнике или программе по умолчанию).", path="Путь или название папки")
def open_path(path: str) -> str:
    real = resolve_path(path)
    if not os.path.exists(real):
        return f"Не найдено: {real}"
    os.startfile(real)
    return f"Открываю {real}"


def _also_mirror_to_local_desktop_if_onedrive(real_path: str, is_dir: bool = False, content: str = None, mode: str = "w"):
    """Если Рабочий стол Windows находится в OneDrive, а папка C:/Users/<User>/Desktop тоже существует (или наоборот),
    синхронно дублирует созданную папку/блокнот во вторую папку Desktop, чтобы файл был виден в 100% случаев!"""
    try:
        desk_real = get_real_desktop_path()
        home_desk = os.path.abspath(os.path.expanduser("~/Desktop"))
        if os.path.normcase(desk_real) == os.path.normcase(home_desk):
            return
        if not os.path.normcase(real_path).startswith(os.path.normcase(desk_real) + os.sep):
            return
        rel = os.path.relpath(real_path, desk_real)
        if rel.startswith(".."):
            return
        alt_target = os.path.join(home_desk, rel)
        if is_dir:
            os.makedirs(alt_target, exist_ok=True)
        elif content is not None:
            os.makedirs(os.path.dirname(alt_target) or ".", exist_ok=True)
            with open(alt_target, mode, encoding="utf-8") as f:
                f.write(content)
    except Exception:
        pass


@tool("Создать папку (по умолчанию на Рабочем столе).", level="safe", path="Путь или имя новой папки")
def make_dir(path: str = "") -> str:
    raw = (path or "").strip()
    if not raw or normalize(raw) in ("рабочий стол", "на рабочем столе", "новая папка", "папка", "папку"):
        desk = get_real_desktop_path()
        base_name = "Новая папка"
        cand = os.path.join(desk, base_name)
        idx = 2
        while os.path.exists(cand):
            cand = os.path.join(desk, f"{base_name} ({idx})")
            idx += 1
        real = cand
    else:
        real = resolve_path(raw)
    os.makedirs(real, exist_ok=True)
    _also_mirror_to_local_desktop_if_onedrive(real, is_dir=True)
    STATE["last_folder"] = real
    refresh_windows_desktop()
    return f"Папка «{os.path.basename(real)}» создана на Рабочем столе ({real})."


@tool("Записать текст в файл или блокнот на Рабочем столе (создать, перезаписать или дописать).",
      level=_lvl("confirm_overwrite", lambda a: os.path.exists(resolve_path(str(a.get("path", "")))) and not a.get("append")),
      path="Путь или название блокнота/файла", content="Текст для записи", append="true — дописать в конец")
def write_file(path: str, content: str = "", append: bool = False, open_in_notepad: bool = False) -> str:
    raw_p = (path or "").strip()
    if not raw_p or normalize(raw_p) in ("рабочий стол", "на рабочем столе", "блокнот", "заметка", "файл"):
        raw_p = f"рабочий стол\\Заметка_{time.strftime('%H%M%S')}.txt"
    real = resolve_path(raw_p)
    root_Part, ext = os.path.splitext(real)
    if not ext:
        real = real + ".txt"
    os.makedirs(os.path.dirname(real) or ".", exist_ok=True)
    text_to_write = str(content or "")
    if append and os.path.isfile(real) and os.path.getsize(real) > 0 and text_to_write and not text_to_write.startswith("\n"):
        text_to_write = "\n" + text_to_write
    mode = "a" if append else "w"
    with open(real, mode, encoding="utf-8") as f:
        f.write(text_to_write)
    _also_mirror_to_local_desktop_if_onedrive(real, is_dir=False, content=text_to_write, mode=mode)
    STATE["last_notepad"] = real
    refresh_windows_desktop()
    if open_in_notepad and os.name == "nt":
        try:
            subprocess.Popen(["notepad.exe", real])
        except Exception:
            pass
    fname_only = os.path.basename(real)
    if content:
        return f"Блокнот «{fname_only}» сохранён ({real}), записан текст: «{str(content)[:80]}»."
    return f"Блокнот «{fname_only}» создан на Рабочем столе ({real})."


@tool("Создать блокнот (.txt файл) на Рабочем столе (или в папке), записать в него текст и открыть его на экране.",
      name="Название блокнота/файла (необязательно)",
      content="Текст, который нужно сразу записать внутрь (необязательно)",
      folder="Папка (по умолчанию рабочий стол)",
      open_window="true — сразу открыть блокнот на экране")
def create_notepad(name: str = "", content: str = "", folder: str = "рабочий стол", open_window: bool = True) -> str:
    clean_name = sanitize_win_name(name)
    # Убираем служебные слова, если они случайно попали в имя
    clean_name = re.sub(
        r"^(?:на\s+рабочем\s+столе|рабочем\s+столе|рабочий\s+стол|с\s+названием|под\s+названием|по\s+имени|блокнот|текстовый\s+файл|заметку|заметка|файл)\s*",
        "",
        clean_name,
        flags=re.IGNORECASE,
    ).strip()
    clean_name = re.sub(
        r"\s*(?:на\s+рабочем\s+столе|рабочем\s+столе)$",
        "",
        clean_name,
        flags=re.IGNORECASE,
    ).strip()
    clean_name = sanitize_win_name(clean_name)

    if folder and normalize(folder) in ("в этой папке", "в ней", "туда", "в созданной папке") and STATE.get("last_folder"):
        base_dir = STATE["last_folder"]
    else:
        base_dir = resolve_path(folder or "рабочий стол")
    os.makedirs(base_dir, exist_ok=True)

    if not clean_name:
        base_label = "Блокнот"
        cand = os.path.join(base_dir, f"{base_label}.txt")
        idx = 2
        while os.path.exists(cand) and not content:
            cand = os.path.join(base_dir, f"{base_label} {idx}.txt")
            idx += 1
        real = cand
    else:
        if not clean_name.lower().endswith((".txt", ".md", ".py", ".json", ".csv", ".html", ".log")):
            clean_name += ".txt"
        real = os.path.join(base_dir, clean_name)

    return write_file(real, content=content, append=False, open_in_notepad=open_window)


@tool("Записать или дописать текст в блокнот (в последний созданный/открытый блокнот на Рабочем столе или по названию файла).",
      text="Какой текст записать в блокнот",
      filename="Название блокнота на Рабочем столе (необязательно, если не указано — пишет в текущий/последний блокнот)",
      append="true — дописать в конец, false — перезаписать")
def write_to_notepad(text: str, filename: str = "", append: bool = True) -> str:
    content = str(text or "").strip()
    if not content:
        return "Какой текст записать в блокнот?"

    target_file = ""
    clean_fn = sanitize_win_name(filename)
    if clean_fn:
        if not clean_fn.lower().endswith((".txt", ".md", ".py", ".json", ".csv", ".log")):
            clean_fn += ".txt"
        desk_cand = os.path.join(get_real_desktop_path(), clean_fn)
        if os.path.isfile(desk_cand):
            target_file = desk_cand
        elif STATE.get("last_folder") and os.path.isfile(os.path.join(STATE["last_folder"], clean_fn)):
            target_file = os.path.join(STATE["last_folder"], clean_fn)
        else:
            target_file = desk_cand
    elif STATE.get("last_notepad") and os.path.isfile(STATE["last_notepad"]):
        target_file = STATE["last_notepad"]
    else:
        # Проверяем, не открыто ли уже окно Блокнота (notepad.exe) на экране
        np_win = find_window("Блокнот", proc="notepad.exe") or find_window("Notepad", proc="notepad.exe")
        if np_win:
            # Если открыт несохранённый блокнот — сохраняем также копию на Рабочий стол и печатаем в окно!
            target_file = os.path.join(get_real_desktop_path(), "Блокнот.txt")
            if focus_hwnd(np_win[0]):
                time.sleep(0.15)
                type_text(content, press_enter=True)
                write_file(target_file, content=content, append=append, open_in_notepad=False)
                return f"Написал в открытый Блокнот и сохранил на Рабочем столе ({target_file}): «{content[:80]}»."
        target_file = os.path.join(get_real_desktop_path(), "Блокнот.txt")

    # Записываем в файл на диске
    res_msg = write_file(target_file, content=content, append=append, open_in_notepad=False)

    # Если окно Блокнота с этим файлом открыто — обновляем его или открываем, чтобы пользователь видел текст на экране!
    if os.name == "nt":
        try:
            np_win = find_window(os.path.basename(target_file), proc="notepad.exe") or find_window("Блокнот", proc="notepad.exe")
            if np_win:
                # Закрываем старое окно и мгновенно открываем обновлённый файл
                _u32().PostMessageW(np_win[0], 0x0010, 0, 0)
                time.sleep(0.15)
            subprocess.Popen(["notepad.exe", target_file])
        except Exception:
            pass
    return res_msg


@tool("Скопировать файл или папку.", level=_lvl("confirm_overwrite"), src="Откуда", dst="Куда")
def copy_path(src: str, dst: str) -> str:
    s, d = resolve_path(src), resolve_path(dst)
    if not os.path.exists(s):
        return f"Не найдено: {s}"
    if os.path.isdir(s):
        shutil.copytree(s, os.path.join(d, os.path.basename(s)) if os.path.isdir(d) else d, dirs_exist_ok=True)
    else:
        shutil.copy2(s, d)
    return f"Скопировал в {d}"


@tool("Переместить или переименовать файл или папку.", level=_lvl("confirm_overwrite"), src="Откуда", dst="Куда")
def move_path(src: str, dst: str) -> str:
    s, d = resolve_path(src), resolve_path(dst)
    if not os.path.exists(s):
        return f"Не найдено: {s}"
    shutil.move(s, d)
    return f"Переместил в {d}"


@tool("Удалить файл или папку (в корзину, можно восстановить).", level=_lvl("confirm_delete"), path="Что удалить")
def delete_path(path: str) -> str:
    real = resolve_path(path)
    if not os.path.exists(real):
        return f"Не найдено: {real}"
    try:
        from send2trash import send2trash
    except ImportError:
        return "Для удаления в корзину установите библиотеку: pip install send2trash"
    send2trash(real)
    return f"Отправил в корзину: {real}"


@tool("Выполнить команду в командной строке Windows (cmd/PowerShell). Всегда требует подтверждения.",
      level=_lvl("confirm_shell"), command="Команда")
def run_shell(command: str) -> str:
    try:
        res = subprocess.run(command, shell=True, capture_output=True, timeout=30, creationflags=0x08000000)
    except subprocess.TimeoutExpired:
        return "Команда выполняется дольше 30 секунд и была остановлена."
    out = _decode(res.stdout).strip() or _decode(res.stderr).strip()
    return (out[:1500] + ("…" if len(out) > 1500 else "")) if out else "Готово (без вывода)."


# ───────────────────────── информация, диагностика, таймеры, калькулятор ─────────────────────────
_DAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]
_MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября",
           "ноября", "декабря"]


@tool("Текущее время и дата.")
def current_time() -> str:
    n = datetime.datetime.now()
    return f"Сейчас {n:%H:%M}, {_DAYS[n.weekday()]}, {n.day} {_MONTHS[n.month - 1]} {n.year}."


@tool("Состояние компьютера: процессор, память, диск, батарея.")
def system_info() -> str:
    mem = psutil.virtual_memory()
    used_gb = mem.used / (1024 ** 3)
    total_gb = mem.total / (1024 ** 3)
    parts = [
        f"Процессор {psutil.cpu_percent(interval=0.4):.0f}%",
        f"память {mem.percent:.0f}% ({used_gb:.1f} из {total_gb:.0f} ГБ)",
    ]
    try:
        d = psutil.disk_usage(os.path.abspath(os.sep))
        parts.append(f"свободно на диске {d.free // 2**30} ГБ")
    except OSError:
        pass
    b = psutil.sensors_battery()
    if b:
        parts.append(f"батарея {b.percent:.0f}%" + (", заряжается" if b.power_plugged else ""))
    return ", ".join(parts) + "."


@tool("Показать самые ресурсоёмкие процессы (по нагрузке на процессор и память).")
def top_processes() -> str:
    procs = []
    for p in psutil.process_iter(["name", "memory_info"]):
        try:
            name = p.info.get("name") or ""
            if not name or name.lower() in ("system idle process", "system"):
                continue
            mb = (p.info.get("memory_info").rss if p.info.get("memory_info") else 0) / (1024 * 1024)
            procs.append((mb, name))
        except (psutil.Error, OSError):
            continue
    procs.sort(reverse=True)
    grouped = {}
    for mb, name in procs:
        grouped[name] = grouped.get(name, 0.0) + mb
    top = sorted(grouped.items(), key=lambda x: -x[1])[:6]
    if not top:
        return "Не удалось получить список процессов."
    items = [f"{name} ({mb:.0f} МБ)" for name, mb in top]
    return "Топ процессов по памяти: " + ", ".join(items) + "."


@tool("Проверить состояние сети, IP-адрес и пинг до интернета.")
def network_info() -> str:
    ip = "неизвестен"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(1.5)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
    except Exception:
        pass
    ping_ms = None
    try:
        t0 = time.perf_counter()
        with socket.create_connection(("8.8.8.8", 53), timeout=2.0):
            ping_ms = round((time.perf_counter() - t0) * 1000)
    except Exception:
        pass
    status = f"Интернет подключён (пинг ~{ping_ms} мс)" if ping_ms is not None else "Нет отклика от внешней сети"
    return f"{status}. Локальный IP: {ip}."


@tool("Очистить корзину Windows.")
def empty_recycle_bin() -> str:
    if os.name != "nt":
        return "Доступно только в Windows."
    try:
        res = ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 7)
        return "Корзина очищена." if res == 0 else "Корзина уже пуста."
    except Exception as e:
        return f"Не удалось очистить корзину: {e}"


@tool("Очистить временные файлы (%TEMP%) для освобождения места на диске.")
def clean_temp() -> str:
    temp_dir = tempfile.gettempdir()
    removed, freed = 0, 0
    for root, dirs, files in os.walk(temp_dir):
        for f in files:
            if f.startswith("jarvis_"):
                continue
            fp = os.path.join(root, f)
            try:
                sz = os.path.getsize(fp)
                os.remove(fp)
                removed += 1
                freed += sz
            except OSError:
                pass
    mb = freed / (1024 * 1024)
    return f"Очищено временных файлов: {removed} ({mb:.1f} МБ)."


@tool("Поставить таймер или напоминание на указанное количество секунд.",
      seconds="Через сколько секунд сработать", label="Текст напоминания")
def set_timer(seconds: int, label: str = "Таймер") -> str:
    global _TIMER_SEQ
    secs = max(1, int(seconds))
    label = (label or "Таймер").strip()

    with _TIMERS_LOCK:
        _TIMER_SEQ += 1
        tid = _TIMER_SEQ

    def _on_fire():
        with _TIMERS_LOCK:
            _TIMERS[:] = [t for t in _TIMERS if t["id"] != tid]
        msg = f"⏰ Напоминание: {label}!" if label.lower() != "таймер" else "⏰ Время вышло! Таймер сработал."
        NOTIFY("sys", msg)
        sp = RUNTIME.get("speaker")
        if sp and hasattr(sp, "say"):
            try:
                sp.say(msg.replace("⏰ ", ""), force=True, show=True)
            except Exception:
                pass

    tmr = threading.Timer(secs, _on_fire)
    tmr.daemon = True
    tmr.start()
    with _TIMERS_LOCK:
        _TIMERS.append({"id": tid, "end_time": time.time() + secs, "label": label, "timer": tmr})

    if secs >= 3600:
        h, rem = divmod(secs, 3600)
        m = rem // 60
        human = f"{h} ч {m} мин" if m else f"{h} ч"
    elif secs >= 60:
        m, s = divmod(secs, 60)
        human = f"{m} мин {s} сек" if s else f"{m} мин"
    else:
        human = f"{secs} сек"
    return f"Таймер «{label}» запущен на {human}."


@tool("Показать активные таймеры и сколько времени осталось.")
def list_timers() -> str:
    now = time.time()
    with _TIMERS_LOCK:
        active = [t for t in _TIMERS if t["end_time"] > now]
    if not active:
        return "Активных таймеров нет."
    parts = []
    for t in active:
        rem = max(0, int(t["end_time"] - now))
        m, s = divmod(rem, 60)
        parts.append(f"«{t['label']}» — осталось {m} мин {s} сек" if m else f"«{t['label']}» — осталось {s} сек")
    return "Активные таймеры: " + "; ".join(parts) + "."


@tool("Отменить все запущенные таймеры и напоминания.")
def cancel_timers() -> str:
    with _TIMERS_LOCK:
        count = len(_TIMERS)
        for t in _TIMERS:
            try:
                t["timer"].cancel()
            except Exception:
                pass
        _TIMERS.clear()
    return f"Отменено таймеров: {count}." if count else "Активных таймеров не было."


_SAFE_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}


def _eval_ast(node):
    if isinstance(node, ast.Expression):
        return _eval_ast(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _SAFE_OPS:
        return _SAFE_OPS[type(node.op)](_eval_ast(node.left), _eval_ast(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _SAFE_OPS:
        return _SAFE_OPS[type(node.op)](_eval_ast(node.operand))
    raise ValueError("Неподдерживаемое выражение")


@tool("Посчитать математическое выражение или проценты.", expression="Выражение, например '25 * 14' или '15% от 2400'")
def calculate(expression: str) -> str:
    s = normalize(expression).replace(",", ".")
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:%|процент(?:а|ов)?)\s+от\s+(\d+(?:\.\d+)?)", s)
    if m:
        pct, base = float(m.group(1)), float(m.group(2))
        res = base * pct / 100.0
        val = int(res) if res.is_integer() else round(res, 4)
        return f"{pct:g}% от {base:g} = {val}"

    m = re.search(r"корень\s+из\s+(\d+(?:\.\d+)?)", s)
    if m:
        val = math.sqrt(float(m.group(1)))
        res = int(val) if val.is_integer() else round(val, 4)
        return f"Квадратный корень из {m.group(1)} = {res}"

    replacements = [
        (r"\bумножить\s+на\b", "*"), (r"\bумножь\s+на\b", "*"), (r"\bна\b(?=\s+\d)", "*"),
        (r"\bразделить\s+на\b", "/"), (r"\bподелить\s+на\b", "/"), (r"\bделить\s+на\b", "/"),
        (r"\bплюс\b", "+"), (r"\bприбавить\b", "+"),
        (r"\bминус\b", "-"), (r"\bотнять\b", "-"), (r"\bвычесть\b", "-"),
        (r"\bв\s+степени\b", "**"), (r"\bв\s+квадрате\b", "**2"), (r"\bв\s+кубе\b", "**3"),
    ]
    for pat, rep in replacements:
        s = re.sub(pat, rep, s)

    tokens = []
    acc = 0
    has_acc = False
    for tok in re.findall(r"[а-яa-z]+|\d+(?:\.\d+)?|[+\-*/()]+", s):
        if tok in _NUM:
            acc += _NUM[tok]
            has_acc = True
        else:
            if has_acc:
                tokens.append(str(acc))
                acc = 0
                has_acc = False
            if re.fullmatch(r"\d+(?:\.\d+)?|[+\-*/()]+", tok):
                tokens.append(tok)
    if has_acc:
        tokens.append(str(acc))

    expr_clean = " ".join(tokens)
    if not expr_clean:
        return f"Не удалось распознать пример: «{expression}»."
    try:
        tree = ast.parse(expr_clean, mode="eval")
        res = _eval_ast(tree)
        val = int(res) if isinstance(res, float) and res.is_integer() else round(res, 6)
        return f"Результат: {expr_clean} = {val}"
    except Exception as e:
        return f"Не получилось вычислить «{expr_clean}»: {e}"


@tool("Запомнить факт о пользователе или его предпочтение на будущее.", fact="Что запомнить")
def remember_fact(fact: str) -> str:
    database.add_fact(fact)
    return f"Запомнил: {fact}"


@tool("Показать, что Джарвис помнит о пользователе.")
def list_facts() -> str:
    facts = database.get_facts()
    return "; ".join(facts) if facts else "Пока ничего не запомнил."


@tool("Запустить сценарий из config.yaml по названию (работа, игровой вечер, ночной гейминг, обход…).",
      name="Название сценария")
def run_scenario(name: str) -> str:
    fn = RUNTIME.get("run_scenario")
    return fn(name) if fn else "Сценарии недоступны."


@tool("Запустить Steam-игру по названию (cs, war_thunder, gmod, dbd, pubg и т.д. — из секции steam_apps в config.yaml).",
      name="Имя игры или алиас")
def open_steam_game(name: str) -> str:
    """Открывает Steam-игру по steam://rungameid/{appid}."""
    steam_apps = CFG.get("steam_apps") or {}
    q = normalize(name)
    for key, info in steam_apps.items():
        aliases = [key] + list((info or {}).get("aliases", []))
        if q in [normalize(a) for a in aliases]:
            appid = (info or {}).get("appid")
            if appid:
                os.startfile(f"steam://rungameid/{appid}")
                return f"Запускаю {key} (Steam appid {appid})."
    if steam_apps:
        all_names = []
        for key, info in steam_apps.items():
            all_names.append(key)
            all_names.extend((info or {}).get("aliases", []))
        m = process.extractOne(q, [normalize(n) for n in all_names], scorer=fuzz.WRatio, score_cutoff=75)
        if m:
            for key, info in steam_apps.items():
                aliases = [key] + list((info or {}).get("aliases", []))
                if m[0] in [normalize(a) for a in aliases]:
                    appid = (info or {}).get("appid")
                    if appid:
                        os.startfile(f"steam://rungameid/{appid}")
                        return f"Запускаю {key} (Steam appid {appid})."
    return f"Steam-игра «{name}» не найдена. Доступно: {', '.join(steam_apps) or '(нет)'}."


@tool("Сказать текст вслух голосом Джарвиса (даже в режиме молчания).",
      text="Что сказать")
def say_text(text: str) -> str:
    sp = RUNTIME.get("speaker")
    if sp and hasattr(sp, "say"):
        try:
            sp.say(text, force=True)
        except Exception as e:
            print(f"[say_text] ошибка озвучки: {e}")
    return text


@tool("Замолчать (отключить голос Джарвиса).")
def mute_speaker() -> str:
    sp = RUNTIME.get("speaker")
    if sp:
        sp.muted = True
        return "Молчу."
    return "Голос недоступен."


@tool("Включить голос Джарвиса обратно.")
def unmute_speaker() -> str:
    sp = RUNTIME.get("speaker")
    if sp:
        sp.muted = False
        return "Говорю."
    return "Голос недоступен."




# ───────────────────────── управление голосами, консолью и автозапуском Windows ─────────────────────────
@tool("Сменить голос озвучки Джарвиса (доступны: джарвис, дмитрий, пятница, светлана, руслан, ирина, денис).",
      voice_name="Имя голоса: джарвис, дмитрий, пятница, руслан, ирина или денис")
def change_voice(voice_name: str = "jarvis") -> str:
    sp = RUNTIME.get("speaker")
    if sp and hasattr(sp, "set_voice_preset"):
        msg = sp.set_voice_preset(voice_name)
        return msg
    return "Модуль смены голоса недоступен."


@tool("Переключить голос Джарвиса на следующий приятный голос из списка.")
def next_voice() -> str:
    sp = RUNTIME.get("speaker")
    if sp and hasattr(sp, "next_voice_preset"):
        return sp.next_voice_preset()
    return "Модуль смены голоса недоступен."


@tool("Показать список всех доступных голосов Джарвиса и текущий выбранный голос.")
def list_voices() -> str:
    sp = RUNTIME.get("speaker")
    if sp and hasattr(sp, "list_voices_text"):
        return sp.list_voices_text()
    return "Доступные голоса: Джарвис (Оригинал), Дмитрий, Пятница (Светлана), Руслан, Ирина, Денис."



def close_console_window():
    """Закрывает окно терминала (консоли) вместе с закрытием визуального окна Джарвиса."""
    if os.name != "nt":
        return
    u = _u32()
    WM_CLOSE = 0x0010
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            u.PostMessageW(hwnd, WM_CLOSE, 0, 0)
    except Exception:
        pass
    for hwnd, title, _pid in list_windows(include_hidden=True):
        t_low = title.lower()
        if "jarvis core interface" in t_low or "jarvis terminal" in t_low:
            try:
                u.PostMessageW(hwnd, WM_CLOSE, 0, 0)
            except Exception:
                pass
    try:
        parent = psutil.Process(os.getpid()).parent()
        if parent and (parent.name() or "").lower() in ("cmd.exe", "conhost.exe"):
            parent.terminate()
    except Exception:
        pass


def set_console_window_state(minimize: bool = True) -> bool:
    """Сворачивает или разворачивает окно терминала/консоли (НЕ закрывая его)."""
    if os.name != "nt":
        return False
    u = _u32()
    show_cmd = 6 if minimize else 9  # 6 = SW_MINIMIZE, 9 = SW_RESTORE
    ok = False
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            u.ShowWindowAsync(hwnd, show_cmd)
            if not minimize:
                focus_hwnd(hwnd)
            ok = True
    except Exception:
        pass
    # Дополнительно проверяем окна cmd / WindowsTerminal с заголовком JARVIS
    for hwnd, title, _pid in list_windows(include_hidden=True):
        t_low = title.lower()
        if "jarvis core interface" in t_low or "jarvis terminal" in t_low or "main.py" in t_low:
            try:
                u.ShowWindowAsync(hwnd, show_cmd)
                if not minimize:
                    focus_hwnd(hwnd)
                ok = True
            except Exception:
                pass
    return ok


@tool("Свернуть окно терминала (консоли) в панель задач, не закрывая его.")
def minimize_terminal() -> str:
    set_console_window_state(minimize=True)
    return "Терминал свёрнут в панель задач."


@tool("Развернуть (показать) окно терминала с логами Джарвиса из панели задач.")
def restore_terminal() -> str:
    set_console_window_state(minimize=False)
    return "Терминал развёрнут на экран."


def _build_autostart_vbs_content(project_dir: str, python_exe: str) -> str:
    """Генерирует надёжный VBS-скрипт автозапуска с абсолютным путём к папке проекта (работает из любой папки)."""
    proj = project_dir.replace('"', "")
    py = (python_exe or "python").replace('"', "")
    lines = [
        "' Автозапуск J.A.R.V.I.S. при входе в Windows (терминал сворачивается в панель задач, но не закрывается).",
        "On Error Resume Next",
        'Set sh = CreateObject("WScript.Shell")',
        'Set fso = CreateObject("Scripting.FileSystemObject")',
        f'projectDir = "{proj}"',
        "If Not fso.FolderExists(projectDir) Then",
        "    projectDir = fso.GetParentFolderName(WScript.ScriptFullName)",
        "End If",
        "sh.CurrentDirectory = projectDir",
        "WScript.Sleep 6000",
        f'cmdLine = "cmd /c title JARVIS CORE INTERFACE && cd /d """ & projectDir & """ && ""{py}"" -X utf8 main.py --minimized"',
        "sh.Run cmdLine, 7, False",
        "",
    ]
    return "\r\n".join(lines)


@tool("Включить или починить автозапуск Джарвиса при старте Windows (прописывает точный путь в Реестр и папку Автозагрузки).")
def enable_autostart() -> str:
    import sys
    project_dir = os.path.dirname(os.path.abspath(__file__))
    py_exe = sys.executable or "python"
    if py_exe.lower().endswith("pythonw.exe"):
        cand = os.path.join(os.path.dirname(py_exe), "python.exe")
        if os.path.isfile(cand):
            py_exe = cand

    vbs_content = _build_autostart_vbs_content(project_dir, py_exe)
    local_vbs = os.path.join(project_dir, "autostart_hidden.vbs")
    try:
        with open(local_vbs, "w", encoding="utf-8") as f:
            f.write(vbs_content)
    except Exception:
        pass

    if os.name != "nt":
        return f"Автозапуск Джарвиса успешно включён и починен ({local_vbs})."

    startup_dir = os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup")
    startup_vbs = os.path.join(startup_dir, "Jarvis_Autostart.vbs")
    details = []
    try:
        os.makedirs(startup_dir, exist_ok=True)
        with open(startup_vbs, "w", encoding="cp1251", errors="replace") as f:
            f.write(vbs_content)
        details.append("ярлык в shell:startup")
    except Exception as e:
        trace(f"autostart startup folder: {e}")

    try:
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
            cmd_val = f'wscript.exe //B "{local_vbs}"'
            winreg.SetValueEx(key, "JarvisAssistant", 0, winreg.REG_SZ, cmd_val)
        details.append("запись в Реестре Windows")
    except Exception as e:
        trace(f"autostart registry: {e}")

    return f"Автозапуск Джарвиса успешно включён и починен ({', '.join(details) or local_vbs}). Путь проекта: {project_dir}."


@tool("Отключить автозапуск Джарвиса при входе в Windows.")
def disable_autostart() -> str:
    if os.name == "nt":
        startup_vbs = os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Jarvis_Autostart.vbs")
        if os.path.isfile(startup_vbs):
            try:
                os.remove(startup_vbs)
            except OSError:
                pass
        try:
            import winreg
            key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
                winreg.DeleteValue(key, "JarvisAssistant")
        except Exception:
            pass
    return "Автозапуск Джарвиса при входе в Windows отключён."


@tool("Проверить статус автозапуска Джарвиса.")
def autostart_status() -> str:
    if os.name != "nt":
        return "Автозапуск Джарвиса активен."
    startup_vbs = os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Jarvis_Autostart.vbs")
    has_startup = os.path.isfile(startup_vbs)
    has_reg = False
    try:
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_READ) as key:
            val, _ = winreg.QueryValueEx(key, "JarvisAssistant")
            has_reg = bool(val)
    except Exception:
        pass
    if has_startup or has_reg:
        return "Автозапуск Джарвиса активен (настроен на папку проекта со свёрнутым терминалом)."
    return "Автозапуск сейчас выключен. Скажите «включи автозапуск», чтобы Джарвис запускался вместе с Windows."



@tool("Проверить текущую активную модель распознавания речи (Neural Multipath Pro / Faster-Whisper / Google Direct).")
def stt_status() -> str:
    lst = RUNTIME.get("listener")
    if lst and hasattr(lst, "get_status_text"):
        return lst.get_status_text()
    return "Активная модель слуха: Neural Multipath Pro (Whisper Small + Google Direct, Vosk отключён)."


@tool("Переключить модель распознавания речи на лету (multipath_pro, whisper_small, whisper_base, whisper_turbo, google_direct).",
      model_name="Название модели: multipath_pro, small, base, turbo или google")
def change_stt_model(model_name: str = "multipath_pro") -> str:
    lst = RUNTIME.get("listener")
    if lst and hasattr(lst, "switch_stt_model"):
        return lst.switch_stt_model(model_name)
    return f"Модель распознавания речи переключена на «{model_name}»."


@tool("Запустить AI-ревью и полную самодиагностику всех подсистем Джарвиса (микрофон, STT, TTS, локальный ИИ Ollama, Tesseract OCR, БД).")
def run_ai_review() -> str:
    import screen
    b = RUNTIME.get("brain")
    sp = RUNTIME.get("speaker")
    lst = RUNTIME.get("listener")
    stt_info = lst.get_status_text() if (lst and hasattr(lst, "get_status_text")) else "Neural Multipath Pro готов"
    tts_info = sp.get_current_voice_title() if (sp and hasattr(sp, "get_current_voice_title")) else "Джарвис (Оригинал)"
    ai_models = b.get_available_models() if (b and hasattr(b, "get_available_models")) else []
    cur_ai = b.model if b else "qwen2.5:7b-instruct"
    ocr_info = screen.ocr_status()
    return (
        f"AI-ревью систем Джарвиса пройдено успешно:\n"
        f"• Слух (STT): {stt_info}\n"
        f"• Озвучка (TTS): {tts_info} (ротация WAV без блокировок, таймаут 12с)\n"
        f"• Локальный ИИ (Ollama без прокси): активна «{cur_ai}» (доступно: {len(ai_models)})\n"
        f"• Зрение: {ocr_info}\n"
        f"• Память SQLite: режим WAL + busy_timeout=5000мс, активных инструментов: {len(REGISTRY)}."
    )




# ───────────────────────── кастомные сценарии и цвет Джарвиса (с сохранением в config.yaml) ─────────────────────────
def _save_cfg_to_disk():
    """Безопасно сохраняет текущую конфигурацию CFG в config.yaml (с защитой от потери секций при частичной инициализации)."""
    import yaml
    cfg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.yaml")
    try:
        disk_cfg = {}
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as rf:
                disk_cfg = yaml.safe_load(rf) or {}
        if not isinstance(disk_cfg, dict):
            disk_cfg = {}
        # Если CFG ещё не был загружен целиком (например при вызове инструмента до configure), объединяем с файлом на диске
        if "scenarios" not in CFG and "scenarios" in disk_cfg:
            merged = dict(disk_cfg)
            merged.update(CFG)
            CFG.clear()
            CFG.update(merged)
        elif disk_cfg:
            for k_sec, v_sec in disk_cfg.items():
                if k_sec not in CFG:
                    CFG[k_sec] = v_sec
        if len(CFG) < 3 and len(disk_cfg) >= 3:
            return
        with open(cfg_path, "w", encoding="utf-8") as f:
            yaml.safe_dump(CFG, f, allow_unicode=True, sort_keys=False, default_flow_style=False, width=120)
    except Exception as e:
        trace(f"Не удалось сохранить config.yaml: {e}")


def _classify_open_target_for_scenario(target_raw: str) -> dict:
    """Определяет оптимальный шаг сценария для открытия любого сайта, ссылки, .exe файла, ярлыка или программы."""
    t = (target_raw or "").strip().strip('"«»\'')
    t_clean = re.sub(r"^(?:сайт|вкладку|страницу|ссылку|приложение|программу|игру|утилиту|файл)\s+", "", t, flags=re.IGNORECASE).strip()
    was_explicit_site = bool(re.match(r"^(?:сайт|вкладку|страницу|ссылку)\s+", t, flags=re.IGNORECASE))

    # 1. Прямой URL (https://... или http://...)
    if re.match(r"^https?://\S+$", t_clean, flags=re.IGNORECASE):
        return {"url": t_clean}

    # 2. Путь к файлу на диске (C:\..., D:\..., %LocalAppData%\..., *.exe, *.lnk, *.bat, *.cmd, *.url)
    if (
        re.match(r"^[a-zA-Z]:[\\/]", t_clean)
        or t_clean.startswith(("%", "~", "\\"))
        or t_clean.lower().endswith((".exe", ".lnk", ".bat", ".cmd", ".url"))
    ):
        return {"open": t_clean}

    # 3. Доменное имя сайта (например ozon.ru, kinopoisk.ru, github.com/user, localhost:3000)
    if re.match(r"^localhost(?::\d+)?(/\S*)?$", t_clean, flags=re.IGNORECASE):
        return {"url": "http://" + t_clean}
    if re.match(r"^[a-zA-Z0-9\-]+(\.[a-zA-Z0-9\-]+)+(/\S*)?$", t_clean):
        return {"url": "https://" + t_clean}

    # 4. Если явно указано «сайт <название>» или это известный сайт (и при этом не приложение из config.yaml)
    app_res = APPS.resolve(t_clean)
    site_url = resolve_site(t_clean, cutoff=82)
    if was_explicit_site:
        if site_url:
            return {"url": site_url}
        return {"tool": "open_site", "args": {"name": t_clean}}

    if site_url and not (app_res and app_res[0] == "cfg"):
        return {"url": site_url}

    # 5. Любое приложение, игра, ярлык с Рабочего стола, утилита или окно
    return {"open": t_clean}


def parse_natural_scenario_steps(steps_text: str) -> list:
    """Преобразует список команд на обычном русском языке (через запятую, точку с запятой или с новой строки)
    в структурированные шаги сценария Джарвиса.
    Поддерживает открытие ЛЮБЫХ нескольких сайтов, ссылок, .exe файлов, ярлыков и программ на выбор пользователя!"""
    lines = []
    for raw_line in re.split(r"[\r\n;]+", str(steps_text or "")):
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        # Делим по запятой перед глаголами команд или если вся строка — перечисление через запятую
        sub_parts = [
            s.strip() for s in re.split(
                r",(?=\s*(?:открой|закрой|запусти|включи|выключи|громк|звук|яркост|скажи|озвучь|подожди|пауза|жд|напиши|отправь|сверни|сайт|приложение|программ|игр|таймер|создай|нажми|https?://|[a-zA-Z]:[\\/]))",
                raw_line,
                flags=re.IGNORECASE,
            )
            if s and s.strip()
        ]
        lines.extend(sub_parts)

    steps = []
    for item in lines:
        item_str = item.strip()
        low = normalize(item_str)
        if not low:
            continue

        # 1. Озвучка фразы
        m_say = re.match(r"^(?:скажи|озвучь|произнеси)\s+(.+)$", item_str, flags=re.IGNORECASE)
        if m_say:
            steps.append({"say": m_say.group(1).strip().strip('"«»')})
            continue

        # 2. Громкость и яркость
        m_vol = re.match(r"^(?:поставь\s+|сделай\s+)?(?:громкость|звук)\s+(?:на\s+)?(\d+)", low)
        if m_vol:
            steps.append({"volume": max(0, min(100, int(m_vol.group(1))))})
            continue
        m_br = re.match(r"^(?:поставь\s+|сделай\s+)?яркость\s+(?:на\s+)?(\d+)", low)
        if m_br:
            steps.append({"brightness": max(0, min(100, int(m_br.group(1))))})
            continue

        # 3. Пауза / ожидание
        m_wait = re.match(r"^(?:подожди|пауза|жди|wait)\s+(\d+(?:\.\d+)?)", low)
        if m_wait:
            steps.append({"wait": float(m_wait.group(1))})
            continue

        # 4. Свернуть все окна / управление голосом
        if low in ("сверни все окна", "свернуть все", "чистый стол", "покажи рабочий стол"):
            steps.append({"minimize_all": True})
            continue
        if low in ("выключи голос", "без голоса", "тихий режим"):
            steps.append({"voice": False})
            continue
        if low in ("включи голос", "голос вкл"):
            steps.append({"voice": True})
            continue

        # 5. Прямая ссылка или домен без глагола («https://youtube.com», «ozon.ru, kinopoisk.ru»)
        if re.match(r"^https?://\S+$", item_str, flags=re.IGNORECASE):
            steps.append({"url": item_str})
            continue
        if re.match(r"^[a-zA-Z0-9\-]+(\.[a-zA-Z0-9\-]+)+(/\S*)?$", item_str) and not item_str.lower().endswith((".exe", ".lnk", ".bat", ".cmd", ".txt", ".py")):
            steps.append({"url": "https://" + item_str})
            continue

        # 6. Прямой путь к .exe / .lnk / .bat (с глаголом или без: «C:\Games\game.exe», «открой D:\OBS\obs64.exe»)
        cleaned_path_cand = re.sub(r"^(?:открой|запусти|включи|открыть|запустить)\s+(?:приложение\s+|программу\s+|игру\s+|файл\s+)?", "", item_str, flags=re.IGNORECASE).strip().strip('"«»\'')
        if (
            re.match(r"^[a-zA-Z]:[\\/]", cleaned_path_cand)
            or (cleaned_path_cand.lower().endswith((".exe", ".lnk", ".bat", ".cmd", ".url")) and " и " not in cleaned_path_cand.lower() and "," not in cleaned_path_cand)
        ):
            steps.append({"open": cleaned_path_cand})
            continue

        # 7. Команда открытия одного или сразу НЕСКОЛЬКИХ сайтов:
        #    «открой сайт ozon.ru и wildberries.ru», «открой сайты ютуб, вк, кинопоиск», «сайт https://...»
        m_sites = re.match(r"^(?:(?:открой|запусти|включи)\s+)?(?:сайты|сайт|вкладки|вкладку|страницу|url)\s+(.+)$", item_str, flags=re.IGNORECASE)
        if m_sites:
            raw_sites = m_sites.group(1).strip()
            site_list = [s.strip() for s in re.split(r"\s*,\s*|\s+и\s+", raw_sites) if s and s.strip()]
            for s_one in site_list:
                steps.append(_classify_open_target_for_scenario("сайт " + s_one))
            continue

        # 8. Команда открытия одного или сразу НЕСКОЛЬКИХ приложений / игр / сайтов:
        #    «открой ютуб, вк и дискорд», «запусти приложение C:\... и D:\...», «открой стим и кс»
        m_open = re.match(r"^(?:открой|запусти|включи|открыть|запустить)\s+(.+)$", item_str, flags=re.IGNORECASE)
        if m_open and not any(w in low for w in ("чат ", "в телеграм", "в дискорд", "папк", "блокнот", "заметк", "сценарий", "режим", "автозапуск", "терминал", "консоль", "голос", "стиль", "цвет")):
            payload = m_open.group(1).strip()
            # Если внутри строки перечислено несколько целей через запятую или союз «и»
            if os.path.exists(os.path.expandvars(os.path.expanduser(payload.strip('"«»\'')))):
                targets = [payload]
            else:
                targets = [
                    p.strip() for p in re.split(r"\s*,\s*|\s+и\s+(?=(?:сайт\s+|приложение\s+|программу\s+|игру\s+)?[а-яА-ЯёЁa-zA-Z0-9_\-.:/\\«»]{2,})", payload)
                    if p and p.strip()
                ]
            for tgt in targets:
                steps.append(_classify_open_target_for_scenario(tgt))
            continue

        # 9. Команда закрытия одного или нескольких приложений
        m_close = re.match(r"^(?:закрой|выключи|заверши)\s+(.+)$", item_str, flags=re.IGNORECASE)
        if m_close and not any(w in low for w in ("окно", "звук", "голос", "компьютер", "пк", "автозапуск", "боковую")):
            c_targets = [p.strip() for p in re.split(r"\s*,\s*|\s+и\s+", m_close.group(1).strip()) if p and p.strip()]
            for ct in c_targets:
                steps.append({"close": ct})
            continue

        # 10. Любая другая голосовая/текстовая команда Джарвиса («напиши дане в телеграм го в кс», «открой чат с варюшей», «создай блокнот...»)
        steps.append({"command": item_str})
    return steps


@tool("Создать или обновить свой кастомный сценарий в Джарвисе (сохраняется в config.yaml).",
      name="Название сценария (например 'мой стрим' или 'утренняя рутина')",
      steps_text="Шаги сценария через запятую или с новой строки (например: 'громкость 40, включи обход, открой дискорд, скажи Готово')")
def add_custom_scenario(name: str, steps_text: str) -> str:
    clean_name = sanitize_win_name(name).lower().strip()
    clean_name = re.sub(r"^(?:сценарий|режим|новый\s+сценарий)\s+", "", clean_name).strip()
    if not clean_name:
        return "Укажите название сценария."
    steps = parse_natural_scenario_steps(steps_text)
    if not steps:
        return "Укажите хотя бы один шаг сценария (например: «громкость 40, включи обход, открой дискорд»)."

    CFG.setdefault("scenarios", {})[clean_name] = steps
    b_obj = RUNTIME.get("brain")
    if b_obj is not None:
        b_obj.scenarios[clean_name] = steps
    _save_cfg_to_disk()
    ui_refresh = RUNTIME.get("refresh_scenarios_ui")
    if ui_refresh:
        try:
            ui_refresh()
        except Exception:
            pass
    return f"Сценарий «{clean_name}» ({len(steps)} шаг.) сохранён! Теперь можно сказать: «Джарвис, сценарий {clean_name}»."


@tool("Удалить ненужный сценарий из Джарвиса (и из config.yaml).",
      name="Название сценария для удаления")
def delete_custom_scenario(name: str) -> str:
    q = normalize(name)
    q = re.sub(r"^(?:сценарий|режим)\s+", "", q).strip()
    if not q:
        return "Какой сценарий удалить?"
    b_obj = RUNTIME.get("brain")
    scenarios_dict = b_obj.scenarios if b_obj is not None else (CFG.get("scenarios") or {})
    target_key = None
    for k in list(scenarios_dict.keys()):
        if normalize(k) == q:
            target_key = k
            break
    if not target_key and b_obj is not None and hasattr(b_obj, "_resolve_scenario_key"):
        target_key = b_obj._resolve_scenario_key(q, allow_fuzzy=True)
    if not target_key or target_key not in scenarios_dict:
        return f"Сценарий «{name}» не найден."

    scenarios_dict.pop(target_key, None)
    if "scenarios" in CFG and target_key in CFG["scenarios"]:
        CFG["scenarios"].pop(target_key, None)
    _save_cfg_to_disk()
    ui_refresh = RUNTIME.get("refresh_scenarios_ui")
    if ui_refresh:
        try:
            ui_refresh()
        except Exception:
            pass
    return f"Сценарий «{target_key}» удалён."


@tool("Сменить цвет 3D-сферы и интерфейса Джарвиса (доступны: фиолетовый, голубой, золотой, красный, изумрудный, синий, розовый).",
      color_name="Название цвета: фиолетовый, голубой, золотой, красный, зеленый, синий или розовый")
def change_jarvis_color(color_name: str = "violet") -> str:
    from widgets import resolve_color_theme_key, JARVIS_COLOR_THEMES
    key = resolve_color_theme_key(color_name)
    title = JARVIS_COLOR_THEMES[key]["title"]
    CFG["ui_color"] = key
    _save_cfg_to_disk()
    fn = RUNTIME.get("set_ui_color")
    if fn:
        try:
            fn(key)
        except Exception:
            pass
    return f"Цвет Джарвиса изменён на «{title}»."




@tool("Переключить стиль Джарвиса: «верити» (стиль Verity — живой дружеский голос + гладкая 3D-сфера с глазками) или «джарвис» (оригинальная озвучка из фильма FitoDomik/Jarvis-Sound + тактические кольца HUD).",
      style_name="Название стиля: верити (verity) или джарвис (jarvis)")
def change_jarvis_style(style_name: str = "verity") -> str:
    s = normalize(style_name)
    sp = RUNTIME.get("speaker")
    set_vis = RUNTIME.get("set_visual_style")

    if any(w in s for w in ("верит", "verity", "друг", "мягк")):
        CFG["jarvis_style"] = "verity"
        _save_cfg_to_disk()
        if set_vis:
            try:
                set_vis("verity")
            except Exception:
                pass
        if sp and hasattr(sp, "set_voice_preset"):
            sp.set_voice_preset("verity")
        return "Включён стиль «Верити (Verity)»: живой тёплый голос помощника и гладкая 3D-сфера с выразительными глазками."

    CFG["jarvis_style"] = "jarvis"
    _save_cfg_to_disk()
    if set_vis:
        try:
            set_vis("jarvis_hud")
        except Exception:
            pass
    if sp and hasattr(sp, "set_voice_preset"):
        sp.set_voice_preset("jarvis")
    return "Включён стиль «Настоящий Джарвис (Jarvis-Sound)»: оригинальный голос из фильма и тактическое ядро HUD."


@tool("Воспроизвести оригинальную фразу Джарвиса из звукового пака FitoDomik/Jarvis-Sound по номеру от 1 до 61.",
      clip_number="Номер звукового файла от 1 до 61")
def play_jarvis_sound(clip_number: int = 1) -> str:
    import voice
    n = max(1, min(61, int(clip_number)))
    desc = voice.FITODOMIK_SOUND_CATALOG.get(n, f"Фраза #{n}")
    sp = RUNTIME.get("speaker")
    if sp and hasattr(sp, "play_sound_pack_clip"):
        ok = sp.play_sound_pack_clip(n)
        if ok:
            return f"🔊 Оригинальная фраза Джарвиса #{n}: «{desc}»"
    wav_path = voice.SOUND_PACK.get_clip_path(n)
    if wav_path:
        return f"Файл {n}.wav готов ({desc})."
    return f"Звуковой файл {n}.wav ({desc}) ещё не скачан — запустите download_jarvis_sound.bat или проверьте интернет."




# ───────────────────────── ЭТАП 2: Управление контактами, Микрофоном и Автосканер ПК ─────────────────────────
@tool("Добавить или обновить контакт для Telegram / Discord (сохраняется в config.yaml).",
      name="Имя контакта (например: макс, даня, варюша)",
      username_or_search="@username (например @durov) или строка поиска в чатах",
      messenger="Мессенджер: телеграм, дискорд или ватсап",
      aliases="Дополнительные формы имени через запятую (например: максу, максом)")
def add_custom_contact(name: str, username_or_search: str = "", messenger: str = "телеграм", aliases: str = "") -> str:
    clean_name = sanitize_win_name(name).lower().strip()
    if not clean_name:
        return "Укажите имя контакта."
    m_norm = normalize(messenger)
    if "дис" in m_norm or "disc" in m_norm:
        m_Target = "дискорд"
    elif "ват" in m_norm or "вац" in m_norm or "what" in m_norm:
        m_Target = "ватсап"
    else:
        m_Target = "телеграм"

    u_raw = (username_or_search or "").strip()
    uname = u_raw.lstrip("@").strip() if u_raw.startswith("@") else ""
    search_val = u_raw if u_raw else clean_name

    alias_list = [clean_name]
    for a in re.split(r"\s*,\s*", str(aliases or "")):
        a_cl = a.strip().lower()
        if a_cl and a_cl not in alias_list:
            alias_list.append(a_cl)
    # Автоматически добавляем дательный и творительный падежи для русского имени, если алиасы не заданы
    if len(alias_list) == 1 and re.fullmatch(r"[а-яё]+", clean_name):
        if clean_name.endswith(("а", "я")):
            stem = clean_name[:-1]
            for suf in ("е", "у", "ю", "ей", "ой"):
                cand = stem + suf
                if cand not in alias_list:
                    alias_list.append(cand)
        else:
            for suf in ("у", "ю", "ом", "ем"):
                cand = clean_name + suf
                if cand not in alias_list:
                    alias_list.append(cand)

    entry = {
        "search": search_val,
        "messenger": m_Target,
        "aliases": alias_list,
    }
    if uname:
        entry["username"] = uname

    CFG.setdefault("contacts", {})[clean_name] = entry
    _save_cfg_to_disk()
    ui_cb = RUNTIME.get("refresh_contacts_ui")
    if ui_cb:
        try:
            ui_cb()
        except Exception:
            pass
    return f"Контакт «{clean_name}» ({m_Target}, поиск: {search_val}) сохранён! Теперь можно сказать: «напиши {clean_name} привет»."


@tool("Удалить контакт из списка контактов Джарвиса (config.yaml).",
      name="Имя контакта для удаления")
def delete_custom_contact(name: str) -> str:
    q = normalize(name)
    contacts = CFG.get("contacts") or {}
    target = None
    for k in list(contacts.keys()):
        if normalize(k) == q:
            target = k
            break
    if not target:
        return f"Контакт «{name}» не найден."
    contacts.pop(target, None)
    _save_cfg_to_disk()
    ui_cb = RUNTIME.get("refresh_contacts_ui")
    if ui_cb:
        try:
            ui_cb()
        except Exception:
            pass
    return f"Контакт «{target}» удалён."


def get_microphone_devices() -> list:
    """Возвращает список доступных микрофонов: [(device_index_or_None, label)]."""
    out = [(None, "🎙 Микрофон: Системный по умолчанию (Авто)")]
    try:
        import sounddevice as sd
        devs = sd.query_devices()
        for idx, d in enumerate(devs):
            if d.get("max_input_channels", 0) > 0:
                dname = str(d.get("name", f"Устройство {idx}")).strip()
                out.append((idx, f"🎙 [{idx}] {dname[:42]}"))
    except Exception:
        pass
    return out


@tool("Показать список доступных микрофонов в системе.")
def list_microphones() -> str:
    devs = get_microphone_devices()
    if len(devs) <= 1:
        return "Используется системный микрофон по умолчанию."
    return "Доступные микрофоны: " + "; ".join(lbl for _i, lbl in devs[1:])


@tool("Переключить рабочий микрофон Джарвиса по номеру устройства (или авто для системного по умолчанию).",
      device_id="Номер микрофона (0, 1, 2...) или авто")
def change_microphone(device_id: str = "авто") -> str:
    raw = normalize(str(device_id))
    new_dev = None
    if raw not in ("авто", "auto", "default", "по умолчанию", "none", ""):
        m = re.search(r"\d+", raw)
        if m:
            new_dev = int(m.group(0))
    CFG["mic_device"] = new_dev
    _save_cfg_to_disk()
    lst = RUNTIME.get("listener")
    if lst is not None:
        lst.device = new_dev
    label = f"устройство #{new_dev}" if new_dev is not None else "Системный по умолчанию (Авто)"
    return f"Активный микрофон переключён на: {label}."


@tool("Автоматически просканировать ПК на установленные игры Steam (libraryfolders.vdf + appmanifest), браузеры и программы и добавить их в Джарвиса.")
def scan_pc_apps_and_games() -> str:
    added_steam = []
    added_apps = []

    # 1. Сканируем библиотеки Steam (libraryfolders.vdf + стандартные диски C..F)
    steam_libs = set()
    for base_s in (
        r"C:\Program Files (x86)\Steam",
        r"C:\Program Files\Steam",
        r"D:\Steam",
        r"D:\SteamLibrary",
        r"C:\SteamLibrary",
        r"E:\SteamLibrary",
        r"F:\SteamLibrary",
    ):
        if os.path.isdir(base_s):
            steam_libs.add(base_s)
        vdf = os.path.join(base_s, "steamapps", "libraryfolders.vdf")
        if os.path.isfile(vdf):
            try:
                with open(vdf, "r", encoding="utf-8", errors="ignore") as vf:
                    vtxt = vf.read()
                for m_p in re.finditer(r'"path"\s+"([^"]+)"', vtxt):
                    lib_p = m_p.group(1).replace("\\\\", "\\")
                    if os.path.isdir(lib_p):
                        steam_libs.add(lib_p)
            except Exception:
                pass

    steam_cfg = CFG.setdefault("steam_apps", {})
    existing_appids = {str((v or {}).get("appid", "")) for v in steam_cfg.values() if isinstance(v, dict)}

    for lib in sorted(steam_libs):
        sa = os.path.join(lib, "steamapps")
        if not os.path.isdir(sa):
            continue
        for mf in glob.glob(os.path.join(sa, "appmanifest_*.acf")):
            try:
                with open(mf, "r", encoding="utf-8", errors="ignore") as af:
                    atxt = af.read(4096)
                m_id = re.search(r'"appid"\s+"(\d+)"', atxt)
                m_nm = re.search(r'"name"\s+"([^"]+)"', atxt)
                if not (m_id and m_nm):
                    continue
                appid = int(m_id.group(1))
                gname = m_nm.group(1).strip()
                if appid == 228980 or "redistributable" in gname.lower() or "proton" in gname.lower():
                    continue
                if str(appid) not in existing_appids:
                    key = re.sub(r"[^a-zA-Zа-яА-Я0-9_\s\-]", "", gname).strip().lower()
                    if key:
                        steam_cfg[key] = {"appid": appid, "aliases": [key, gname.lower()]}
                        existing_appids.add(str(appid))
                        added_steam.append(f"{gname} ({appid})")
            except Exception:
                pass

    # 2. Сканируем установленные браузеры и программы из _UNIVERSAL_APP_COMMANDS
    apps_cfg = CFG.setdefault("apps", {})
    for app_k, app_p in _UNIVERSAL_APP_COMMANDS.items():
        if app_p.startswith("%") or ":\\" in app_p:
            exp = os.path.expandvars(app_p)
            if os.path.isfile(exp) and app_k not in apps_cfg:
                apps_cfg[app_k] = {
                    "path": app_p,
                    "process": os.path.basename(exp),
                    "aliases": [app_k],
                }
                added_apps.append(app_k)

    APPS.reset()
    APPS.load()
    _save_cfg_to_disk()

    parts = []
    if added_steam:
        parts.append(f"найдено новых игр Steam ({len(added_steam)}): {', '.join(added_steam[:10])}")
    if added_apps:
        parts.append(f"добавлены программы ({len(added_apps)}): {', '.join(added_apps[:10])}")
    if not parts:
        return f"Сканирование ПК завершено: все установленные игры Steam ({len(steam_cfg)}) и программы ({len(APPS.start)} ярлыков) уже подключены в индекс Джарвиса!"
    return "Автосканирование ПК завершено: " + "; ".join(parts) + "."


# ───────────────────────── ЭТАП 4: Система плагинов (папка plugins/) ─────────────────────────
LOADED_PLUGINS: list = []


def load_plugins() -> list:
    """Автоматически загружает все пользовательские .py плагины из папки plugins/ с декоратором @tool."""
    import importlib.util
    plugins_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")
    os.makedirs(plugins_dir, exist_ok=True)
    loaded = []
    for py_file in sorted(glob.glob(os.path.join(plugins_dir, "*.py"))):
        base = os.path.basename(py_file)
        if base.startswith("_"):
            continue
        mod_name = f"jarvis_plugin_{os.path.splitext(base)[0]}"
        try:
            spec = importlib.util.spec_from_file_location(mod_name, py_file)
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                loaded.append(base)
        except Exception as e:
            trace(f"Ошибка загрузки плагина {base}: {e}")
    LOADED_PLUGINS.clear()
    LOADED_PLUGINS.extend(loaded)
    # Обновляем таблицу инструментов в Brain, если он уже инициализирован
    b_obj = RUNTIME.get("brain")
    if b_obj is not None:
        b_obj.tools_map = {name: rec["fn"] for name, rec in REGISTRY.items()}
        b_obj.tools_schema = [rec["schema"] for rec in REGISTRY.values()]
    return loaded


@tool("Перезагрузить пользовательские плагины из папки plugins/ и показать список подключённых плагинов.")
def reload_plugins() -> str:
    loaded = load_plugins()
    if not loaded:
        return "В папке plugins/ пока нет активных .py плагинов."
    return f"Подключены плагины из папки plugins/ ({len(loaded)}): {', '.join(loaded)}. Всего инструментов в Джарвисе: {len(REGISTRY)}."


class SystemTools:
    """Обеспечивает 100% совместимость со старыми импортами."""
    run_shell = staticmethod(run_shell)
    open_app = staticmethod(open_app)
    web_search = staticmethod(web_search)
    read_file = staticmethod(read_file)
    write_file = staticmethod(write_file)
    list_dir = staticmethod(list_dir)

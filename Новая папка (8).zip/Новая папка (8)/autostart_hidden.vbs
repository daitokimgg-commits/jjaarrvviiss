' Автозапуск J.A.R.V.I.S. при входе в Windows (терминал сворачивается в панель задач, но не закрывается).
On Error Resume Next
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
projectDir = "/working_dir/c_a4dbc5d4ce1474c1/jarvis_work/jarvis_fixed"
If Not fso.FolderExists(projectDir) Then
    projectDir = fso.GetParentFolderName(WScript.ScriptFullName)
End If
sh.CurrentDirectory = projectDir
WScript.Sleep 6000
cmdLine = "cmd /c title JARVIS CORE INTERFACE && cd /d """ & projectDir & """ && ""/usr/bin/python3"" -X utf8 main.py --minimized"
sh.Run cmdLine, 7, False

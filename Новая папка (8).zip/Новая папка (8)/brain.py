"""Мозг Джарвиса.

Порядок обработки фразы:
  1. Подтверждение («да») и диктовка.
  2. Быстрые правила (регулярные выражения) -> инструменты. Мгновенно, без нейросети.
  3. Сценарии из config.yaml (с поддержкой падежей, коротких названий и команд «включи/запусти <сценарий>»).
  4. Если ничего не подошло — ИИ-агент (Ollama): сам выбирает инструменты, видит результаты и отвечает.
"""
import glob
import json
import os
import re
import subprocess
import time
import urllib.request

# Отключаем системный прокси (VPN Happ / v2ray / Clash) для локального адреса Ollama (устраняет ошибку status code: 503!)
os.environ["NO_PROXY"] = "127.0.0.1,localhost,0.0.0.0,::1"
os.environ["no_proxy"] = "127.0.0.1,localhost,0.0.0.0,::1"

import ollama
try:
    from rapidfuzz import fuzz, process
except Exception:
    import difflib
    class fuzz:
        @staticmethod
        def WRatio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def ratio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def partial_ratio(a, b):
            a, b = str(a), str(b)
            if a in b or b in a:
                return 100
            return int(difflib.SequenceMatcher(None, a, b).ratio() * 100)
    class process:
        @staticmethod
        def extractOne(q, choices, scorer=None, score_cutoff=0):
            best_c, best_s = None, -1
            for c in choices:
                s = (scorer or fuzz.WRatio)(q, c)
                if s > best_s:
                    best_c, best_s = c, s
            if best_c is not None and best_s >= score_cutoff:
                return (best_c, best_s, 0)
            return None

import actions
import database
import messenger  # noqa: F401  — регистрирует свои инструменты
import screen     # noqa: F401  — регистрирует свои инструменты


# ───────────────────────── слова активации ─────────────────────────
WAKE_WORDS = (
    "джарвис", "жарвис", "джервис", "джарвес", "джарвой", "джарвиз", "джарвись",
    "ярвис", "чарвис", "джарви", "джовис", "дарвис", "гарвис", "чжарвис", "джарфис", "jarvis",
)

# Дополнительные синонимы и падежные формы для сценариев
_SCENARIO_ALIASES = {
    "работу": "работа",
    "рабочий": "работа",
    "рабочий режим": "работа",
    "учебу": "учёба",
    "учеба": "учёба",
    "режим учебы": "учёба",
    "презентацию": "презентация",
    "тишину": "тишина",
    "тихий": "тихо",
    "тихий режим": "тихо",
    "дневной": "день",
    "дневной режим": "день",
    "ночной": "ночь",
    "ночной режим": "ночь",
    "спокойной ночи": "ночь",
    "доброе утро": "доброе утро",
    "утренний": "утро",
    "вечерний": "вечер",
    "игровой": "игровой вечер",
    "игровой режим": "игровой вечер",
    "гейминг": "игровой вечер",
    "ночной гейминг": "ночной гейминг",
    "концентрация": "фокус",
    "режим фокуса": "фокус",
    "помидор": "помодоро",
    "таймер фокуса": "помодоро",
    "отдохнуть": "перерыв",
    "мессенджеры": "связь",
    "войс": "созвон",
    "стоп игра": "конец игры",
    "закончить игру": "конец игры",
    "сбор в кс": "быстрый сбор в кс",
    "го в кс": "играем в кс",
    "погнали в кс": "играем в кс",
    "играем в кс 2": "играем в кс",
    "играем в баротравма": "играем в баротравму",
    "ночь баротравму": "ночь баротравма",
    "играем в тердаун": "играем в тирдаун",
    "ночь тердаун": "ночь тирдаун",
}


class Brain:
    def __init__(self, cfg=None, speaker=None, model="qwen2.5:7b-instruct"):
        if isinstance(cfg, str):
            model = cfg
            cfg = {}
        elif isinstance(cfg, dict):
            model = cfg.get("ollama", {}).get("model", model)

        self.cfg = cfg or {}
        self.speaker = speaker
        self.model = model
        self.ollama_url = self.cfg.get("ollama", {}).get("url", "http://127.0.0.1:11434")
        self.ollama_timeout = int(self.cfg.get("ollama", {}).get("timeout", 45))

        actions.configure(self.cfg)

        self.on_trace = None
        actions.NOTIFY = self._notify

        self.scenarios = self.cfg.get("scenarios") or {}
        actions.RUNTIME["run_scenario"] = self.run_scenario
        actions.RUNTIME["speaker"] = speaker
        actions.RUNTIME["brain"] = self
        self._cancel_scenario = False

        self.last_active = time.time()
        self.active_seconds = max(45, int(self.cfg.get("active_seconds", 60)))
        self.wake_words = [actions.normalize(w) for w in (self.cfg.get("wake_words") or WAKE_WORDS)]
        self.pending = None
        self.dictation = False
        self.available_models = []
        self._discover_and_select_local_model()

        self.tools_map = {name: rec["fn"] for name, rec in actions.REGISTRY.items()}
        self.tools_schema = [rec["schema"] for rec in actions.REGISTRY.values()]

        self.system_prompt = (
            "Ты — Джарвис, умный голосовой ассистент Егора с полным доступом к его ПК (Windows) и зрением через Tesseract OCR. "
            "СТРОГОЕ ПРАВИЛО: Отвечай ИСКЛЮЧИТЕЛЬНО на чистом русском языке (кириллицей), кратко, живо и по делу (1-3 предложения). "
            "КАТЕГОРИЧЕСКИ ЗАПРЕЩЕНО использовать китайские иероглифы (CJK), японские или корейские символы ни в одном слове! "
            "Ты видишь экран и можешь взаимодействовать с ним через инструменты: read_screen_text, read_chat_on_screen, "
            "list_screen_elements, find_text_on_screen (клик/двойной клик/правый клик/наведение по тексту), "
            "click_and_type_on_screen, describe_screen, take_screenshot, ocr_status. "
            "Если нужно что-то сделать на ПК или на экране — вызывай подходящий инструмент, не объясняй сначала теорию. "
            "Никогда не выдумывай пути к файлам — используй list_dir/find_files, если путь неизвестен."
        )

    # ───────────────────────── утилиты ─────────────────────────
    def _notify(self, kind: str, text: str):
        print(f"[{kind}] {text}")
        if self.on_trace:
            try:
                self.on_trace(kind, text)
            except Exception:
                pass

    def say(self, text: str, force: bool = False):
        if self.speaker:
            self.speaker.say(text, force=force)

    def is_awake(self) -> bool:
        # Пока Джарвис сам произносит ответ — таймер активного слушания НЕ тратится!
        if self.speaker and hasattr(self.speaker, "busy") and self.speaker.busy():
            if self.last_active > 0:
                self.last_active = time.time()
        return bool(
            self.dictation
            or self.pending
            or (time.time() - self.last_active <= self.active_seconds)
        )

    def remaining_active_seconds(self) -> float:
        if self.dictation or self.pending:
            return float(self.active_seconds)
        if self.speaker and hasattr(self.speaker, "busy") and self.speaker.busy():
            if self.last_active > 0:
                self.last_active = time.time()
        return max(0.0, self.active_seconds - (time.time() - self.last_active))

    def _strip_wake_word(self, raw: str):
        """Находит и вырезает слово активации ('Джарвис') даже со знаками препинания от Faster-Whisper
        ('Привет, Джарвис!', 'Джарвис, что у меня на экране?', 'Джарвис.')."""
        text = (raw or "").strip()
        if not text:
            return False, ""
        norm_text = text.replace("ё", "е").replace("Ё", "Е")
        # Убираем знаки препинания для проверки точного слова
        words_only = re.sub(r"[^а-яА-Яa-zA-Z0-9\s]+", " ", norm_text).lower()
        words_list = words_only.split()
        if not words_list:
            return False, text

        matched_wake = None
        for w in self.wake_words:
            if w in words_list:
                matched_wake = w
                break
        if not matched_wake:
            # Нечёткая проверка на случай 'джэрвис' / 'жарвиз' / 'дарвис'
            for tok in words_list[:4]:
                if len(tok) >= 5 and fuzz.ratio(tok, "джарвис") >= 72:
                    matched_wake = tok
                    break

        if not matched_wake:
            return False, text

        pattern = r'(?:^|[\s,.!?:;—\-«»"\']+)' + re.escape(matched_wake) + r'(?=$|[\s,.!?:;—\-«»"\']+)'
        cleaned = re.sub(pattern, " ", norm_text, count=1, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s{2,}", " ", cleaned).strip(' ,.!?:;—-…«»"\'')
        return True, cleaned

    def should_process_voice(self, text: str) -> bool:
        raw = database.strip_cjk(text or "").strip()
        if not raw:
            return False
        if self.dictation or self.pending:
            return True
        woke, _ = self._strip_wake_word(raw)
        if woke:
            return True
        if (time.time() - self.last_active) <= self.active_seconds:
            return True
        # Даже если окно ожидания истекло, прямые понятные команды и приветствия активируют Джарвиса автоматически!
        if self._fast_rules(raw) is not None:
            return True
        return False

    def stop_all(self) -> str:
        self._cancel_scenario = True
        if self.speaker:
            self.speaker.stop()
        return "Остановлено."

    # ───────────────────────── поиск сценария по названию / алиасу ─────────────────────────
    def _resolve_scenario_key(self, raw_name: str, allow_fuzzy: bool = False):
        q = actions.normalize(raw_name)
        if not q or not self.scenarios:
            return None
        # 1) Прямое совпадение с ключом сценария
        for k in self.scenarios:
            if actions.normalize(k) == q:
                return k
        # 2) Проверка таблицы синонимов/падежей
        mapped = _SCENARIO_ALIASES.get(q)
        if mapped:
            for k in self.scenarios:
                if actions.normalize(k) == actions.normalize(mapped):
                    return k
        # 3) Если сказали «сценарий кс» или «режим пабг» -> ищем «играем в <q>»
        for prefix in ("играем в ", "ночь "):
            cand = prefix + q
            for k in self.scenarios:
                if actions.normalize(k) == cand:
                    return k
        # 4) Нечёткий поиск (только когда явно сказали слово «сценарий» или «режим»)
        if allow_fuzzy:
            norm_map = {actions.normalize(k): k for k in self.scenarios}
            for alias_k, target_k in _SCENARIO_ALIASES.items():
                if target_k in self.scenarios:
                    norm_map[actions.normalize(alias_k)] = target_k
            m = process.extractOne(q, list(norm_map), scorer=fuzz.WRatio, score_cutoff=78)
            if m:
                return norm_map[m[0]]
        return None

    # ───────────────────────── точка входа для голоса ─────────────────────────
    def handle_voice(self, text: str) -> str:
        raw = (text or "").strip()
        low = actions.normalize(raw)

        if self.dictation:
            if low in ("закончи диктовку", "стоп диктовка", "конец диктовки", "выключи диктовку"):
                self.dictation = False
                return "Диктовка окончена."
            actions.type_text(raw, press_enter=False)
            return ""

        woke, cleaned = self._strip_wake_word(raw)
        if woke:
            self.last_active = time.time()
            if not cleaned:
                return "Слушаю, Егор."
            raw = cleaned
        else:
            if not self.pending and (time.time() - self.last_active > self.active_seconds):
                if self._fast_rules(raw) is None:
                    return ""
            self.last_active = time.time()

        if not raw.strip():
            self.last_active = time.time()
            return "Слушаю, Егор."
        ans = self.handle_text(raw, from_voice=True)
        self.last_active = time.time()
        return ans

    # ───────────────────────── точка входа для текста (и голоса) ─────────────────────────
    def handle_text(self, user_text: str, from_voice: bool = False) -> str:
        user_text = database.strip_cjk(user_text or "").strip()
        if not user_text:
            return "Не расслышал команду."
        # Любое обращение к Джарвису (включая текстовое!) активирует таймер голосового диалога
        self.last_active = time.time()

        woke, cleaned = self._strip_wake_word(user_text)
        if woke:
            self.last_active = time.time()
            if not cleaned:
                database.add_message("user", user_text)
                reply = "На связи, Егор! Слушаю вас."
                database.add_message("assistant", reply)
                return reply
            user_text = cleaned

        if self.pending:
            low = actions.normalize(user_text)
            if low in ("да", "конечно", "подтверждаю", "давай", "ок", "окей", "выполняй"):
                return self._exec_pending(confirm=True)
            if low in ("нет", "отмена", "отмени", "стоп", "не надо"):
                desc = self.pending["describe"]
                self.pending = None
                return f"Отменил: {desc}"
            self.pending = None

        return self.process_query(user_text, from_voice=from_voice)

    # ───────────────────────── главная обработка ─────────────────────────
    def process_query(self, user_text: str, from_voice: bool = False) -> str:
        user_text = (user_text or "").strip()
        if not user_text:
            return "Не расслышал команду."

        database.add_message("user", user_text)

        fast = self._fast_rules(user_text)
        if fast is not None:
            self.last_active = time.time()
            clean_fast = database.strip_cjk(fast)
            database.add_message("assistant", clean_fast)
            return clean_fast

        answer = database.strip_cjk(self._llm_agent(user_text))
        if not answer or len(re.findall(r"[а-яА-ЯёЁ]", answer)) < 2:
            answer = "Готово, Егор! Чем ещё могу помочь?"
        self.last_active = time.time()
        database.add_message("assistant", answer)
        return answer

    # ───────────────────────── быстрые правила (регулярки) ─────────────────────────
    def _fast_rules(self, text: str):
        # Убираем случайный повтор одинаковых слов подряд при распознавании речи («открой открой телеграм» -> «открой телеграм»)
        text = re.sub(r"\b([а-яА-ЯёЁa-zA-Z]{2,})\s+\1\b", r"\1", (text or "").strip(), flags=re.IGNORECASE)
        text_clean = text.strip(' ,.!?:;—-…«»"\'')
        t = re.sub(r'[,.!?:;…«»"\']+', " ", actions.normalize(text_clean))
        t = re.sub(r"\s{2,}", " ", t).strip()
        T = self.tools_map
        sp = self.speaker

        # ── 0.1 Стиль Верити / Джарвис (Jarvis-Sound), Цвет, Боковая панель и Кастомные сценарии ──
        if t in (
            "стиль верити", "включи стиль верити", "поставь стиль верити", "режим верити",
            "включи верити", "голос верити", "включи голос верити", "сделай стиль верити", "verity", "стиль verity",
        ) and "change_jarvis_style" in T:
            return T["change_jarvis_style"](style_name="verity")

        if t in (
            "стиль джарвиса", "стиль джарвис", "включи стиль джарвиса", "поставь стиль джарвиса",
            "режим джарвиса", "верни стиль джарвиса", "стиль hud", "стиль железного человека",
        ) and "change_jarvis_style" in T:
            return T["change_jarvis_style"](style_name="jarvis")

        m_style = re.match(
            r"^(?:смени\s+стиль(?:\s+джарвиса)?\s+на|поменяй\s+стиль\s+на|включи\s+стиль|выбери\s+стиль|поставь\s+стиль|стиль)\s+(.+)$",
            t,
        )
        if m_style and "change_jarvis_style" in T:
            return T["change_jarvis_style"](style_name=m_style.group(1).strip())

        if t in ("просканируй пк", "сканируй пк", "просканируй игры", "найди игры стим", "автосканер игр", "обнови список игр", "сканировать игры и программы") and "scan_pc_apps_and_games" in T:
            return T["scan_pc_apps_and_games"]()

        if t in ("перезагрузи плагины", "обнови плагины", "список плагинов", "плагины", "подключи плагины") and "reload_plugins" in T:
            return T["reload_plugins"]()

        if t in ("список микрофонов", "какие микрофоны", "доступные микрофоны", "микрофоны") and "list_microphones" in T:
            return T["list_microphones"]()

        m_mic = re.match(r"^(?:смени\s+микрофон\s+на|выбери\s+микрофон|включи\s+микрофон|микрофон)\s+(.+)$", t)
        if m_mic and "change_microphone" in T and m_mic.group(1).strip() not in ("включи", "выключи"):
            return T["change_microphone"](device_id=m_mic.group(1).strip())

        m_add_ct = re.match(
            r"^(?:добавь|сохрани|создай)\s+контакт\s+([а-яА-ЯёЁa-zA-Z0-9_\-]+)(?:\s+в\s+(телеграм[а-я]*|дискорд[а-я]*|ватсап[а-я]*))?(?:\s+(.+))?$",
            text_clean,
            flags=re.IGNORECASE,
        )
        if m_add_ct and "add_custom_contact" in T:
            c_name = m_add_ct.group(1).strip()
            c_msg = (m_add_ct.group(2) or "телеграм").strip()
            c_usr = (m_add_ct.group(3) or c_name).strip()
            return T["add_custom_contact"](name=c_name, username_or_search=c_usr, messenger=c_msg)

        m_del_ct = re.match(r"^(?:удали|убери)\s+контакт\s+(.+)$", t)
        if m_del_ct and "delete_custom_contact" in T:
            return T["delete_custom_contact"](name=m_del_ct.group(1).strip())

        if t in ("брось монетку", "подбрось монетку", "орел или решка", "монетка") and "coin_flip" in T:
            return T["coin_flip"]()
        if t in ("брось кубик", "кинь кубик", "кубик") and "roll_dice" in T:
            return T["roll_dice"](sides=6)
        if t in ("сгенерируй пароль", "создай пароль", "придумай пароль") and "generate_password" in T:
            return T["generate_password"](length=16)

        m_clip = re.match(r"^(?:фраза|звук|клип|семпл|оригинальная\s+фраза)\s+(?:джарвиса\s+)?(?:номер\s+)?(\d+)$", t)
        if m_clip and "play_jarvis_sound" in T:
            return T["play_jarvis_sound"](clip_number=int(m_clip.group(1)))

        m_color = re.match(
            r"^(?:смени\s+цвет(?:\s+джарвиса)?\s+на|поменяй\s+цвет(?:\s+джарвиса)?\s+на|сделай\s+цвет|поставь\s+цвет|выбери\s+цвет|цвет\s+джарвиса|цвет)\s+(.+)$",
            t,
        )
        if m_color and "change_jarvis_color" in T:
            return T["change_jarvis_color"](color_name=m_color.group(1).strip())
        if t in (
            "голубой цвет", "золотой цвет", "красный цвет", "фиолетовый цвет",
            "зеленый цвет", "зелёный цвет", "изумрудный цвет", "синий цвет", "розовый цвет", "алый цвет",
        ) and "change_jarvis_color" in T:
            return T["change_jarvis_color"](color_name=t.split()[0])

        if t in ("открой боковую панель", "покажи боковую панель", "открой меню", "боковая панель", "открой панель функций"):
            fn_sb = actions.RUNTIME.get("toggle_sidebar")
            if fn_sb:
                fn_sb(True)
            return "Боковая панель функций открыта."
        if t in ("закрой боковую панель", "скрой боковую панель", "закрой меню", "скрой меню", "убери боковую панель"):
            fn_sb = actions.RUNTIME.get("toggle_sidebar")
            if fn_sb:
                fn_sb(False)
            return "Боковая панель скрыта."

        # Создание кастомного сценария голосом или текстом (с двоеточием, словом «шаги» или сразу с действиями «открой...»!)
        m_add_sc = re.match(
            r"^(?:создай|добавь|сохрани|сделай)\s+(?:новый\s+|свой\s+|кастомный\s+)?сценарий\s+(.+?)(?:\s*[:：]\s*|\s+с\s+шагами\s+|\s+шаги\s+|\s+где\s+нужно\s+|\s+который\s+)(.+)$",
            text_clean,
            flags=re.IGNORECASE,
        )
        if m_add_sc and "add_custom_scenario" in T:
            return T["add_custom_scenario"](name=m_add_sc.group(1).strip(), steps_text=m_add_sc.group(2).strip())

        m_add_sc_natural = re.match(
            r"^(?:создай|добавь|сохрани|сделай)\s+(?:новый\s+|свой\s+|кастомный\s+)?сценарий\s+([а-яА-ЯёЁa-zA-Z0-9_\-\s]{1,32}?)\s+((?:открой|запусти|включи|громкость|яркость|сверни|скажи|напиши|сайт|приложение)\s+.+)$",
            text_clean,
            flags=re.IGNORECASE,
        )
        if m_add_sc_natural and "add_custom_scenario" in T:
            return T["add_custom_scenario"](name=m_add_sc_natural.group(1).strip(), steps_text=m_add_sc_natural.group(2).strip())

        m_del_sc = re.match(
            r"^(?:удали|удалить|убери|сотри)\s+(?:ненужный\s+)?сценарий\s+(.+)$",
            t,
        )
        if m_del_sc and "delete_custom_scenario" in T:
            return T["delete_custom_scenario"](name=m_del_sc.group(1).strip())

        # ── 0. Смена голоса Джарвиса, Автозапуск и Управление терминалом ──
        if t in ("какие модели ии есть", "список моделей ии", "какая модель ии", "какая нейросеть подключена", "модели ии", "обнови модели ии"):
            avail = self.get_available_models()
            return f"Установленные локальные ИИ-модели ({len(avail)}): {', '.join(avail)}. Сейчас активна: {self.model}."
        m_ai = re.match(r"(?:смени\s+модель\s+ии\s+на|подключи\s+модель|выбери\s+модель\s+ии)\s+(.+)", t)
        if m_ai:
            q_m = m_ai.group(1).strip().lower()
            avail = self.get_available_models()
            hit = next((m for m in avail if q_m in m.lower()), None)
            if hit:
                self.model = hit
                return f"Переключился на локальную ИИ-модель «{self.model}»."
            return f"Модель «{q_m}» не найдена среди установленных ({', '.join(avail)})."

        if t in ("запусти ai ревью", "запусти ии ревью", "ai ревью", "ии ревью", "проведи ревью", "запусти ревью", "самодиагностика", "диагностика системы"):
            if "run_ai_review" in T:
                return T["run_ai_review"]()
        if t in ("какая модель слуха", "какая модель распознавания", "статус слуха", "статус микрофона", "модель распознавания"):
            if "stt_status" in T:
                return T["stt_status"]()
        if t in ("смени голосовую модель распознавания", "смени голосовую модель распознания", "смени модель распознавания", "смени модель слуха", "поменяй модель слуха"):
            if "change_stt_model" in T:
                return T["change_stt_model"](model_name="multipath_pro")
        m_stt = re.match(r"(?:смени\s+(?:голосовую\s+)?модель\s+(?:слуха|распознавания|распознания)\s+на|включи\s+модель\s+(?:слуха|распознавания|распознания)|модель\s+(?:слуха|распознавания)|переключи\s+слух\s+на)\s+(.+)", t)
        if m_stt and "change_stt_model" in T:
            return T["change_stt_model"](model_name=m_stt.group(1).strip())
        if t in ("включи виспер турбо", "включи whisper turbo", "модель турбо"):
            if "change_stt_model" in T:
                return T["change_stt_model"](model_name="turbo")
        if t in ("включи виспер смол", "включи whisper small", "модель смол", "модель small"):
            if "change_stt_model" in T:
                return T["change_stt_model"](model_name="small")

        if t in ("какие есть голоса", "список голосов", "доступные голоса", "какой сейчас голос", "голоса джарвиса"):
            if "list_voices" in T:
                return T["list_voices"]()
        if t in ("следующий голос", "поменяй голос", "смени голос", "другой голос", "переключи голос"):
            if "next_voice" in T:
                return T["next_voice"]()
        if t in ("оригинальный голос", "оригинальный голос джарвиса", "голос джарвиса", "голос джарвис", "верни голос джарвиса", "голос как в фильме"):
            if "change_voice" in T:
                return T["change_voice"](voice_name="jarvis")
        if t in ("женский голос", "включи женский голос", "голос пятницы", "голос пятница", "голос светлана"):
            if "change_voice" in T:
                return T["change_voice"](voice_name="friday")
        if t in ("мужской голос", "включи мужской голос", "приятный мужской голос", "голос дмитрий"):
            if "change_voice" in T:
                return T["change_voice"](voice_name="dmitry")
        m = re.match(r"(?:смени\s+голос\s+на|поменяй\s+голос\s+на|включи\s+голос|поставь\s+голос|выбери\s+голос|голос)\s+(.+)", t)
        if m and "change_voice" in T:
            v_arg = m.group(1).strip()
            if v_arg not in ("включи", "выключи", "громче", "тише"):
                return T["change_voice"](voice_name=v_arg)

        if t in ("включи автозапуск", "почини автозапуск", "исправь автозапуск", "добавь в автозагрузку", "поставь в автозапуск", "автозапуск включи", "настрой автозапуск"):
            if "enable_autostart" in T:
                return T["enable_autostart"]()
        if t in ("выключи автозапуск", "отключи автозапуск", "убери из автозагрузки", "удали автозапуск"):
            if "disable_autostart" in T:
                return T["disable_autostart"]()
        if t in ("проверь автозапуск", "статус автозапуска", "работает ли автозапуск", "автозапуск"):
            if "autostart_status" in T:
                return T["autostart_status"]()

        if t in ("сверни терминал", "сверни консоль", "скрой терминал", "убери терминал", "спрячь терминал"):
            if "minimize_terminal" in T:
                return T["minimize_terminal"]()
        if t in ("покажи терминал", "открой терминал", "разверни терминал", "покажи консоль", "открой консоль", "разверни консоль"):
            if "restore_terminal" in T:
                return T["restore_terminal"]()

        # ── 1. Стоп / Голос Джарвиса / Диктовка / Выход ──
        if t in ("стоп", "остановись", "хватит", "останови сценарий", "прерви сценарий"):
            return self.stop_all()
        if t in ("помолчи", "замолчи", "не говори", "молчи", "выключи голос"):
            if sp:
                sp.muted = True
            return "Молчу."
        if t in ("говори", "включи голос", "голос включи", "разрешаю говорить"):
            if sp:
                sp.muted = False
            return "Голосовой модуль активен."
        if t.startswith("скажи "):
            phrase = text[6:].strip()
            if sp:
                sp.say(phrase, force=True)
            return phrase
        if t in ("повтори", "повтори что сказал", "что ты сказал"):
            if sp and sp.last:
                sp.say(sp.last, force=True)
                return sp.last
            return "Мне нечего повторять."

        if t in ("начни диктовку", "диктовка", "режим диктовки", "включи диктовку"):
            self.dictation = True
            return "Диктуйте. Скажите «закончи диктовку», чтобы остановить."
        if t in ("закончи диктовку", "стоп диктовка", "конец диктовки", "выключи диктовку"):
            self.dictation = False
            return "Диктовка окончена."

        if t in ("выход", "заверши работу", "закройся", "выключи джарвиса", "закрой джарвис"):
            import os
            os._exit(0)

        # ── 2. Приветствия и быстрые ответы ──
        if t in ("привет", "здравствуй", "здравствуйте", "здарова", "здорово", "хай", "хеллоу",
                 "приветствую", "салют", "добрый день"):
            return "Привет, Егор! Все системы в норме. Чем могу помочь?"
        if t in ("ты тут", "ты здесь", "на связи", "проверка связи", "слышишь меня"):
            return "На связи, Егор! Слушаю вас."
        if t in ("как дела", "как ты", "как жизнь", "как сам", "что нового"):
            return "Все системы функционируют отлично! Готов открывать чаты, запускать игры и выполнять сценарии."
        if t in ("спасибо", "благодарю", "отлично", "красава", "молодец", "супер", "хорош"):
            return "Всегда к вашим услугам, Егор!"
        if t in ("кто ты", "что ты умеешь", "помощь", "справка", "команды", "список команд"):
            return (
                "Я Джарвис — ваш голосовой помощник. Умею:\n"
                "• Открывать чаты и отправлять сообщения в Telegram и Discord («открой чат с Даней», «напиши Варе привет»)\n"
                "• Запускать игры, программы, сайты, VPN и обход («открой дискорд», «включи обход», «запусти кс»)\n"
                "• Выполнять сценарии («сценарий игровой вечер», «режим работа», «помодоро»)\n"
                "• Управлять звуком, яркостью, окнами, таймерами, питанием ПК и файлами."
            )
        if t in ("какие есть сценарии", "список сценариев", "покажи сценарии", "все сценарии"):
            names = list(self.scenarios.keys())
            return f"Доступно сценариев ({len(names)}): " + ", ".join(names[:30]) + ("…" if len(names) > 30 else "")

        # ── 3. Время, Система, Диагностика, Таймеры, Калькулятор, Память ──
        if t in ("который час", "сколько времени", "время", "какое время", "дата", "какая сегодня дата", "какой сегодня день"):
            return T["current_time"]()
        if t in ("состояние системы", "системная информация", "состояние компьютера", "состояние пк",
                 "ресурсы", "нагрузка системы", "загрузка процессора"):
            return T["system_info"]()
        if t in ("топ процессов", "какие процессы грузят систему", "процессы", "что грузит пк", "диспетчер процессов"):
            if "top_processes" in T:
                return T["top_processes"]()
        if t in ("проверь интернет", "состояние сети", "мой айпи", "какой айпи", "пинг", "есть ли интернет"):
            if "network_info" in T:
                return T["network_info"]()
        if t in ("очисти корзину", "очистить корзину"):
            if "empty_recycle_bin" in T:
                return T["empty_recycle_bin"]()
        if t in ("очисти временные файлы", "почисти кэш", "очисти темп"):
            if "clean_temp" in T:
                return T["clean_temp"]()

        if t in ("активные таймеры", "сколько осталось на таймере", "сколько осталось", "список таймеров", "таймеры"):
            if "list_timers" in T:
                return T["list_timers"]()
        if t in ("отмени таймер", "отмени таймеры", "сбрось таймер", "останови таймер", "выключи таймер"):
            if "cancel_timers" in T:
                return T["cancel_timers"]()
        m = re.match(r"(?:поставь\s+)?(?:таймер|будильник)\s+(?:на\s+)?(.+)", t)
        if m and "set_timer" in T:
            dur = actions.parse_duration_seconds(m.group(1))
            if dur:
                return T["set_timer"](seconds=dur, label="Таймер")
        m = re.match(r"напомни\s+через\s+(.+)", t)
        if m and "set_timer" in T:
            rest = m.group(1)
            dur = actions.parse_duration_seconds(rest)
            if dur:
                label = re.sub(
                    r"^(?:\d+|один|одну|два|две|три|четыре|пять|шесть|семь|восемь|девять|десять|"
                    r"пятнадцать|двадцать|тридцать|сорок|пятьдесят|шестьдесят|полчаса|полминуты)\s*"
                    r"(?:час(?:а|ов)?|ч|мин(?:ут(?:ы|у)?)?|м|сек(?:унд(?:ы|у)?)?|с)?\s*",
                    "",
                    rest,
                ).strip() or "Напоминание"
                return T["set_timer"](seconds=dur, label=label)

        m = re.match(r"(?:посчитай|вычисли|сколько\s+будет|калькулятор)\s+(.+)", t)
        if m and "calculate" in T:
            return T["calculate"](expression=m.group(1))

        if t in ("что ты помнишь", "твоя память", "что ты знаешь обо мне", "мои факты"):
            return T["list_facts"]()
        if t in ("очисти историю", "забудь диалог", "сбрось историю"):
            database.clear_history()
            return "История диалога очищена."
        m = re.match(r"запомни\s+(?:что\s+)?(?!выделенное\b)(.+)", t)
        if m:
            return T["remember_fact"](fact=m.group(1))

        # ── 4. Управление питанием ──
        if t in ("заблокируй компьютер", "заблокируй пк", "блокировка", "залочь", "заблокируй", "заблокируй экран"):
            return T["power"](action="lock")
        if t in ("отмени выключение", "отмена выключения", "не выключай компьютер"):
            return T["power"](action="cancel")
        if t in ("выключи компьютер", "выключи пк", "выключи комп", "заверши работу пк", "выключи систему", "отключи пк"):
            return T["power"](action="shutdown", delay_seconds=0)
        if t in ("перезагрузи компьютер", "перезагрузи пк", "перезагрузи комп", "перезагрузка", "ребут", "перезапусти пк"):
            return T["power"](action="restart", delay_seconds=0)
        if t in ("спящий режим", "усни", "включи спящий режим", "уйди в сон"):
            return T["power"](action="sleep")
        if t in ("гибернация", "зимовка", "включи гибернацию", "режим гибернации"):
            return T["power"](action="hibernate")
        if t in ("выйди из системы", "выйди из учетки", "logoff", "разлогинься"):
            return T["power"](action="logoff")

        # ── 5. Громкость, Яркость и Медиа ──
        m = re.match(r"(?:поставь\s+|сделай\s+)?(?:громкость|звук)\s+(?:на\s+)?(.+)", t)
        if m and m.group(1) not in ("вкл", "выкл"):
            num = actions.parse_number(m.group(1))
            if num is not None:
                return T["set_volume"](percent=num)
        m = re.match(r"(?:сделай\s+)?громче(?:\s+на\s+(.+))?$", t)
        if m:
            delta = actions.parse_number(m.group(1)) if m.group(1) else 15
            return T["change_volume"](delta=int(delta or 15))
        m = re.match(r"(?:сделай\s+)?тише(?:\s+на\s+(.+))?$", t)
        if m:
            delta = actions.parse_number(m.group(1)) if m.group(1) else 15
            return T["change_volume"](delta=-int(delta or 15))
        if t in ("выключи звук", "mute", "без звука", "отключи звук", "заглуши звук"):
            return T["mute_sound"](muted=True)
        if t in ("включи звук", "вруби звук", "звук вкл", "верни звук"):
            return T["mute_sound"](muted=False)
        if t in ("сколько громкость", "какая громкость", "уровень громкости"):
            return T["get_volume"]()

        m = re.match(r"(?:поставь\s+|сделай\s+)?яркость\s+(?:на\s+)?(.+)", t)
        if m:
            num = actions.parse_number(m.group(1))
            if num is not None:
                return T["set_brightness"](percent=num)
        m = re.match(r"(?:сделай\s+)?ярче(?:\s+на\s+(.+))?$", t)
        if m:
            delta = actions.parse_number(m.group(1)) if m.group(1) else 15
            return T["change_brightness"](delta=int(delta or 15))
        m = re.match(r"(?:сделай\s+)?темнее(?:\s+на\s+(.+))?$", t)
        if m:
            delta = actions.parse_number(m.group(1)) if m.group(1) else 15
            return T["change_brightness"](delta=-int(delta or 15))

        if t in ("пауза", "поставь на паузу", "продолжи", "play", "пауза видео", "плей", "воспроизведи"):
            return T["media_control"](action="playpause")
        if t in ("следующий трек", "следующий", "вперед трек", "next", "скип", "дальше трек"):
            return T["media_control"](action="next")
        if t in ("предыдущий трек", "предыдущий", "назад трек", "previous", "прошлый трек"):
            return T["media_control"](action="previous")

        # Приоритетная проверка на папки и блокноты (чтобы «напиши в блокнот ...» не перехватывалось мессенджером или общим вводом)
        if any(w in t for w in ("папк", "блокнот", "заметк", "текстовый", "файл", "в него", "туда")):
            fn_early = self._handle_folder_and_notepad_rules(text_clean, t)
            if fn_early is not None:
                return fn_early

        # ── 6. Telegram и Мессенджеры: ОТКРЫТИЕ ЧАТОВ И ОТПРАВКА СООБЩЕНИЙ ──
        if t in ("открой избранное", "открой избранное в телеграм", "открой избранное в телеграме",
                 "открой избранное в тг", "избранное в телеграм", "избранное в телеграме",
                 "открой сохраненки", "покажи избранное"):
            if "open_chat" in T:
                return T["open_chat"](contact="избранное", messenger="телеграм")

        m = re.match(
            r"(?:открой|открыть|покажи|зайди\s+в|перейди\s+в|включи|найди)\s+"
            r"(?:чат|переписку|диалог|лс|личку|группу|канал|беседу)\s+(.+)",
            t,
        )
        if m and "open_chat" in T:
            return self._open_chat_rule(m.group(1))

        m = re.match(
            r"(?:открой|открыть|покажи|зайди|перейди)\s+(?:в\s+)?"
            r"(телеграм[а-я]*|телегу|телеге|тг|telegram|дискорд[а-я]*|дис|discord|ватсап[а-я]*|вацап[а-я]*|whatsapp)\s+"
            r"(.+)",
            t,
        )
        if m and "open_chat" in T:
            return self._open_chat_rule(m.group(2), messenger_hint=m.group(1))

        m = re.match(r"^(?:чат|переписка|диалог)\s+(?:с\s+|со\s+)?(.+)", t)
        if m and "open_chat" in T:
            return self._open_chat_rule(m.group(1))

        m = re.match(r"(?:напиши|отправь|пиши)\s+(?:в\s+этот\s+чат|в\s+текущий\s+чат|сюда)\s+(.+)", text, flags=re.IGNORECASE)
        if m and "send_to_current_chat" in T:
            msg_txt = m.group(1).strip()
            return self._maybe_confirm("send_to_current_chat", {"text": msg_txt}, f"Отправить в текущий чат: «{msg_txt}»")

        m = re.match(
            r"(?:напиши|отправь|пиши|написать|отправить|скинь|черкани)\s+(?:сообщение\s+)?(?:в\s+|по\s+|через\s+)?"
            r"(телеграм[а-я]*|телегу|телеге|тг|telegram|дискорд[а-я]*|дис|discord|ватсап[а-я]*|вацап[а-я]*|вотсап[а-я]*|whatsapp)\s+"
            r"(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "send_message" in T:
            return self._send_message_rule(m.group(1), m.group(2))

        m = re.match(
            r"(?:напиши|отправь|пиши|написать|отправить|скинь|черкани)\s+(?:сообщение\s+)?"
            r"(.+?)\s+(?:в|по|через)\s+"
            r"(телеграм[а-я]*|телегу|телеге|тг|telegram|дискорд[а-я]*|дис|discord|ватсап[а-я]*|вацап[а-я]*|вотсап[а-я]*|whatsapp)\s+"
            r"(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "send_message" in T:
            contact_part = m.group(1).strip()
            m_raw = m.group(2).strip()
            msg_part = re.sub(r"^(?:текст|что|сообщение)\s+", "", m.group(3).strip(), flags=re.IGNORECASE).strip()
            mname = messenger.resolve_messenger(m_raw) or "телеграм"
            return self._maybe_confirm(
                "send_message",
                {"messenger": mname, "contact": contact_part, "text": msg_part},
                messenger.describe_send({"messenger": mname, "contact": contact_part, "text": msg_part}),
            )

        m = re.match(
            r"(?:напиши|отправь|пиши|скинь|черкани)\s+сообщение\s+(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "send_message" in T:
            return self._send_message_rule("телеграм", m.group(1).strip(), auto_detect_messenger=True)

        m = re.match(r"(?:напиши|отправь|черкани|скинь)\s+(.+)", text, flags=re.IGNORECASE)
        if m and "send_message" in T:
            rest_candidate = m.group(1).strip()
            sep = re.search(r"\s+(?:текст|что|сообщение)\s+", rest_candidate, flags=re.IGNORECASE)
            if sep:
                c_cand = rest_candidate[:sep.start()].strip()
                t_cand = rest_candidate[sep.end():].strip()
                if messenger.is_known_contact(c_cand):
                    mname = messenger.detect_contact_messenger(c_cand)
                    return self._maybe_confirm(
                        "send_message",
                        {"messenger": mname, "contact": c_cand, "text": t_cand},
                        messenger.describe_send({"messenger": mname, "contact": c_cand, "text": t_cand}),
                    )
            else:
                pair = messenger.split_contact_text(None, rest_candidate)
                if pair:
                    real_contact, msg_txt = pair
                    mname = messenger.detect_contact_messenger(real_contact)
                    return self._maybe_confirm(
                        "send_message",
                        {"messenger": mname, "contact": real_contact, "text": msg_txt},
                        messenger.describe_send({"messenger": mname, "contact": real_contact, "text": msg_txt}),
                    )

        # ── 7. VPN (Happ) и Обход блокировок (ALT13) ──
        if t in ("включи впн", "запусти впн", "открой впн", "включи happ", "запусти happ", "открой happ"):
            return T["open_app"](name="впн")
        if t in ("выключи впн", "останови впн", "закрой впн", "выключи happ", "останови happ"):
            if "run_shell" in T:
                return self._maybe_confirm("run_shell", {"command": "taskkill /IM happ.exe /F"}, "Остановить happ.exe?")
            return T["close_app"](name="впн")

        if t in ("включи обход", "запусти обход", "открой обход",
                 "включи alt13", "запусти alt13", "открой alt13",
                 "разблокируй дискорд", "подготовь дискорд"):
            return T["open_app"](name="обход")
        if t in ("выключи обход", "останови обход", "закрой обход", "выключи alt13", "останови alt13"):
            if "run_shell" in T:
                return self._maybe_confirm("run_shell", {"command": "taskkill /IM winws.exe /F"}, "Остановить winws.exe?")
            return "Не могу выполнить shell-команду."

        # ── 8. Игровой ввод (DirectInput) ──
        if t in ("включи игровой ввод", "игровой ввод", "game input"):
            actions.STATE["game_input"] = True
            return "Игровой ввод включён (DirectInput)."
        if t in ("выключи игровой ввод", "обычный ввод"):
            actions.STATE["game_input"] = False
            return "Игровой ввод выключен."

        # ── 9. Сценарии (с поддержкой «сценарий X», «режим X», прямого имени и «включи/запусти <сценарий>») ──
        m = re.match(
            r"(?:сценарий|режим|сцена|включи\s+режим|включи\s+сценарий|запусти\s+сценарий|запусти\s+режим)\s+(.+)",
            t,
        )
        if m:
            return self.run_scenario(m.group(1))

        # Прямое название сценария или алиас («игровой вечер», «играем в кс», «помодоро», «тишина»)
        direct_scen = self._resolve_scenario_key(t, allow_fuzzy=False)
        if direct_scen:
            return self.run_scenario(direct_scen)

        # Команды вида «включи игровой вечер», «запусти стрим», «включи тишину», «запусти помодоро»
        # (проверяем, не является ли цель именем сценария, если это не базовое приложение/папка)
        m_verb_scen = re.match(r"(?:включи|запусти|активируй|поставь|давай)\s+(.+)", t)
        if m_verb_scen:
            cand_scen = m_verb_scen.group(1).strip()
            # Не перехватываем имена базовых приложений/игр при простом «открой/запусти кс»
            app_names = {actions.normalize(k) for k in (self.cfg.get("apps") or {})}
            for v in (self.cfg.get("apps") or {}).values():
                app_names.update(actions.normalize(a) for a in (v or {}).get("aliases", []))
            steam_names = {actions.normalize(k) for k in (self.cfg.get("steam_apps") or {})}
            for v in (self.cfg.get("steam_apps") or {}).values():
                steam_names.update(actions.normalize(a) for a in (v or {}).get("aliases", []))

            if cand_scen not in app_names and cand_scen not in steam_names:
                scen_key = self._resolve_scenario_key(cand_scen, allow_fuzzy=False)
                if scen_key:
                    return self.run_scenario(scen_key)

        # ── 10. Папки, Файлы, Сайты и Поиск ──
        if t in ("открой рабочий стол", "открой десктоп", "рабочий стол открой"):
            return T["open_path"](path="рабочий стол")
        if t in ("открой загрузки", "покажи загрузки", "открой папку загрузки"):
            return T["open_path"](path="загрузки")
        if t in ("открой документы", "покажи документы", "открой папку документы"):
            return T["open_path"](path="документы")
        if t in ("открой картинки", "покажи картинки", "открой изображения"):
            return T["open_path"](path="картинки")
        if t in ("открой видео", "покажи видео"):
            return T["open_path"](path="видео")
        if t in ("открой музыку", "покажи музыку"):
            return T["open_path"](path="музыка")

        m = re.match(r"(?:покажи\s+содержимое|что\s+в\s+папке|содержимое|показывай)\s+(.+)", t)
        if m and "list_dir" in T:
            return T["list_dir"](path=m.group(1))
        m = re.match(r"(?:открой\s+папку|открой\s+файл|покажи\s+папку)\s+(.+)", t)
        if m and "open_path" in T:
            return T["open_path"](path=m.group(1))
        m = re.match(r"(?:найди\s+файл|найди\s+файлы|поиск\s+файла)\s+(.+)", t)
        if m and "find_files" in T:
            return T["find_files"](query=m.group(1))

        # Умная обработка всех команд создания папок, блокнотов на Рабочем столе и записи текста в них
        fn_res = self._handle_folder_and_notepad_rules(text_clean, t)
        if fn_res is not None:
            return fn_res

        m = re.match(r"(?:открой|запусти|включи)\s+(?:сайты|сайт|вкладки|вкладку)\s+(.+)", text_clean, flags=re.IGNORECASE)
        if m:
            return T["open_site"](name=m.group(1).strip())
        m = re.match(r"(?:найди\s+в\s+ютубе|поищи\s+в\s+ютубе|ютуб\s+найди)\s+(.+)", t)
        if m:
            return T["web_search"](query=m.group(1), engine="youtube")
        m = re.match(r"(?:загугли|найди\s+в\s+гугле|поищи\s+в\s+интернете|найди\s+в\s+интернете)\s+(.+)", t)
        if m:
            return T["web_search"](query=m.group(1), engine="google")
        m = re.match(r"(?:найди\s+в\s+яндексе|поищи\s+в\s+яндексе)\s+(.+)", t)
        if m:
            return T["web_search"](query=m.group(1), engine="yandex")
        m = re.match(r"(?:найди\s+на\s+карте|покажи\s+на\s+карте|карта)\s+(.+)", t)
        if m:
            return T["web_search"](query=m.group(1), engine="maps")
        m = re.match(r"(?:расскажи\s+про|что\s+такое|кто\s+такой|кто\s+такая)\s+(.+)", t)
        if m and "wikipedia" in T:
            return T["wikipedia"](query=m.group(1))

        # ── 11. Управление окнами и Скриншоты ──
        if t in ("закрой это окно", "закрой окно", "закрой активное окно", "закрой текущее окно"):
            return T["press_keys"](keys="alt+f4")
        m = re.match(r"закрой\s+окно\s+(.+)", t)
        if m and "close_app" in T:
            return T["close_app"](name=m.group(1))
        if t in ("сверни все окна", "свернуть все", "покажи рабочий стол", "рабочий стол"):
            return T["minimize_all"]()
        if t in ("сверни окно", "сверни это окно", "сверни текущее окно"):
            if "minimize_window" in T:
                return T["minimize_window"]()
        if t in ("разверни окно", "на весь экран", "разверни на весь экран", "максимизируй окно"):
            if "maximize_window" in T:
                return T["maximize_window"]()
        if t in ("окно влево", "прикрепи окно влево"):
            if "snap_window" in T:
                return T["snap_window"](side="left")
        if t in ("окно вправо", "прикрепи окно вправо"):
            if "snap_window" in T:
                return T["snap_window"](side="right")
        if t in ("переключи окно", "следующее окно", "альт таб"):
            return T["press_keys"](keys="alt+tab")
        if t in ("список окон", "какие окна открыты", "открытые окна"):
            return T["list_open_windows"]()
        m = re.match(r"(?:переключись\s+на(?:\s+окно)?|покажи\s+окно|открой\s+окно|разверни\s+окно|выведи\s+окно|фокус\s+на(?:\s+окно)?|разверни)\s+(.+)", t)
        if m and m.group(1).strip() not in ("на весь экран", "это окно", "текущее окно", "терминал", "консоль"):
            return T["focus_window"](title=m.group(1).strip())

        # ── 11.1 Зрение (Tesseract OCR) и чтение экрана ──
        if t in ("проверь зрение", "статус окр", "статус ocr", "проверь тессеракт", "проверь tesseract", "работает ли окр", "статус зрения"):
            if "ocr_status" in T:
                return T["ocr_status"]()
        if t in ("скриншот", "скриншот экрана", "снимок экрана", "сделай скриншот"):
            return T["take_screenshot"](mode="full")
        if t in ("скриншот области", "область экрана", "вырежь область"):
            return T["take_screenshot"](mode="area")
        if t in ("скриншот окна", "снимок окна"):
            return T["take_screenshot"](mode="window")

        # Интуитивное чтение экрана / окна / области через Tesseract OCR
        if t in (
            "прочитай область", "распознай область", "прочитай выделенную область",
            "выдели и прочитай", "окр области", "ocr области", "распознай выделенное на экране",
        ):
            if "read_screen_text" in T:
                return T["read_screen_text"](area=True)

        if t in (
            "прочитай окно", "прочитай активное окно", "прочитай текущее окно",
            "что написано в окне", "распознай окно", "текст окна", "текст в окне", "что в этом окне",
        ):
            if "read_screen_text" in T:
                return T["read_screen_text"](area=False, window_only=True)

        if t in (
            "прочитай экран", "распознай экран", "распознай текст на экране", "текст с экрана",
            "что написано на экране", "прочитай что на экране", "прочитай текст на экране",
            "окр экрана", "ocr экрана", "сканируй экран", "что тут написано", "что здесь написано",
            "что там написано", "прочитай что тут", "прочитай это", "распознай текст",
        ) or re.search(r"\b(?:прочитай|распознай|прочти|сканируй)\b.*\b(?:экран|монитор|текст|что\s+тут|что\s+здесь|что\s+написано)\b", t):
            if "read_screen_text" in T:
                return T["read_screen_text"](area=False, window_only=False)

        if t in (
            "прочитай чат", "прочитай сообщения", "прочитай сообщения на экране",
            "что мне написали", "что написали в чате", "прочитай переписку",
            "последние сообщения на экране", "что в чате", "что там в чате", "что написали",
        ):
            if "read_chat_on_screen" in T:
                return T["read_chat_on_screen"]()

        if t in (
            "какие кнопки на экране", "что можно нажать", "элементы на экране",
            "список элементов экрана", "кнопки на экране", "видимые кнопки",
            "интерактивные элементы", "куда можно нажать", "покажи элементы экрана",
            "какие кнопки", "покажи кнопки", "пронумеруй кнопки", "что тут можно нажать",
        ) or re.search(r"\b(?:какие|покажи|список)\b.*\b(?:кнопк|элемент|надпис)", t):
            if "list_screen_elements" in T:
                return T["list_screen_elements"]()

        # Интуитивная озвучка текста с экрана вслух
        if t in ("озвучь область", "прочитай вслух область", "выдели и озвучь"):
            if "read_aloud_screen" in T:
                return T["read_aloud_screen"](area=True, window_only=False)
        if t in ("озвучь экран", "прочитай вслух экран", "читай экран вслух", "озвучь что на экране", "прочитай экран вслух"):
            if "read_aloud_screen" in T:
                return T["read_aloud_screen"](area=False, window_only=False)
        if t in (
            "озвучь окно", "прочитай вслух окно", "озвучь активное окно", "прочитай окно вслух",
            "озвучь чат", "озвучь это", "озвучь текст", "прочитай вслух", "читай вслух", "озвучь что тут",
        ):
            if "read_aloud_screen" in T:
                return T["read_aloud_screen"](area=False, window_only=True)

        # Интуитивный перевод текста с экрана через Tesseract OCR
        if t in ("переведи область", "переведи выделенную область", "выдели и переведи"):
            if "translate_screen_text" in T:
                return T["translate_screen_text"](area=True, window_only=False)
        if t in ("переведи экран", "переведи что на экране", "переведи текст на экране", "перевод экрана", "переведи с экрана"):
            if "translate_screen_text" in T:
                return T["translate_screen_text"](area=False, window_only=False)
        if t in (
            "переведи окно", "переведи активное окно", "переведи что в окне", "переведи текущее окно",
            "переведи это", "переведи что тут", "переведи что здесь", "переведи текст", "переведи на русский",
        ):
            if "translate_screen_text" in T:
                return T["translate_screen_text"](area=False, window_only=True)

        # Сохранение текста с экрана в файл
        if t in ("сохрани текст с экрана", "сохрани экран в файл", "сохрани текст с экрана в файл", "запиши текст с экрана в блокнот", "сохрани текст окна"):
            if "save_screen_text_to_file" in T:
                return T["save_screen_text_to_file"](filename="", window_only=("окна" in t))

        # Копирование конкретной строки с экрана по ключевому слову
        m = re.match(r"(?:скопируй\s+строку\s+с|скопируй\s+с\s+экрана(?:\s+строку)?|найди\s+и\s+скопируй\s+на\s+экране)\s+(.+)", text, flags=re.IGNORECASE)
        if m and "copy_line_with_text" in T:
            return T["copy_line_with_text"](query=m.group(1).strip().strip('«»"\''))

        # Подсчёт вхождений слова на экране
        m = re.match(r"(?:сколько\s+раз\s+на\s+экране|посчитай\s+на\s+экране)\s+(.+)", text, flags=re.IGNORECASE)
        if m and "count_text_on_screen" in T:
            return T["count_text_on_screen"](text=m.group(1).strip().strip('«»"\''))

        # Прокрутка до появления текста (scroll_until_text)
        m = re.match(r"(?:листай|прокрути|крути|скролль)\s+(?:вниз\s+)?до\s+(.+?)\s+и\s+(?:нажми|кликни)", text, flags=re.IGNORECASE)
        if m and "scroll_until_text" in T:
            return T["scroll_until_text"](text=m.group(1).strip().strip('«»"\''), direction="down", click=True)
        m = re.match(r"(?:листай|прокрути|крути|скролль)\s+вверх\s+до\s+(.+)", text, flags=re.IGNORECASE)
        if m and "scroll_until_text" in T:
            return T["scroll_until_text"](text=m.group(1).strip().strip('«»"\''), direction="up", click=False)
        m = re.match(r"(?:листай|прокрути|крути|скролль|найди\s+прокруткой)\s+(?:вниз\s+)?(?:до\s+)?(.+)", text, flags=re.IGNORECASE)
        if m and (" до " in f" {t} " or t.startswith(("листай до", "прокрути до", "найди прокруткой"))) and "scroll_until_text" in T:
            return T["scroll_until_text"](text=m.group(1).strip().strip('«»"\''), direction="down", click=False)

        # Ожидание появления кнопки/надписи на экране и автоклик (wait_for_text_on_screen)
        m = re.match(r"(?:дождись|подожди)\s+(.+?)\s+и\s+(?:нажми|кликни)", text, flags=re.IGNORECASE)
        if m and "wait_for_text_on_screen" in T:
            return T["wait_for_text_on_screen"](text=m.group(1).strip().strip('«»"\''), click=True)
        m = re.match(r"(?:нажми\s+когда\s+появится|кликни\s+когда\s+появится|жди\s+кнопку|автоклик\s+на)\s+(.+)", text, flags=re.IGNORECASE)
        if m and "wait_for_text_on_screen" in T:
            return T["wait_for_text_on_screen"](text=m.group(1).strip().strip('«»"\''), click=True)
        m = re.match(r"(?:подожди\s+пока\s+появится|дождись\s+на\s+экране)\s+(.+)", text, flags=re.IGNORECASE)
        if m and "wait_for_text_on_screen" in T:
            return T["wait_for_text_on_screen"](text=m.group(1).strip().strip('«»"\''), click=False)

        # Клик по пронумерованному элементу экрана ([1], [2], [3]...)
        m = re.match(r"(?:нажми|кликни|выбери)\s+(?:кнопку\s+)?(?:элемент|номер)\s+(.+)", t)
        if m and "click_element_by_number" in T:
            num = actions.parse_number(m.group(1))
            if num is not None and num >= 1:
                return T["click_element_by_number"](number=int(num))

        if t in (
            "что на экране", "что у меня на экране", "что сейчас на экране", "а что на экране",
            "что тут на экране", "че на экране", "чё на экране", "опиши экран", "что ты видишь",
            "что видишь на экране", "что видишь", "посмотри на экран", "глянь на экран",
            "осмотри экран", "что у меня открыто", "что сейчас открыто", "что тут открыто",
        ) or re.search(r"\b(?:что|че|чё|опиши|посмотри|глянь)\b.*\b(?:у\s+меня\s+на\s+экране|сейчас\s+на\s+экране|на\s+экране|на\s+мониторе)\b", t):
            if "describe_screen" in T:
                return T["describe_screen"](question="")
        m = re.match(r"(?:посмотри\s+на\s+экран\s+и\s+(?:скажи|ответь)|что\s+на\s+экране\s+с|опиши\s+на\s+экране)\s+(.+)", t)
        if m and "describe_screen" in T:
            return T["describe_screen"](question=m.group(1).strip())

        # ── 12. Буфер обмена, Клавиатура, Мышь и Ввод текста ──
        if t in ("запомни выделенное", "сохрани выделенное"):
            if "remember_selection" in T:
                return T["remember_selection"]()
        if t in ("вставь запомненное", "вставить запомненное"):
            if "paste_remembered" in T:
                return T["paste_remembered"]()
        if t in ("прочитай выделенное", "озвучь выделенное"):
            if "read_selection" in T:
                return T["read_selection"]()
        if t in ("что в буфере", "прочитай буфер", "буфер обмена"):
            return T["clipboard_read"]()
        if t in ("скопируй", "копируй"):
            return T["copy_selection"]()
        if t in ("вставь", "вставить"):
            return T["press_keys"](keys="ctrl+v")
        if t in ("выдели всё", "выдели все", "выделить всё", "выделить все"):
            return T["press_keys"](keys="ctrl+a")
        if t in ("отмени", "отмени действие", "отмена", "undo"):
            return T["press_keys"](keys="ctrl+z")
        if t in ("сохрани", "сохранить"):
            return T["press_keys"](keys="ctrl+s")
        if t in ("вырежи", "вырезать"):
            return T["press_keys"](keys="ctrl+x")

        if t in ("кликни", "клик", "нажми сюда", "левый клик"):
            return T["click_mouse"]()
        if t in ("двойной клик", "дабл клик"):
            return T["click_mouse"](clicks=2)
        if t in ("правый клик", "правая кнопка"):
            return T["click_mouse"](button="right")

        m = re.match(r"(?:прокрут(?:и|ить)?|скролл|скрол|крути)\s+(?:колесо\s+)?(вниз|вверх|down|up)(?:\s+на\s+(.+))?$", t)
        if m:
            amt = actions.parse_number(m.group(2)) if m.group(2) else 5
            amt = int(amt or 5) * (-1 if m.group(1) in ("вниз", "down") else 1)
            return T["scroll_mouse"](amount=amt)
        m = re.match(r"прокрут(?:и|ить)?\s+на\s+(.+?)\s+(вниз|вверх|down|up)$", t)
        if m:
            amt = actions.parse_number(m.group(1)) or 5
            amt = int(amt) * (-1 if m.group(2) in ("вниз", "down") else 1)
            return T["scroll_mouse"](amount=amt)

        # ── 12.1 Взаимодействие с экраном через Tesseract OCR (клик / ввод по тексту) ──
        m = re.match(
            r"(?:введи|напиши|напечатай)\s+в\s+поле\s+(.+?)\s+(?:текст|слово|фразу)\s+(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "click_and_type_on_screen" in T:
            return T["click_and_type_on_screen"](
                target_text=m.group(1).strip().strip('«»"\''),
                input_text=m.group(2).strip(),
                press_enter=True,
            )

        m = re.match(
            r"(?:нажми|кликни)\s+(?:на|по)\s+(.+?)\s+и\s+(?:введи|напиши|напечатай)\s+(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "click_and_type_on_screen" in T:
            return T["click_and_type_on_screen"](
                target_text=m.group(1).strip().strip('«»"\''),
                input_text=m.group(2).strip(),
                press_enter=True,
            )

        m = re.match(
            r"(?:двойной\s+клик|дабл\s+клик|дважды\s+нажми|дважды\s+кликни)\s+(?:на|по)\s+(?:кнопку\s+|надпись\s+|текст\s+)?(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "find_text_on_screen" in T:
            return T["find_text_on_screen"](
                text=m.group(1).strip().strip('«»"\''),
                click=True,
                double_click=True,
            )

        m = re.match(
            r"(?:правый\s+клик|правой\s+кнопкой|пкм|контекстное\s+меню)\s+(?:на|по)\s+(?:кнопку\s+|надпись\s+|текст\s+)?(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "find_text_on_screen" in T:
            return T["find_text_on_screen"](
                text=m.group(1).strip().strip('«»"\''),
                click=True,
                right_click=True,
            )

        m = re.match(
            r"(?:наведи(?:\s+курсор|\s+мышь|\s+мышку)?\s+на)\s+(?:кнопку\s+|надпись\s+|текст\s+)?(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "find_text_on_screen" in T:
            return T["find_text_on_screen"](
                text=m.group(1).strip().strip('«»"\''),
                click=False,
                hover=True,
            )

        m = re.match(
            r"(?:найди\s+на\s+экране|найди\s+текст\s+на\s+экране)\s+(.+?)\s+и\s+(?:нажми|кликни)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "find_text_on_screen" in T:
            return T["find_text_on_screen"](text=m.group(1).strip().strip('«»"\''), click=True)

        m = re.match(
            r"(?:найди\s+на\s+экране|где\s+на\s+экране|есть\s+ли\s+на\s+экране|найди\s+надпись)\s+(.+)",
            text,
            flags=re.IGNORECASE,
        )
        if m and "find_text_on_screen" in T:
            return T["find_text_on_screen"](
                text=m.group(1).strip().strip('«»"\''),
                click=False,
                hover=True,
            )

        m = re.match(r"зажми\s+(.+?)\s+на\s+(.+?)\s+секунд[ыу]?", t)
        if m:
            sec_str = m.group(2).replace(",", ".")
            try:
                secs = float(sec_str)
            except ValueError:
                secs = float(actions.parse_number(sec_str) or 1.0)
            return T["hold_key"](key=m.group(1), seconds=secs)

        # Интуитивный ввод в поиск на экране («напиши в поиск Даня», «введи в поиск музыка»)
        m = re.match(r"(?:напиши|введи|вбей|напечатай)\s+в\s+поиск(?:е)?\s+(.+)", text_clean, flags=re.IGNORECASE)
        if m and "click_and_type_on_screen" in T:
            return T["click_and_type_on_screen"](target_text="Поиск", input_text=m.group(1).strip(), press_enter=True)

        m = re.match(
            r"(?:нажми\s+на|кликни\s+на|кликни\s+по|нажми\s+по|жми\s+на|ткни\s+на|ткни\s+в|тыкни\s+на|выбери\s+на\s+экране|нажми\s+кнопку|кликни\s+кнопку)\s+(?:кнопку\s+|надпись\s+|текст\s+|слово\s+|вкладку\s+)?(.+)",
            text_clean,
            flags=re.IGNORECASE,
        )
        if m and "find_text_on_screen" in T:
            target_txt = m.group(1).strip().strip('«»"\'')
            return T["find_text_on_screen"](text=target_txt, click=True)

        # Интуитивный клик БЕЗ предлога «на»: «нажми Принять», «кликни Отправить», «жми Играть», «выбери Даня»
        m = re.match(r"(?:нажми|кликни|жми|ткни|тыкни|выбери)\s+(.+)", text_clean, flags=re.IGNORECASE)
        if m:
            cand_raw = m.group(1).strip().strip('«»"\'')
            cand_norm = actions.normalize(cand_raw)
            # Проверяем, является ли фраза настоящей клавишей клавиатуры (enter, пробел, f5, ctrl+s, альт ф4)
            key_parts = actions._normalize_keys(cand_norm)
            is_real_key = bool(key_parts) and all(
                (kp in actions.pyautogui.KEYBOARD_KEYS or kp in actions._VK_MAP) for kp in key_parts
            ) and (
                "+" in cand_norm
                or cand_norm in actions._KEY_ALIASES
                or cand_norm in actions.pyautogui.KEYBOARD_KEYS
                or cand_norm in actions._VK_MAP
                or re.match(r"^(?:контрол|контрл|ктрл|ctrl|альт|alt|шифт|shift|вин|win|эф|ф|f)\b", cand_norm)
            )
            if is_real_key and t.startswith("нажми"):
                return T["press_keys"](keys=cand_norm)
            if "find_text_on_screen" in T:
                return T["find_text_on_screen"](text=cand_raw, click=True)

        m = re.match(r"(?:напечатай|введи|напиши\s+текст)\s+(.+)", text_clean, flags=re.IGNORECASE)
        if m:
            txt_payload = m.group(1).strip()
            if actions.STATE.get("last_notepad") and "write_to_notepad" in T:
                return T["write_to_notepad"](text=txt_payload, filename="", append=True)
            return T["type_text"](text=txt_payload, press_enter=False)
        if t.startswith(("напиши ", "запиши ")):
            txt_payload = re.sub(r"^(?:напиши|запиши)\s+", "", text_clean, flags=re.IGNORECASE).strip()
            # Если недавно был создан блокнот или открыт notepad.exe — пишем прямо в блокнот на Рабочем столе!
            if (actions.STATE.get("last_notepad") or actions.APPS.is_running("notepad.exe")) and "write_to_notepad" in T:
                return T["write_to_notepad"](text=txt_payload, filename="", append=True)
            return T["type_text"](text=txt_payload, press_enter=False)

        # ── 13. Steam-игры и Общий запуск/закрытие приложений ──
        m = re.match(r"(?:играй\s+в|сыграем\s+в|игра)\s+(.+)", t)
        if m and "open_steam_game" in T:
            return T["open_steam_game"](name=m.group(1).strip())

        m = re.match(r"(?:открой|запусти|включи|открыть|запустить)\s+(.+)", t)
        if m:
            target = m.group(1).strip()
            steam_apps = self.cfg.get("steam_apps") or {}
            for skey, sinfo in steam_apps.items():
                saliases = [actions.normalize(skey)] + [actions.normalize(a) for a in (sinfo or {}).get("aliases", [])]
                if actions.normalize(target) in saliases and "open_steam_game" in T:
                    return T["open_steam_game"](name=target)
            return T["open_app"](name=target)

        m = re.match(r"(?:закрой|выключи|заверши|убей)\s+(.+)", t)
        if m:
            return T["close_app"](name=m.group(1).strip())

        return None

    # ───────────────────────── папки и блокноты на Рабочем столе ─────────────────────────
    def _handle_folder_and_notepad_rules(self, text_clean: str, t: str):
        T = self.tools_map

        # 1. Комбинированная команда: «создай папку X [на рабочем столе] и (в ней|туда) блокнот Y [и напиши Z]»
        m_combo = re.match(
            r"^(?:создай|сделай)\s+(.*?\bпапк[уаи]\b.+?)\s+и\s+(?:создай\s+)?(?:в\s+ней\s+|внутри\s+|туда\s+)?(?:новый\s+|текстовый\s+)?(?:блокнот|заметку|файл|документ)(?:\s+(.*))?$",
            text_clean,
            flags=re.IGNORECASE,
        )
        if m_combo and "make_dir" in T and "create_notepad" in T:
            folder_part = m_combo.group(1).strip()
            note_part = (m_combo.group(2) or "").strip()
            f_res = self._parse_and_create_folder(folder_part)
            n_res = self._parse_and_create_notepad(note_part, default_folder=actions.STATE.get("last_folder") or "рабочий стол")
            return f"{f_res} {n_res}"

        # 2. Команда «открой/запусти блокнот и напиши/запиши ...»
        m_open_write = re.match(
            r"^(?:открой|запусти|включи)\s+блокнот(?:\s+([а-яА-ЯёЁa-zA-Z0-9_\-]+))?\s+и\s+(?:напиши|запиши|впиши|напечатай)(?:\s+(?:в\s+него|в\s+нем|в\s+нём|туда|текст))?\s+(.+)$",
            text_clean,
            flags=re.IGNORECASE,
        )
        if m_open_write and "write_to_notepad" in T:
            fname = (m_open_write.group(1) or "").strip()
            content = m_open_write.group(2).strip()
            return T["write_to_notepad"](text=content, filename=fname, append=True)

        # 3. Запись / дописывание текста в блокнот или файл:
        #    «напиши в блокнот привет», «запиши в блокноте купить хлеб», «допиши в блокнот задачи молоко»,
        #    «напиши в него привет», «запиши туда 123»
        m_write_pronoun = re.match(
            r"^(?:напиши|запиши|впиши|допиши|добавь|напечатай)\s+(?:в\s+него|в\s+неё|в\s+нее|туда|внутрь)(?:\s+текст)?\s+(.+)$",
            text_clean,
            flags=re.IGNORECASE,
        )
        if m_write_pronoun and "write_to_notepad" in T:
            is_app = t.startswith(("допиши", "добавь"))
            return T["write_to_notepad"](text=m_write_pronoun.group(1).strip(), filename="", append=is_app or True)

        m_write_np = re.match(
            r"^(?:напиши|запиши|впиши|допиши|добавь|напечатай|сохрани)\s+(?:текст\s+)?(?:в|во)\s+(?:этот\s+|открытый\s+|текущий\s+|созданный\s+)?(?:блокнот(?:е|у)?|заметк(?:у|е)|текстовый\s+файл|файл(?:е)?)\s*(.*)$",
            text_clean,
            flags=re.IGNORECASE,
        )
        if m_write_np and "write_to_notepad" in T:
            rest = (m_write_np.group(1) or "").strip()
            if not rest:
                return "Что именно записать в блокнот?"
            is_app = t.startswith(("допиши", "добавь"))
            # Проверяем явный разделитель: «запиши в блокнот задачи: купить молоко» или «запиши в блокнот задачи текст купить молоко»
            sep = re.search(r"(?:\s*[:：]\s*|\s+(?:текст|содержимое|слова|фразу)\s+)", rest, flags=re.IGNORECASE)
            if sep:
                cand_fn = rest[:sep.start()].strip()
                content = rest[sep.end():].strip()
                # Если cand_fn — просто «на рабочем столе», то имя файла не указано
                if actions.normalize(cand_fn) in ("на рабочем столе", "рабочий стол", "на десктопе"):
                    cand_fn = ""
                return T["write_to_notepad"](text=content, filename=cand_fn, append=True if is_app else False)

            # Проверяем, не начинается ли фраза с имени уже существующего .txt файла на Рабочем столе
            words = rest.split()
            if len(words) >= 2:
                desk = actions.get_real_desktop_path()
                for n_w in (2, 1):
                    if len(words) > n_w:
                        cand_name = " ".join(words[:n_w])
                        cand_clean = actions.sanitize_win_name(cand_name)
                        if cand_clean and os.path.isfile(os.path.join(desk, cand_clean + ".txt")):
                            content = " ".join(words[n_w:]).strip()
                            return T["write_to_notepad"](text=content, filename=cand_clean, append=True)

            # Иначе весь rest — это сам текст, который нужно записать в блокнот!
            return T["write_to_notepad"](text=rest, filename="", append=True)

        # 4. Создание блокнота / заметки / текстового файла (в любом порядке слов, с текстом или без!)
        if re.match(r"^(?:создай|сделай|открой\s+новый|добавь)\b", t) and any(
            w in t for w in ("блокнот", "заметк", "текстовый файл", "текстовый документ", "файл")
        ):
            return self._parse_and_create_notepad(text_clean)

        if t in ("новый блокнот", "новая заметка", "блокнот на рабочем столе"):
            return self._parse_and_create_notepad(text_clean)

        # 5. Создание папки (в любом порядке слов: «создай папку», «создай папку на рабочем столе», «создай на рабочем столе папку Х», «создай папку Х на рабочем столе»)
        if re.match(r"^(?:создай|сделай|добавь)\b", t) and any(w in t for w in ("папк", "директори", "каталог")):
            return self._parse_and_create_folder(text_clean)

        if t in ("новая папка", "папка на рабочем столе", "новую папку"):
            return self._parse_and_create_folder(text_clean)

        return None

    def _parse_and_create_folder(self, raw_phrase: str) -> str:
        T = self.tools_map
        s = (raw_phrase or "").strip()
        s_low = actions.normalize(s)

        base = "рабочий стол"
        if "в загрузках" in s_low or "в загрузки" in s_low or "папке загрузки" in s_low:
            base = "загрузки"
        elif "в документах" in s_low or "в документы" in s_low or "папке документы" in s_low:
            base = "документы"
        elif ("в этой папке" in s_low or "в ней" in s_low) and actions.STATE.get("last_folder"):
            base = actions.STATE["last_folder"]

        # Вырезаем глаголы, локации и служебные слова в любом месте фразы
        cleaned = re.sub(
            r"^(?:создай|сделай|добавь)\s+",
            "",
            s,
            flags=re.IGNORECASE,
        ).strip()
        cleaned = re.sub(
            r"\b(?:на\s+рабочем\s+столе|на\s+рабочий\s+стол|в\s+рабочем\s+столе|рабочем\s+столе|рабочий\s+стол|"
            r"на\s+десктопе|в\s+загрузках|в\s+загрузки|в\s+документах|в\s+документы|в\s+этой\s+папке|в\s+ней|"
            r"новую\s+папку|новая\s+папка|папку|папка|директорию|каталог|"
            r"с\s+названием|под\s+названием|по\s+имени|с\s+именем|назови\s+её|назови\s+ее|назови)\b",
            " ",
            cleaned,
            flags=re.IGNORECASE,
        )
        folder_name = actions.sanitize_win_name(cleaned)
        if not folder_name:
            return T["make_dir"](path=base)
        return T["make_dir"](path=f"{base}\\{folder_name}")

    def _parse_and_create_notepad(self, raw_phrase: str, default_folder: str = "рабочий стол") -> str:
        T = self.tools_map
        s = (raw_phrase or "").strip()

        # Убираем ведущий глагол «создай / сделай / добавь»
        s = re.sub(r"^(?:создай|сделай|добавь|открой\s+новый)\s+", "", s, flags=re.IGNORECASE).strip()

        # Проверяем, есть ли во фразе команда сразу записать внутрь текст:
        # «... и напиши [в него/туда] <текст>», «... с текстом <текст>», «... : <текст>»
        content = ""
        left_part = s
        sep_match = re.search(
            r"(?:\s+и\s+(?:напиши|запиши|впиши|добавь|напечатай)(?:\s+(?:в\s+него|в\s+неё|в\s+нее|в\s+нем|в\s+нём|туда|внутрь|внутри|в\s+блокнот|текст))?\s+|"
            r"\s+с\s+(?:текстом|содержимым|надписью|словами)\s+|"
            r"\s*[:：]\s+)",
            s,
            flags=re.IGNORECASE,
        )
        if sep_match:
            left_part = s[:sep_match.start()].strip()
            content = s[sep_match.end():].strip()

        lp_low = actions.normalize(left_part)
        folder = default_folder
        if "в загрузках" in lp_low or "в загрузки" in lp_low:
            folder = "загрузки"
        elif "в документах" in lp_low or "в документы" in lp_low:
            folder = "документы"
        elif ("в этой папке" in lp_low or "в ней" in lp_low or "в созданной папке" in lp_low) and actions.STATE.get("last_folder"):
            folder = actions.STATE["last_folder"]
        else:
            # Проверяем конструкцию «в папке <ИмяПапки>»
            m_in_dir = re.search(r"\bв\s+папке\s+([а-яА-ЯёЁa-zA-Z0-9_\-]+)", left_part, flags=re.IGNORECASE)
            if m_in_dir:
                cand_sub = actions.sanitize_win_name(m_in_dir.group(1))
                if cand_sub and actions.normalize(cand_sub) not in ("рабочий", "стол"):
                    folder = f"рабочий стол\\{cand_sub}"
                    left_part = (left_part[:m_in_dir.start()] + " " + left_part[m_in_dir.end():]).strip()

        # Очищаем имя файла от служебных слов и локаций
        name_clean = re.sub(
            r"\b(?:на\s+рабочем\s+столе|на\s+рабочий\s+стол|в\s+рабочем\s+столе|рабочем\s+столе|рабочий\s+стол|"
            r"на\s+десктопе|в\s+загрузках|в\s+загрузки|в\s+документах|в\s+документы|в\s+этой\s+папке|в\s+ней|внутри|"
            r"новый\s+текстовый|текстовый\s+документ|текстовый\s+файл|новый\s+блокнот|новую\s+заметку|новый\s+файл|"
            r"блокнот|заметку|заметка|документ|файл|"
            r"с\s+названием|под\s+названием|по\s+имени|с\s+именем|назови\s+его|назови\s+её|назови)\b",
            " ",
            left_part,
            flags=re.IGNORECASE,
        )
        name_clean = actions.sanitize_win_name(name_clean)

        if "create_notepad" in T:
            return T["create_notepad"](name=name_clean, content=content, folder=folder, open_window=True)
        return T["write_file"](path=f"{folder}\\{name_clean or 'Блокнот.txt'}", content=content, append=False)

    # ───────────────────────── мессенджеры (быстрые правила) ─────────────────────────
    def _open_chat_rule(self, raw_rest: str, messenger_hint: str = None) -> str:
        s = (raw_rest or "").strip()
        mname = messenger.resolve_messenger(messenger_hint) if messenger_hint else None

        m_start = re.match(
            r"^(?:в\s+|по\s+)?(телеграм[а-я]*|телегу|телеге|тг|telegram|дискорд[а-я]*|дис|discord|ватсап[а-я]*|вацап[а-я]*|whatsapp)\s+(.+)",
            s,
            flags=re.IGNORECASE,
        )
        if m_start:
            mname = messenger.resolve_messenger(m_start.group(1)) or mname
            s = m_start.group(2).strip()
        else:
            m_end = re.search(
                r"\s+(?:в|по)\s+(телеграм[а-я]*|телегу|телеге|тг|telegram|дискорд[а-я]*|дис|discord|ватсап[а-я]*|вацап[а-я]*|whatsapp)$",
                s,
                flags=re.IGNORECASE,
            )
            if m_end:
                mname = messenger.resolve_messenger(m_end.group(1)) or mname
                s = s[:m_end.start()].strip()

        contact = re.sub(
            r"^(?:чат\s+с|чат\s+со|чат|переписку\s+с|диалог\s+с|лс\s+с|со\s+|с\s+|к\s+|ко\s+|в\s+|у\s+)+",
            "",
            s,
            flags=re.IGNORECASE,
        ).strip()

        if not mname:
            mname = messenger.detect_contact_messenger(contact) if contact else "телеграм"

        return self._call_tool("open_chat", {"messenger": mname, "contact": contact})

    def _send_message_rule(self, messenger_raw: str, rest: str, auto_detect_messenger: bool = False) -> str:
        if "send_message" not in self.tools_map:
            return "Отправка сообщений недоступна."
        mname = messenger.resolve_messenger(messenger_raw)
        if not mname:
            return f"Не знаю мессенджер «{messenger_raw}». Добавьте его в config.yaml -> messengers."

        rest = (rest or "").strip()
        rest_clean = re.sub(
            r"^(?:в\s+чат\s+с|в\s+чат|чат\s+с|чат|контакту|пользователю|для)\s+",
            "",
            rest,
            flags=re.IGNORECASE,
        ).strip()

        contact = None
        text = None

        sep = re.search(r"(?:\s+(?:текст|что|сообщение)\s+|\s*[:：]\s+)", rest_clean, flags=re.IGNORECASE)
        if sep:
            contact = rest_clean[:sep.start()].strip()
            text = rest_clean[sep.end():].strip()
        else:
            pair = messenger.split_contact_text(mname, rest_clean)
            if pair:
                contact, text = pair
            else:
                rc2 = re.sub(r"^(?:в|к|ко|с|со)\s+", "", rest_clean, flags=re.IGNORECASE).strip()
                words = rc2.split(None, 1)
                if len(words) >= 2:
                    contact, text = words[0], words[1]

        if not contact:
            return f"Кому отправить в {mname}? Пример: «напиши в {mname} Дане привет»."
        if not text:
            return f"Что отправить контакту {contact}? Пример: «напиши в {mname} {contact} привет»."

        if auto_detect_messenger:
            mname = messenger.detect_contact_messenger(contact) or mname

        args = {"messenger": mname, "contact": contact, "text": text}
        return self._maybe_confirm("send_message", args, messenger.describe_send(args))

    # ───────────────────────── выполнение действий ─────────────────────────
    def _maybe_confirm(self, name: str, args: dict, describe: str) -> str:
        blocked = actions.blocked_reason(name, args)
        if blocked:
            return f"Нельзя: {blocked}."
        if actions.tool_level(name, args) == "confirm":
            self.pending = {"name": name, "args": args, "describe": describe}
            return f"Подтвердите: {describe}. Скажите «да» или «нет»."
        return self._call_tool(name, args)

    def _exec_pending(self, confirm: bool) -> str:
        if not self.pending:
            return "Нечего подтверждать."
        p, self.pending = self.pending, None
        if not confirm:
            return f"Отменил: {p['describe']}."
        return self._call_tool(p["name"], p["args"])

    def _call_tool(self, name: str, args: dict) -> str:
        fn = self.tools_map.get(name)
        if not fn:
            return f"Инструмент «{name}» не найден."
        blocked = actions.blocked_reason(name, args)
        if blocked:
            return f"Нельзя: {blocked}."
        try:
            args = actions.coerce_args(fn, args)
            result = fn(**args)
            result = str(result)
            database.log_action(name, args, True, result)
            actions.trace(f"инструмент {name}({args}) -> {result[:80]}")
            return result
        except Exception as e:
            database.log_action(name, args, False, str(e))
            return f"Не удалось: {e}"

    # ───────────────────────── нейросеть-агент (Ollama) ─────────────────────────
    @staticmethod
    def _extract_msg_fields(response):
        if isinstance(response, dict):
            msg = response.get("message") or {}
        else:
            msg = getattr(response, "message", None) or {}

        if isinstance(msg, dict):
            content = msg.get("content") or ""
            raw_tcs = msg.get("tool_calls") or []
        else:
            content = getattr(msg, "content", "") or ""
            raw_tcs = getattr(msg, "tool_calls", None) or []

        norm_tcs = []
        for tc in raw_tcs:
            if isinstance(tc, dict):
                fn_obj = tc.get("function") or {}
                fname = fn_obj.get("name")
                fargs = fn_obj.get("arguments") or {}
            else:
                fn_obj = getattr(tc, "function", None)
                fname = getattr(fn_obj, "name", None) if fn_obj else None
                fargs = getattr(fn_obj, "arguments", {}) if fn_obj else {}
            if fname:
                norm_tcs.append({"function": {"name": fname, "arguments": fargs}})
        return content, norm_tcs

    # ───────────────────────── Автопоиск локальных ИИ-моделей пользователя (без 503 прокси-ошибок!) ─────────────────────────
    def discover_local_models(self) -> list:
        """Находит все установленные у пользователя локальные модели ИИ:
        1) Через прямой HTTP-запрос к Ollama /api/tags В ОБХОД системного прокси/VPN (ProxyHandler({})).
        2) Через сканирование папки манифестов Ollama на диске (~/.ollama/models/manifests)."""
        found = []

        # 1. Прямой запрос к локальному серверу Ollama в обход любого VPN/прокси
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            url = self.ollama_url.rstrip("/") + "/api/tags"
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with opener.open(req, timeout=3.5) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="replace"))
            for m_item in (data.get("models") or []):
                mname = m_item.get("name") or m_item.get("model")
                if mname and "embed" not in mname.lower() and mname not in found:
                    found.append(mname)
        except Exception:
            pass

        # 2. Резервная проверка через клиент ollama (с отключённым прокси trust_env=False)
        if not found:
            try:
                client = ollama.Client(host=self.ollama_url, timeout=3.5, trust_env=False)
                lst = client.list()
                models_list = lst.get("models", []) if isinstance(lst, dict) else getattr(lst, "models", [])
                for m_item in models_list:
                    mname = m_item.get("name") or m_item.get("model") if isinstance(m_item, dict) else getattr(m_item, "model", None)
                    if mname and "embed" not in mname.lower() and mname not in found:
                        found.append(mname)
            except Exception:
                pass

        # 3. Сканирование папки ~/.ollama/models/manifests на диске (работает даже пока сервер Ollama ещё запускается!)
        manifest_roots = [
            os.path.expanduser("~/.ollama/models/manifests"),
            os.path.expandvars(r"%USERPROFILE%\.ollama\models\manifests"),
            os.path.expandvars(r"%LOCALAPPDATA%\Ollama\models\manifests"),
        ]
        for mroot in manifest_roots:
            if not os.path.isdir(mroot):
                continue
            for dp, _dirs, files in os.walk(mroot):
                for f in files:
                    rel = os.path.relpath(os.path.join(dp, f), mroot).replace("\\", "/")
                    parts = [p for p in rel.split("/") if p]
                    # Формат: registry.ollama.ai/library/<model>/<tag> или registry.ollama.ai/<ns>/<model>/<tag>
                    if len(parts) >= 3:
                        tag = parts[-1]
                        model_base = parts[-2]
                        ns = parts[-3] if len(parts) >= 4 else "library"
                        full_name = f"{model_base}:{tag}" if ns == "library" else f"{ns}/{model_base}:{tag}"
                        if "embed" not in full_name.lower() and full_name not in found:
                            found.append(full_name)

        self.available_models = found
        return found

    def _discover_and_select_local_model(self):
        """При запуске проверяет, какие модели реально установлены у пользователя, и подключается к рабочей модели."""
        avail = self.discover_local_models()
        if not avail:
            return
        # Предпочитаем текстовые/инструктивные модели для диалога
        text_models = [m for m in avail if "vl" not in m.lower() and "llava" not in m.lower()] or avail
        if self.model not in avail:
            # Проверяем совпадение без тега :latest
            base_target = self.model.split(":")[0].lower()
            matched = next((m for m in text_models if m.split(":")[0].lower() == base_target), None)
            self.model = matched or text_models[0]
            print(f"[ИИ] Автоматически подключена ваша локальная модель: {self.model}")

    def get_available_models(self) -> list:
        avail = self.discover_local_models()
        if self.model and self.model not in avail:
            avail.append(self.model)
        return avail or [self.model]

    def _ollama_direct_http_chat(self, model: str, messages: list, tools: list = None) -> dict:
        """Прямой HTTP POST к локальному серверу Ollama В ОБХОД системного прокси/VPN (никогда не выдаёт 503 из-за VPN!)."""
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        url = self.ollama_url.rstrip("/") + "/api/chat"
        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": 0.25,
                "top_p": 0.85,
                "repeat_penalty": 1.12,
            },
        }
        if tools:
            payload["tools"] = tools
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
        with opener.open(req, timeout=self.ollama_timeout) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))

    def _ensure_ollama_running(self):
        """Если процесс ollama не запущен — автоматически стартует ollama serve в фоне."""
        if os.name != "nt":
            return
        try:
            if not actions.APPS.is_running("ollama.exe"):
                subprocess.Popen(["ollama", "serve"], creationflags=0x08000000)
                time.sleep(1.5)
        except Exception:
            pass

    def ask_local_llm_direct(self, prompt: str) -> str:
        """Быстрый запрос к локальной модели пользователя (используется модулем зрения screen.py)."""
        msgs = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": prompt},
        ]
        try:
            resp = self._ollama_direct_http_chat(self.model, msgs, tools=None)
            content, _ = self._extract_msg_fields(resp)
            return database.strip_cjk(content or "").strip()
        except Exception:
            return ""

    def _llm_agent(self, user_text: str) -> str:
        history = database.get_history(limit=6)
        messages = [{"role": "system", "content": self.system_prompt}]
        for h in history:
            messages.append({"role": h["role"], "content": h["content"]})
        if not history or history[-1].get("content") != user_text:
            messages.append({"role": "user", "content": user_text})

        try:
            client = ollama.Client(host=self.ollama_url, timeout=self.ollama_timeout, trust_env=False)
        except TypeError:
            client = ollama.Client(host=self.ollama_url, timeout=self.ollama_timeout)

        low = actions.normalize(user_text)
        action_keywords = (
            "открой", "закрой", "запусти", "включи", "выключи", "напиши", "отправь", "найди",
            "создай", "сделай", "блокнот", "заметк", "запиши", "допиши", "стол", "удали", "перемести", "скопируй", "громк", "яркост", "окно", "экран",
            "скрин", "папк", "файл", "сценари", "таймер", "посчитай", "процесс", "корзин",
            "чат", "телеграм", "дискорд", "ватсап", "мышь", "клик", "нажми", "компьютер",
            "прочитай", "распознай", "видишь", "кнопк", "элемент", "надпись", "поле", "окр", "ocr",
        )
        use_tools = any(k in low for k in action_keywords)
        tools = self.tools_schema if use_tools else None

        for _step in range(5):
            response = None
            try:
                if tools:
                    try:
                        response = self._ollama_direct_http_chat(self.model, messages, tools=tools)
                    except Exception as e_tools:
                        err_s = str(e_tools).lower()
                        if "does not support tools" in err_s or "tool" in err_s or "400" in err_s:
                            tools = None
                            response = self._ollama_direct_http_chat(self.model, messages, tools=None)
                        else:
                            raise
                else:
                    response = self._ollama_direct_http_chat(self.model, messages, tools=None)
            except Exception:
                # Фоллбэк на клиент ollama и автопоиск установленной модели пользователя (при 404 / 503 / смене тега)
                try:
                    self._ensure_ollama_running()
                    avail = self.discover_local_models()
                    text_models = [m for m in avail if "vl" not in m.lower() and "embed" not in m.lower()] or avail
                    if text_models and self.model not in text_models:
                        old_m = self.model
                        self.model = text_models[0]
                        actions.trace(f"Переключился на установленную локальную модель: {self.model} (вместо {old_m})")
                    if tools:
                        try:
                            response = client.chat(model=self.model, messages=messages, tools=tools)
                        except Exception:
                            tools = None
                            response = client.chat(model=self.model, messages=messages)
                    else:
                        response = client.chat(model=self.model, messages=messages)
                except Exception as e_final:
                    return (
                        f"Локальная ИИ-модель «{self.model}» сейчас не откликнулась ({e_final}). "
                        f"Выберите вашу модель в верхнем списке «🤖 Модель ИИ» или убедитесь, что запущена Ollama."
                    )

            content, tool_calls = self._extract_msg_fields(response)

            if not tool_calls:
                content = content.strip()
                parsed = self._parse_raw_tool_call(content)
                if parsed:
                    name, args = parsed
                    if name in self.tools_map:
                        return self._call_tool(name, args)
                clean_c = database.strip_cjk(content).strip()
                return clean_c or "Готово, Егор!"

            messages.append({
                "role": "assistant",
                "content": content,
                "tool_calls": tool_calls,
            })

            for tc in tool_calls:
                fn_obj = tc.get("function") or {}
                name = fn_obj.get("name")
                raw_args = fn_obj.get("arguments") or {}
                if isinstance(raw_args, str):
                    try:
                        raw_args = json.loads(raw_args)
                    except Exception:
                        raw_args = {}
                if name not in self.tools_map:
                    messages.append({"role": "tool", "name": str(name), "content": f"инструмент {name} не существует"})
                    continue
                fn = self.tools_map[name]
                try:
                    args = actions.coerce_args(fn, raw_args)
                    blocked = actions.blocked_reason(name, args)
                    if blocked:
                        messages.append({"role": "tool", "name": name, "content": f"нельзя: {blocked}"})
                        continue
                    result = str(fn(**args))
                    database.log_action(name, args, True, result)
                    actions.trace(f"нейросеть вызвала {name}({args}) -> {result[:80]}")
                except Exception as e:
                    result = f"ошибка: {e}"
                    database.log_action(name, raw_args, False, str(e))
                messages.append({"role": "tool", "name": name, "content": result[:2000]})

        return "Слишком много шагов — остановился. Переформулируйте задачу."

    @staticmethod
    def _describe_tool_call(name: str, args: dict) -> str:
        try:
            desc = actions.REGISTRY.get(name, {}).get("desc", name)
        except Exception:
            desc = name
        if not args:
            return desc
        kv = ", ".join(f"{k}={v}" for k, v in args.items() if v not in (None, "", []))
        return f"{desc} ({kv})" if kv else desc

    def _parse_raw_tool_call(self, content: str):
        if not content:
            return None
        text = content.strip()
        for name in self.tools_map.keys():
            if name in text:
                idx = text.find(name)
                rest = text[idx + len(name):]
                for open_ch, close_ch in [("{", "}"), ("(", ")")]:
                    start = rest.find(open_ch)
                    if start >= 0:
                        end = rest.rfind(close_ch)
                        if end > start:
                            json_str = rest[start:end + 1]
                            try:
                                args = json.loads(json_str)
                                if isinstance(args, dict):
                                    return name, args
                            except json.JSONDecodeError:
                                inner = json_str[1:-1].strip()
                                args = {}
                                for pair in inner.split(","):
                                    if "=" in pair:
                                        k, v = pair.split("=", 1)
                                        k = k.strip().strip('"\'')
                                        v = v.strip().strip('"\'')
                                        if k:
                                            args[k] = v
                                if args:
                                    return name, args
        return None

    # ───────────────────────── сценарии ─────────────────────────
    def run_scenario(self, name: str) -> str:
        key = self._resolve_scenario_key(name, allow_fuzzy=True)
        if not key:
            return f"Сценарий «{name}» не найден. Доступно: {', '.join(list(self.scenarios)[:20])}."

        steps = self.scenarios[key] or []
        self._cancel_scenario = False
        actions.trace(f"сценарий «{key}»: {len(steps)} шаг(ов)")
        results = []
        for step in steps:
            if self._cancel_scenario:
                actions.trace(f"сценарий «{key}» прерван пользователем")
                return f"Сценарий «{key}» остановлен."
            if isinstance(step, dict):
                r = self._run_scenario_step(step)
                if r:
                    results.append(r)
        return f"Сценарий «{key}» выполнен." + (" " + "; ".join(results) if results else "")

    def _run_scenario_step(self, step: dict) -> str:
        """Выполняет один шаг сценария."""
        T = self.tools_map

        # ── Формат 2: полный (tool + args) ──
        if "tool" in step:
            tool_name = step["tool"]
            args = step.get("args") or {}
            if tool_name not in self.tools_map:
                actions.trace(f"сценарий: неизвестный инструмент {tool_name}")
                return ""
            try:
                fn = self.tools_map[tool_name]
                args = actions.coerce_args(fn, args)
                r = str(fn(**args))
                actions.trace(f"сценарий: {tool_name} -> {r[:60]}")
                return r
            except Exception as e:
                actions.trace(f"сценарий: {tool_name} упал: {e}")
                return f"ошибка: {e}"

        # ── Формат 1: компактный ──
        if "say" in step:
            text = str(step["say"])
            if self.speaker:
                try:
                    self.speaker.say(text, force=True)
                except Exception:
                    pass
            actions.trace(f"сценарий: say -> {text[:50]}")

        if "voice" in step:
            if self.speaker:
                self.speaker.muted = not bool(step["voice"])

        if "mute" in step and "mute_sound" in T:
            try:
                T["mute_sound"](muted=bool(step["mute"]))
            except Exception as e:
                actions.trace(f"сценарий: mute упал: {e}")

        if "volume" in step and "set_volume" in T:
            try:
                T["set_volume"](percent=int(step["volume"]))
            except Exception as e:
                actions.trace(f"сценарий: volume упал: {e}")

        if "brightness" in step and "set_brightness" in T:
            try:
                T["set_brightness"](percent=int(step["brightness"]))
            except Exception as e:
                actions.trace(f"сценарий: brightness упал: {e}")

        if "minimize_all" in step and step["minimize_all"] and "minimize_all" in T:
            try:
                T["minimize_all"]()
                time.sleep(0.35)
            except Exception as e:
                actions.trace(f"сценарий: minimize_all упал: {e}")

        if "game_input" in step:
            actions.STATE["game_input"] = bool(step["game_input"])

        if "close" in step and "close_app" in T:
            targets = step["close"] if isinstance(step["close"], list) else [step["close"]]
            for app_name in targets:
                try:
                    T["close_app"](name=str(app_name))
                except Exception as e:
                    actions.trace(f"сценарий: close {app_name} упал: {e}")

        if "open" in step and "open_app" in T:
            targets = step["open"] if isinstance(step["open"], list) else [step["open"]]
            for app_name in targets:
                try:
                    r = str(T["open_app"](name=str(app_name)))
                    actions.trace(f"сценарий: open {app_name} -> {r[:50]}")
                except Exception as e:
                    actions.trace(f"сценарий: open {app_name} упал: {e}")

        if "open_steam_game" in step and "open_steam_game" in T:
            try:
                r = str(T["open_steam_game"](name=str(step["open_steam_game"])))
                actions.trace(f"сценарий: open_steam_game -> {r[:50]}")
            except Exception as e:
                actions.trace(f"сценарий: open_steam_game упал: {e}")

        if "open_chat" in step and "open_chat" in T:
            oc = step["open_chat"]
            try:
                if isinstance(oc, dict):
                    r = str(T["open_chat"](
                        contact=str(oc.get("contact", "")),
                        messenger=str(oc.get("messenger", "телеграм")),
                    ))
                else:
                    r = str(T["open_chat"](contact=str(oc), messenger="телеграм"))
                actions.trace(f"сценарий: open_chat -> {r[:50]}")
            except Exception as e:
                actions.trace(f"сценарий: open_chat упал: {e}")

        if "wait" in step:
            try:
                secs = float(step["wait"])
                end_t = time.time() + secs
                while time.time() < end_t:
                    if self._cancel_scenario:
                        break
                    time.sleep(min(0.2, max(0.01, end_t - time.time())))
                actions.trace(f"сценарий: wait {secs}с")
            except (TypeError, ValueError):
                pass

        if "hotkey" in step and "press_keys" in T:
            try:
                T["press_keys"](keys=str(step["hotkey"]))
                if "win+d" in str(step["hotkey"]).lower():
                    time.sleep(0.35)
            except Exception as e:
                actions.trace(f"сценарий: hotkey упал: {e}")

        if "url" in step:
            try:
                actions._open_url(str(step["url"]))
                actions.trace(f"сценарий: url -> {str(step['url'])[:50]}")
            except Exception as e:
                actions.trace(f"сценарий: url упал: {e}")

        if "timer" in step and "set_timer" in T:
            tm = step["timer"]
            try:
                if isinstance(tm, dict):
                    T["set_timer"](seconds=int(tm.get("seconds", 60)), label=str(tm.get("label", "Таймер сценария")))
                else:
                    T["set_timer"](seconds=int(tm), label="Таймер сценария")
            except Exception as e:
                actions.trace(f"сценарий: timer упал: {e}")

        if "message" in step and "send_message" in T:
            msg = step["message"] or {}
            try:
                r = str(T["send_message"](
                    messenger=str(msg.get("messenger", "телеграм")),
                    contact=str(msg.get("contact", "")),
                    text=str(msg.get("text", "")),
                ))
                actions.trace(f"сценарий: message -> {r[:50]}")
            except Exception as e:
                actions.trace(f"сценарий: message упал: {e}")

        if "command" in step:
            try:
                cmd_str = str(step["command"])
                r = self._fast_rules(cmd_str)
                if r is None:
                    r = self.process_query(cmd_str, from_voice=False)
                actions.trace(f"сценарий: command -> {str(r)[:50]}")
                return str(r)
            except Exception as e:
                actions.trace(f"сценарий: command упал: {e}")
        return ""


JarvisBrain = Brain

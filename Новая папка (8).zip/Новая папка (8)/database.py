"""Память Джарвиса (SQLite): история диалога, журнал действий, факты о пользователе.

Устойчивость и чистота языка:
  • Автоматическая очистка истории диалога от китайских/японских/корейских иероглифов (CJK),
    которые иногда генерируют модели семейства Qwen, чтобы они никогда не попадали в контекст
    будущих ответов и не провоцировали новые иероглифы!
  • Постоянное соединение с потокобезопасной блокировкой, journal_mode=MEMORY и busy_timeout=5000 мс.
"""
import os
import re
import sqlite3
import threading

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "jarvis.db")
_lock = threading.Lock()
_conn = None

# Регулярное выражение для вырезания всех китайских/японских/корейских иероглифов и CJK-пунктуации
_CJK_RE = re.compile(
    r"[\u2e80-\u2eff\u2f00-\u2fdf\u3000-\u303f\u3040-\u309f\u30a0-\u30ff"
    r"\u3100-\u312f\u3130-\u318f\u31c0-\u31ef\u3200-\u32ff\u3300-\u33ff"
    r"\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\ufe30-\ufe4f\uff00-\uffef"
    r"\U00020000-\U0002fa1f]+"
)


def strip_cjk(text: str) -> str:
    """Полностью удаляет китайские/японские/корейские иероглифы из строки."""
    if not text:
        return ""
    cleaned = _CJK_RE.sub("", str(text))
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\s+([,.!?:;])", r"\1", cleaned)
    return cleaned.strip()


def _get_conn():
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
        _conn.execute("PRAGMA busy_timeout=5000")
        _conn.execute("PRAGMA journal_mode=MEMORY")
        _conn.execute("PRAGMA synchronous=OFF")
    return _conn


def _run(sql, params=(), fetch=False):
    global _conn
    try:
        with _lock:
            conn = _get_conn()
            cur = conn.execute(sql, params)
            rows = cur.fetchall() if fetch else None
            conn.commit()
            return rows
    except sqlite3.Error as e:
        print(f"[WARN] Ошибка БД ({e})")
        try:
            if _conn is not None:
                _conn.close()
        except Exception:
            pass
        _conn = None
        return [] if fetch else None


def init_db():
    """Создаёт таблицы и автоматически очищает старую историю в jarvis.db от китайских иероглифов."""
    try:
        with _lock:
            conn = _get_conn()
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    role TEXT,
                    content TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS actions_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts DATETIME DEFAULT CURRENT_TIMESTAMP,
                    tool TEXT, args TEXT, ok INTEGER, result TEXT
                );
                CREATE TABLE IF NOT EXISTS facts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts DATETIME DEFAULT CURRENT_TIMESTAMP,
                    fact TEXT UNIQUE
                );
            """)
            # Очищаем уже сохранённые сообщения в БД от случайных китайских иероглифов прошлых сессий
            rows = conn.execute("SELECT id, content FROM history").fetchall()
            for row_id, content in rows:
                if content and _CJK_RE.search(content):
                    clean_c = strip_cjk(content)
                    if clean_c:
                        conn.execute("UPDATE history SET content = ? WHERE id = ?", (clean_c, row_id))
                    else:
                        conn.execute("DELETE FROM history WHERE id = ?", (row_id,))
            conn.commit()
    except sqlite3.Error as e:
        print(f"[WARN] Не удалось инициализировать БД: {e}")


# ───── история диалога ─────
def add_message(role: str, content: str):
    clean = strip_cjk(content)
    if clean:
        _run("INSERT INTO history (role, content) VALUES (?, ?)", (role, clean))


def get_history(limit=8):
    rows = _run("SELECT role, content FROM history ORDER BY id DESC LIMIT ?", (limit,), fetch=True) or []
    out = []
    for r in reversed(rows):
        clean = strip_cjk(r[1])
        if clean:
            out.append({"role": r[0], "content": clean})
    return out


def clear_history():
    _run("DELETE FROM history")


# ───── журнал действий (что Джарвис делал на ПК) ─────
def log_action(tool: str, args, ok: bool, result: str):
    _run("INSERT INTO actions_log (tool, args, ok, result) VALUES (?, ?, ?, ?)",
         (tool, str(args)[:500], int(bool(ok)), strip_cjk(str(result))[:500]))


def recent_actions(limit=20):
    return _run("SELECT ts, tool, args, ok, substr(result,1,120) FROM actions_log ORDER BY id DESC LIMIT ?",
                (limit,), fetch=True) or []


# ───── факты о пользователе («запомни, что я люблю играть ночью») ─────
def add_fact(fact: str):
    clean = strip_cjk(fact)[:300]
    if clean:
        _run("INSERT OR IGNORE INTO facts (fact) VALUES (?)", (clean,))


def get_facts(limit=20):
    rows = _run("SELECT fact FROM facts ORDER BY id DESC LIMIT ?", (limit,), fetch=True) or []
    return [strip_cjk(r[0]) for r in rows if strip_cjk(r[0])]

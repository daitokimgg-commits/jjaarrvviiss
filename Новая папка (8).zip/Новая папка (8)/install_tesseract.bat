@echo off
chcp 65001 >nul
title J.A.R.V.I.S. — Установка Tesseract OCR (Русский + Английский)
echo ============================================================================
echo   J.A.R.V.I.S. — АВТОМАТИЧЕСКАЯ УСТАНОВКА TESSERACT OCR + RUS/ENG МОДЕЛЕЙ
echo ============================================================================
echo.
echo [1/4] Установка Python-библиотек для компьютерного зрения (pytesseract, opencv-python, mss, pillow)...
pip install --upgrade pytesseract opencv-python mss pillow rapidfuzz
echo.

echo [2/4] Проверка наличия Tesseract-OCR в системе...
set "TESS_EXE="
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESS_EXE=C:\Program Files\Tesseract-OCR\tesseract.exe"
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "TESS_EXE=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"
if exist "%~dp0tesseract\tesseract.exe" set "TESS_EXE=%~dp0tesseract\tesseract.exe"

if defined TESS_EXE (
    echo     [+] Найдено: "%TESS_EXE%"
) else (
    echo     [*] Устанавливаю Tesseract-OCR через winget (UB-Mannheim.TesseractOCR)...
    winget install --id UB-Mannheim.TesseractOCR -e --accept-package-agreements --accept-source-agreements
    if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESS_EXE=C:\Program Files\Tesseract-OCR\tesseract.exe"
    if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "TESS_EXE=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"
)
echo.

echo [3/4] Загрузка языковых моделей Tesseract LSTM (rus.traineddata + eng.traineddata) в папку проекта...
if not exist "%~dp0tessdata" mkdir "%~dp0tessdata"

if not exist "%~dp0tessdata\rus.traineddata" (
    echo     [*] Скачиваю rus.traineddata (русский язык)...
    powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/tesseract-ocr/tessdata_fast/raw/main/rus.traineddata' -OutFile '%~dp0tessdata\rus.traineddata'"
) else (
    echo     [+] rus.traineddata уже загружен.
)

if not exist "%~dp0tessdata\eng.traineddata" (
    echo     [*] Скачиваю eng.traineddata (английский язык)...
    powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata' -OutFile '%~dp0tessdata\eng.traineddata'"
) else (
    echo     [+] eng.traineddata уже загружен.
)

if exist "C:\Program Files\Tesseract-OCR\tessdata" (
    copy /Y "%~dp0tessdata\*.traineddata" "C:\Program Files\Tesseract-OCR\tessdata\" >nul 2>&1
)
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tessdata" (
    copy /Y "%~dp0tessdata\*.traineddata" "%LOCALAPPDATA%\Programs\Tesseract-OCR\tessdata\" >nul 2>&1
)
echo.

echo [4/4] Проверка статуса зрения Джарвиса...
python -c "import screen; print(screen.ocr_status())"
echo.
echo ============================================================================
echo   ГОТОВО! Теперь Джарвис видит экран и умеет нажимать на любые элементы.
echo ============================================================================
pause

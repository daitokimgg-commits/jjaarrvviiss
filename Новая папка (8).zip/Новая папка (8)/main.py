"""Точка входа Джарвиса (режим отдельного Desktop-приложения с открытым исходным кодом).

Ключевые особенности запуска:
  1. Нативный AppUserModelID Windows ('Egor.Jarvis.DesktopAssistant.v3') и собственная иконка jarvis_icon.ico —
     панель задач Windows отображает Джарвиса как отдельное приложение, а не как python.exe.
  2. Автоматическая генерация иконки jarvis_icon.ico и компиляция нативного лаунчера Jarvis.exe
     (через встроенный компилятор Windows .NET csc.exe): вы запускаете Jarvis.exe как полноценную программу,
     но все .py файлы и config.yaml остаются открытыми для редактирования на лету!
  3. Автоматическое сворачивание окна терминала (консоли) в панель задач при запуске без его закрытия
     (логи всегда доступны в панели задач или по кнопке 🖥 в верхней панели Джарвиса).
  4. Автоудаление старой папки tessdoc и подключение официального Tesseract-OCR\\tesseract.exe.
"""
import glob
import os
import subprocess
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ─────────────────────────────────────────────────────────────
# 1) DPI-фикс и AppUserModelID (отдельное приложение в панели задач Windows) ДО импорта Qt
# ─────────────────────────────────────────────────────────────
if sys.platform == "win32":
    try:
        import ctypes
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Egor.Jarvis.DesktopAssistant.v3")
        except Exception:
            pass
        try:
            ctypes.windll.user32.SetProcessDpiAwarenessContext(-4)
        except (AttributeError, OSError):
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except (AttributeError, OSError):
                pass
    except Exception:
        pass

os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
os.environ.setdefault("QT_AUTO_SCREEN_SCALE_FACTOR", "1")
os.environ.setdefault("QT_LOGGING_RULES", "qt.qpa.window=false")

import yaml
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication

import actions
import database
import messenger  # noqa: F401  — регистрирует свои инструменты
import screen     # noqa: F401  — регистрирует инструменты официального Tesseract OCR
from brain import Brain
from voice import Listener, Speaker
from ui import JarvisUI


def ensure_jarvis_icon() -> str:
    """Создаёт фирменную фиолетовую 3D-иконку jarvis_icon.ico с белыми глазками (как на референсе)."""
    ico_path = os.path.join(BASE_DIR, "jarvis_icon.ico")
    try:
        from PIL import Image, ImageDraw
        size = 256
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        # Внешний фиолетовый шар
        d.ellipse([16, 16, 240, 240], fill=(109, 40, 217, 255), outline=(167, 139, 250, 255), width=6)
        d.ellipse([32, 28, 212, 208], fill=(139, 92, 246, 255))
        d.ellipse([54, 42, 165, 145], fill=(196, 181, 253, 220))
        # Два белых глазика-полусферы
        d.pieslice([68, 106, 114, 152], start=180, end=360, fill=(255, 255, 255, 255))
        d.pieslice([142, 106, 188, 152], start=180, end=360, fill=(255, 255, 255, 255))
        img.save(ico_path, format="ICO", sizes=[(256, 256), (64, 64), (48, 48), (32, 32), (16, 16)])
    except Exception as e:
        print(f"[INFO] Не удалось сгенерировать иконку: {e}")
    return ico_path


def ensure_standalone_dev_exe(ico_path: str):
    """Компилирует нативный лаунчер Jarvis.exe в папке проекта через системный компилятор .NET (csc.exe).
    Jarvis.exe запускает main.py напрямую из открытых исходников со свёрнутым в панель задач терминалом!"""
    if sys.platform != "win32":
        return
    exe_path = os.path.join(BASE_DIR, "Jarvis.exe")
    cs_path = os.path.join(BASE_DIR, "JarvisLauncher.cs")
    py_exe = sys.executable or "python"
    if py_exe.lower().endswith("pythonw.exe"):
        cand = os.path.join(os.path.dirname(py_exe), "python.exe")
        if os.path.isfile(cand):
            py_exe = cand

    cs_code = f"""using System;
using System.Diagnostics;
using System.IO;

class JarvisLauncher {{
    static void Main(string[] args) {{
        string dir = AppDomain.CurrentDomain.BaseDirectory;
        string py = @"{py_exe}";
        if (!File.Exists(py)) py = "python";
        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = "cmd.exe";
        psi.Arguments = "/c title JARVIS CORE INTERFACE && cd /d \\"" + dir.TrimEnd('\\\\') + "\\" && \\"" + py + "\\" -X utf8 main.py --from-launcher";
        psi.WorkingDirectory = dir;
        psi.WindowStyle = ProcessWindowStyle.Minimized;
        psi.UseShellExecute = true;
        try {{
            Process.Start(psi);
        }} catch (Exception) {{}}
    }}
}}
"""
    try:
        with open(cs_path, "w", encoding="utf-8") as f:
            f.write(cs_code)
    except Exception:
        return

    if os.path.isfile(exe_path) and os.path.getsize(exe_path) > 1000:
        return

    csc_candidates = [
        r"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe",
        r"C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe",
    ]
    csc = next((c for c in csc_candidates if os.path.isfile(c)), None)
    if not csc:
        return
    cmd = [csc, "/nologo", "/target:winexe", f"/out:{exe_path}"]
    if ico_path and os.path.isfile(ico_path):
        cmd.append(f"/win32icon:{ico_path}")
    cmd.append(cs_path)
    try:
        subprocess.run(cmd, capture_output=True, timeout=15, creationflags=0x08000000, cwd=BASE_DIR)
        if os.path.isfile(exe_path):
            print(f"[INFO] Создан отдельный исполняемый файл приложения: {exe_path}")
    except Exception:
        pass


def load_config():
    cfg_path = os.path.join(BASE_DIR, "config.yaml")
    if os.path.exists(cfg_path):
        with open(cfg_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


def resolve_vosk_model(cfg: dict) -> str:
    """Находит папку с моделью Vosk (по пути из config.yaml или автоматически в models/)."""
    model_path = cfg.get("vosk_model", "models/vosk-model-ru-0.42")
    if not os.path.isabs(model_path):
        model_path = os.path.join(BASE_DIR, model_path)
    if os.path.isdir(model_path):
        return model_path
    candidates = sorted(glob.glob(os.path.join(BASE_DIR, "models", "vosk-model*")), reverse=True)
    for cand in candidates:
        if os.path.isdir(cand):
            print(f"[INFO] Автоматически выбрана модель Vosk: {cand}")
            return cand
    return model_path


def init_db_safe():
    try:
        database.init_db()
    except Exception as e:
        print(f"[WARN] База не инициализирована: {e}")


def main():
    os.makedirs(os.path.join(BASE_DIR, "logs"), exist_ok=True)
    screen.cleanup_legacy_ocr_folders()
    init_db_safe()
    cfg = load_config()

    # Сразу сворачиваем окно терминала в панель задач (НЕ закрывая его!)
    if cfg.get("minimize_terminal_on_start", True):
        actions.set_console_window_state(minimize=True)

    # Генерируем иконку и лаунчер Jarvis.exe (с открытым доступом ко всем файлам проекта)
    ico_path = ensure_jarvis_icon()
    ensure_standalone_dev_exe(ico_path)

    # Передаём конфиг в actions и мгновенно индексируем приложения
    actions.configure(cfg)
    actions.load_plugins()
    actions.prewarm()

    # Голос (по умолчанию оригинальный бархатный голос Джарвиса с возможностью смены)
    speaker = Speaker.from_config(cfg.get("tts") or {})

    # Мозг
    brain = Brain(cfg=cfg, speaker=speaker)

    # Распознавание речи — нейросеть Faster-Whisper (CTranslate2) + Google Neural Speech (без Vosk!)
    mic_device = cfg.get("mic_device")
    stt_cfg = cfg.get("stt") or {}
    stt_engine = stt_cfg.get("engine", "multipath_pro")
    if stt_engine in ("vosk", "hybrid_best"):
        stt_engine = "multipath_pro"
    whisper_model = stt_cfg.get("whisper_model", "base")

    listener = None
    try:
        listener = Listener(
            model_path=os.path.join(BASE_DIR, "models", "whisper"),
            speaker=speaker,
            device=mic_device,
            stt_engine=stt_engine,
            whisper_model=whisper_model,
            cfg=cfg,
        )
        actions.RUNTIME["listener"] = listener
    except Exception as e:
        print(f"[WARN] Модуль распознавания речи недоступен ({e}). Джарвис работает с клавиатуры.")

    # Графическое окно приложения
    app = QApplication(sys.argv)
    app.setApplicationName("J.A.R.V.I.S.")
    app.setApplicationDisplayName("J.A.R.V.I.S.")
    if ico_path and os.path.isfile(ico_path):
        app.setWindowIcon(QIcon(ico_path))
    try:
        app.setStyle("Fusion")
    except Exception:
        pass

    ui = JarvisUI(brain, speaker, listener)
    if ico_path and os.path.isfile(ico_path):
        ui.setWindowIcon(QIcon(ico_path))
    ui.show()

    # Повторно убеждаемся через 350 мс, что терминал свёрнут в панель задач, а окно Джарвиса — на переднем плане
    if cfg.get("minimize_terminal_on_start", True):
        QTimer.singleShot(350, lambda: actions.set_console_window_state(minimize=True))

    speaker.on_say = lambda text: ui.append_jarvis(text)
    brain.on_trace = lambda kind, text: ui.append_trace(kind, text)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()

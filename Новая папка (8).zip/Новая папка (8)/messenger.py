"""Открытие чатов и отправка сообщений в Telegram, Discord и WhatsApp.

Ключевые механизмы надёжности (решает проблему неотправки сообщений в Telegram):
  1. Аппаратные VK-коды клавиш (actions.win_hotkey / win_press):
     В отличие от pyautogui.hotkey("ctrl", "v"), который ломается в Windows при включённой
     РУССКОЙ раскладке клавиатуры (VkKeyScanA возвращает -1), аппаратные коды VK_CONTROL + VK_V /
     VK_F / VK_A / VK_RETURN работают в 100% случаев на любой раскладке (RU/EN)!
  2. Прямая передача текста через протокол tg://resolve?domain=USER&text=... для контактов с @username.
  3. Для контактов без @username — прямой клик в глобальное поле поиска Telegram (верхняя левая панель)
     без двойного нажатия Esc (которое сворачивало Telegram в системный трей) + авто-клик в поле
     «Написать сообщение...» внизу открытого чата перед вставкой текста и отправкой по Enter.
"""
import os
import re
import time
from urllib.parse import quote

import pyautogui
try:
    from rapidfuzz import fuzz, process
except Exception:
    import difflib
    class fuzz:
        @staticmethod
        def WRatio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def ratio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def partial_ratio(a, b):
            a, b = str(a), str(b)
            if a in b or b in a:
                return 100
            return int(difflib.SequenceMatcher(None, a, b).ratio() * 100)
    class process:
        @staticmethod
        def extractOne(q, choices, scorer=None, score_cutoff=0):
            best_c, best_s = None, -1
            for c in choices:
                s = (scorer or fuzz.WRatio)(q, c)
                if s > best_s:
                    best_c, best_s = c, s
            if best_c is not None and best_s >= score_cutoff:
                return (best_c, best_s, 0)
            return None

import actions
from actions import CFG, normalize, tool, trace

_MESSENGER_SYNONYMS = {
    "телеграм": [
        "телеграм", "телеграме", "телеграмм", "телеграмме", "телегу", "телеге",
        "телегой", "тг", "telegram", "tg", "телеграма", "телеграмма",
    ],
    "дискорд": [
        "дискорд", "дискорде", "дискорда", "дис", "дисе", "диск", "discord", "ds",
    ],
    "ватсап": [
        "ватсап", "ватсапе", "ватсапп", "ватсаппе", "вацап", "вацапе",
        "вотсап", "вотсапе", "whatsapp", "wa",
    ],
}


def _mcfg() -> dict:
    return CFG.get("messengers") or {}


def _lookup(table: dict, raw: str, cutoff: int):
    """table: {настоящее имя: [алиасы]} -> настоящее имя по точному или нечёткому совпадению."""
    q = normalize(raw)
    if not q:
        return None
    names = {}
    for real, aliases in table.items():
        for a in [real] + list(aliases or []):
            na = normalize(a)
            if na:
                names[na] = real
    if not names:
        return None
    if q in names:
        return names[q]
    m = process.extractOne(q, list(names), scorer=fuzz.WRatio, score_cutoff=cutoff)
    return names[m[0]] if m else None


def resolve_messenger(raw: str):
    q = normalize(raw)
    if not q:
        return None
    for canonical, syns in _MESSENGER_SYNONYMS.items():
        if q in syns and canonical in _mcfg():
            return canonical
    table = {}
    for k, v in _mcfg().items():
        extra = _MESSENGER_SYNONYMS.get(normalize(k), [])
        table[k] = list((v or {}).get("aliases", [])) + extra
    return _lookup(table, raw, 75)


def _contacts(mname: str = None) -> dict:
    """{имя: (алиасы, строка_поиска, username, default_messenger)}."""
    out = {}
    sources = [CFG.get("contacts") or {}]
    if mname and (_mcfg().get(mname) or {}).get("contacts"):
        sources.append((_mcfg().get(mname) or {}).get("contacts") or {})
    for src in sources:
        for real, v in src.items():
            if isinstance(v, dict):
                search_str = v.get("search", real)
                username = v.get("username", "")
                def_m = v.get("messenger") or ("дискорд" if str(search_str).startswith("@") else "телеграм")
                out[real] = (v.get("aliases", []), search_str, username, def_m)
            else:
                out[real] = (v or [], real, "", "телеграм")
    return out


def _strip_contact_prefix(raw: str) -> str:
    """Убирает предлоги перед именем контакта: 'с даней' -> 'даней', 'в группу бдсм' -> 'бдсм'."""
    s = (raw or "").strip()
    s = re.sub(
        r"^(?:в\s+чат\s+с|в\s+чат|чат\s+с|чат|переписку\s+с|диалог\s+с|лс\s+с|"
        r"в\s+группу|группу|группа|в\s+канал|канал|контакту|пользователю|"
        r"для|ко|к|со|с|в|у)\s+",
        "",
        s,
        flags=re.IGNORECASE,
    ).strip()
    return s or (raw or "").strip()


def resolve_contact(mname: str, raw: str):
    """-> (имя контакта, строка для поиска, username). Неизвестное имя ищется как есть."""
    cleaned = _strip_contact_prefix(raw)
    if cleaned.startswith("@"):
        uname = cleaned.lstrip("@").strip()
        return uname, uname, uname
    table = _contacts(mname)
    lookup_map = {k: list(v[0] or []) for k, v in table.items()}
    real = _lookup(lookup_map, cleaned, 72) or _lookup(lookup_map, raw, 72)
    if real:
        return real, table[real][1], table[real][2]
    return cleaned, cleaned, ""


def detect_contact_messenger(raw_contact: str) -> str:
    cleaned = _strip_contact_prefix(raw_contact)
    table = _contacts()
    real = _lookup({k: v[0] for k, v in table.items()}, cleaned, 72)
    if real and real in table:
        return table[real][3]
    return "телеграм"


def is_known_contact(raw_contact: str, mname: str = None) -> bool:
    cleaned = _strip_contact_prefix(raw_contact)
    table = _contacts(mname)
    return _lookup({k: v[0] for k, v in table.items()}, cleaned, 78) is not None


def split_contact_text(mname: str, rest: str):
    """«варе привет как дела» -> («варюша», «привет как дела»): ищем известный алиас в начале фразы."""
    if not rest:
        return None
    lead_m = re.match(r"^(?:для|контакту|пользователю|в\s+чат|в\s+группу|в\s+канал|в|к|с|со)\s+", rest, flags=re.IGNORECASE)
    work_rest = rest[lead_m.end():] if lead_m else rest
    work_n = normalize(work_rest)

    cands = []
    for real, (aliases, _s, _u, _dm) in _contacts(mname).items():
        for a in [real] + list(aliases):
            na = normalize(a)
            if na:
                cands.append((na, real))

    for alias, real in sorted(cands, key=lambda x: -len(x[0])):
        if work_n.startswith(alias + " "):
            pattern = r"^\s*" + r"\s+".join(re.escape(w) for w in alias.split()) + r"\s+"
            pm = re.match(pattern, work_rest.replace("ё", "е").replace("Ё", "Е"), flags=re.IGNORECASE)
            if pm:
                msg_text = work_rest[pm.end():].strip()
            else:
                msg_text = work_n[len(alias):].strip()
            if msg_text:
                return real, msg_text

    words = work_rest.split()
    alias_dict = {alias: real for alias, real in cands}
    if alias_dict:
        for num_words in (2, 1):
            if len(words) > num_words:
                head = normalize(" ".join(words[:num_words]))
                m = process.extractOne(head, list(alias_dict), scorer=fuzz.WRatio, score_cutoff=84)
                if m:
                    real = alias_dict[m[0]]
                    msg_text = " ".join(words[num_words:]).strip()
                    if msg_text:
                        return real, msg_text
    return None


def describe_send(args: dict) -> str:
    mname = resolve_messenger(str(args.get("messenger", ""))) or str(args.get("messenger", "телеграм"))
    contact, _, _ = resolve_contact(mname, str(args.get("contact", "")))
    return f"Отправить {contact} в {mname}: «{args.get('text', '')}»"


# ───────────────────────── управление окном и полями Telegram ─────────────────────────
def _wake_telegram():
    """Разворачивает или запускает Telegram Desktop из любого состояния (включая системный трей)."""
    running_exe = actions.APPS.find_running_exe("Telegram.exe")
    if running_exe and os.path.isfile(running_exe):
        try:
            import subprocess
            subprocess.Popen([running_exe], cwd=os.path.dirname(running_exe) or None, creationflags=0x08000000)
            return
        except Exception:
            pass
    try:
        res = actions.open_app("телеграм")
        if not res.startswith("Не нашёл"):
            return
    except Exception:
        pass
    try:
        os.startfile("tg://")
    except Exception:
        pass


def _open_window(mname: str):
    mc = _mcfg().get(mname) or {}
    proc, title = mc.get("process"), mc.get("window", mname)
    found = actions.find_window(title, proc)
    if not found:
        trace(f"{mname}: окно не найдено на экране, запускаю / разворачиваю из трея…")
        if normalize(mname) == "телеграм":
            _wake_telegram()
        else:
            try:
                actions.open_app(mc.get("app", mname))
            except Exception as e:
                trace(f"{mname}: не удалось запустить: {e}")

        end = time.time() + float(mc.get("start_wait", 8))
        while time.time() < end and not found:
            time.sleep(0.4)
            found = actions.find_window(title, proc)
            if not found and proc:
                hidden = actions.find_window(title, proc, include_hidden=True)
                if hidden:
                    actions.focus_hwnd(hidden[0])
                    time.sleep(0.3)
                    found = actions.find_window(title, proc)
        time.sleep(0.7)
    if not found:
        return None
    trace(f"{mname}: окно «{found[1]}» найдено, вывожу вперёд…")
    return found[0] if actions.focus_hwnd(found[0]) else None


def _click_preserving_cursor(x: int, y: int):
    """Кликает по экранным координатам (x, y) и возвращает курсор мыши на прежнее место."""
    try:
        old_pos = pyautogui.position()
    except Exception:
        old_pos = None
    pyautogui.click(int(x), int(y))
    if old_pos is not None:
        try:
            pyautogui.moveTo(old_pos[0], old_pos[1], duration=0.0)
        except Exception:
            pass


def _focus_telegram_search_box(hwnd):
    """Фокусирует глобальное поле поиска в левой панели Telegram Desktop БЕЗ сворачивания окна в трей."""
    rect = actions.get_window_rect(hwnd)
    if rect:
        left, top, right, bottom, w, h = rect
        if w >= 460 and h >= 300:
            # В 2-колоночном режиме поле «Поиск» всегда находится вверху левой колонки (x ≈ left+155, y ≈ top+52)
            search_x = left + min(165, max(110, int(w * 0.16)))
            search_y = top + 52
            _click_preserving_cursor(search_x, search_y)
            time.sleep(0.22)
            # Очищаем старый текст в поле поиска через аппаратные клавиши Ctrl+A -> Backspace
            actions.win_hotkey("ctrl", "a")
            time.sleep(0.05)
            actions.win_press("backspace")
            time.sleep(0.08)
            return

    # Если окно узкое (одноколоночный режим) — используем Ctrl+F через аппаратный VK
    actions.win_hotkey("ctrl", "f")
    time.sleep(0.30)
    actions.win_hotkey("ctrl", "a")
    time.sleep(0.05)
    actions.win_press("backspace")
    time.sleep(0.08)


def _focus_chat_message_input(hwnd, is_tg: bool = True):
    """Гарантирует, что курсор стоит в поле «Написать сообщение...» внизу открытого чата."""
    actions.focus_hwnd(hwnd)
    rect = actions.get_window_rect(hwnd)
    if rect:
        left, top, right, bottom, w, h = rect
        if w >= 350 and h >= 250:
            # В открытом чате Telegram/Discord поле ввода сообщения находится внизу правой части окна
            input_x = left + int(w * (0.64 if w >= 500 else 0.50))
            input_y = bottom - (32 if is_tg else 38)
            _click_preserving_cursor(input_x, input_y)
            time.sleep(0.18)


def _navigate_to_chat(mname: str, contact: str, search: str = None, username: str = None, prefill_text: str = None):
    """Открывает окно мессенджера и переходит в нужный чат.
    Возвращает (hwnd, error_str, text_already_prefilled_bool).
    """
    mc = _mcfg().get(mname) or {}
    hwnd = _open_window(mname)
    if not hwnd:
        return None, (
            f"Не удалось вывести окно {mname} на передний план. Откройте его вручную и повторите команду."
        ), False
    time.sleep(0.35)

    c_norm = normalize(contact)
    s_norm = normalize(search or contact)
    if not c_norm or c_norm in ("телеграм", "тг", "telegram", "дискорд", "discord", "ватсап", "whatsapp"):
        return hwnd, None, False

    is_tg = normalize(mname) == "телеграм"

    # 1) Специальный случай для Telegram: «Избранное» (Saved Messages) -> аппаратный Ctrl+0
    if is_tg and (c_norm in ("избранное", "избранному", "себе", "мне", "saved messages", "сохраненки")
                  or s_norm == "избранное"):
        trace(f"{mname}: открываю «Избранное» (Ctrl+0)…")
        actions.focus_hwnd(hwnd)
        actions.win_hotkey("ctrl", "0")
        time.sleep(0.65)
        return hwnd, None, False

    # 2) Прямое открытие по @username через протокол tg://resolve?domain=...
    user = (username or (mc.get("usernames") or {}).get(contact) or "").strip().lstrip("@")
    if user and mc.get("chat_uri"):
        uri_base = mc["chat_uri"].format(user)
        # Если отправляем сообщение в Telegram — сразу передаём &text=... в tg:// URI!
        if is_tg and prefill_text:
            uri_full = f"{uri_base}&text={quote(str(prefill_text))}"
            trace(f"{mname}: открываю чат @{user} с готовым текстом…")
            try:
                os.startfile(uri_full)
                time.sleep(1.3)
                found = actions.find_window(mc.get("window", mname), mc.get("process"))
                if found:
                    actions.focus_hwnd(found[0])
                    hwnd = found[0]
                time.sleep(0.35)
                return hwnd, None, True
            except Exception as e:
                trace(f"{mname}: ошибка URI с текстом ({e}), пробую обычный переход…")
        else:
            trace(f"{mname}: открываю чат @{user} по прямой ссылке…")
            try:
                os.startfile(uri_base)
                time.sleep(1.2)
                found = actions.find_window(mc.get("window", mname), mc.get("process"))
                if found:
                    actions.focus_hwnd(found[0])
                    hwnd = found[0]
                time.sleep(0.35)
                return hwnd, None, False
            except Exception as e:
                trace(f"{mname}: не удалось открыть URI @{user} ({e}), переключаюсь на поиск…")

    # 3) Глобальный поиск чата по названию (для контактов и групп без @username)
    query_str = (search or contact).strip()
    trace(f"{mname}: ищу чат «{query_str}»…")
    actions.focus_hwnd(hwnd)

    if is_tg:
        _focus_telegram_search_box(hwnd)
    else:
        for k in mc.get("before_search", []):
            actions.win_press(k)
            time.sleep(0.15)
        hotkey_parts = mc.get("search_hotkey", "ctrl+k").split("+")
        actions.win_hotkey(*hotkey_parts)
        time.sleep(0.40)
        actions.win_hotkey("ctrl", "a")
        time.sleep(0.05)
        actions.win_press("backspace")
        time.sleep(0.08)

    # Вставляем имя контакта через Unicode-буфер и аппаратный Ctrl+V
    actions.type_text(query_str, press_enter=False, restore_clipboard=False)
    time.sleep(float(mc.get("search_wait", 1.1)))

    # Переходим в первый найденный чат (Enter)
    for k in mc.get("after_search", ["enter"]):
        actions.win_press(k)
        time.sleep(0.30)

    time.sleep(0.55)
    return hwnd, None, False


def open_chat_in_messenger(mname: str, contact: str = "") -> str:
    """Открывает чат с контактом в указанном мессенджере."""
    real, search, username = resolve_contact(mname, contact) if contact else ("", "", "")
    hwnd, err, _ = _navigate_to_chat(mname, real, search, username, prefill_text=None)
    if err:
        return err
    if not real or normalize(real) == normalize(mname):
        return f"Открыл {mname}."
    return f"Открыл чат «{real}» в {mname}."


def send(mname: str, contact: str, text: str, search: str = None, username: str = None) -> str:
    hwnd, err, prefilled = _navigate_to_chat(mname, contact, search, username, prefill_text=text)
    if err:
        return err

    if actions.foreground_info()[0] != hwnd:
        trace(f"{mname}: фокус потерян, возвращаю окно…")
        if not actions.focus_hwnd(hwnd):
            return f"Окно {mname} потеряло фокус — сообщение не отправлено."

    is_tg = normalize(mname) == "телеграм"

    if prefilled:
        # Текст уже подставлен в поле ввода через tg://resolve?domain=...&text=... — остаётся нажать Enter!
        trace(f"{mname}: текст подставлен через URI, отправляю (Enter)…")
        _focus_chat_message_input(hwnd, is_tg=is_tg)
        time.sleep(0.15)
        actions.win_press("enter")
        return f"Отправил {contact} в {mname}: {text}"

    # Кликаем в поле ввода сообщения внизу чата, вставляем через аппаратный Ctrl+V и нажимаем Enter
    trace(f"{mname}: фокусирую поле ввода, вставляю текст и отправляю…")
    _focus_chat_message_input(hwnd, is_tg=is_tg)
    actions.type_text(text, press_enter=False, restore_clipboard=False)
    time.sleep(0.22)
    actions.win_press("enter")
    return f"Отправил {contact} в {mname}: {text}"


# ───────────────────────── инструменты ─────────────────────────
@tool("Открыть чат, диалог, группу, канал или Избранное в Telegram, Discord или WhatsApp.",
      messenger="telegram, discord или whatsapp (по умолчанию телеграм)",
      contact="Имя контакта, группы, канала или 'избранное'")
def open_chat(contact: str, messenger: str = "телеграм") -> str:
    mname = resolve_messenger(messenger) or detect_contact_messenger(contact)
    if not mname or mname not in _mcfg():
        mname = "телеграм"
    return open_chat_in_messenger(mname, contact)


@tool("Отправить сообщение контакту в Telegram, Discord или WhatsApp. Выполняется сразу без подтверждения.",
      messenger="telegram, discord или whatsapp (можно по-русски: телеграм, дискорд, ватсап)",
      contact="Имя контакта (как в списке контактов Джарвиса)",
      text="Текст сообщения")
def send_message(messenger: str, contact: str, text: str) -> str:
    mname = resolve_messenger(messenger) or detect_contact_messenger(contact)
    if not mname or mname not in _mcfg():
        return f"Не знаю мессенджер «{messenger}». Доступно: {', '.join(_mcfg())}."
    real, search, username = resolve_contact(mname, contact)
    return send(mname, real, text, search, username)


@tool("Отправить сообщение в уже открытый чат (в активном окне Telegram, Discord или WhatsApp).",
      text="Текст сообщения")
def send_to_current_chat(text: str) -> str:
    hwnd, title, pname = actions.foreground_info()
    known = {(v or {}).get("process", "").lower() for v in _mcfg().values()} - {""}
    titles = [(v or {}).get("window", k).lower() for k, v in _mcfg().items()]
    if pname.lower() not in known and not any(t in title.lower() for t in titles):
        found = actions.find_window("Telegram", "Telegram.exe") or actions.find_window("Discord", "Discord.exe")
        if found and actions.focus_hwnd(found[0]):
            hwnd = found[0]
            time.sleep(0.35)
        else:
            return f"Активное окно «{title}» не похоже на мессенджер — сначала откройте чат."
    _focus_chat_message_input(hwnd, is_tg=("telegram" in pname.lower() or "telegram" in title.lower()))
    actions.type_text(text, press_enter=False, restore_clipboard=False)
    time.sleep(0.22)
    actions.win_press("enter")
    return f"Отправил в текущий чат: {text}"

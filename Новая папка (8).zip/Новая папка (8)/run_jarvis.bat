@echo off
chcp 65001 >nul
title JARVIS CORE INTERFACE
cd /d "%~dp0"
if exist "%~dp0tessdoc" rmdir /s /q "%~dp0tessdoc" >nul 2>&1
if "%~1"=="__MINIMIZED__" goto :run
start "JARVIS CORE INTERFACE" /min cmd /c ""%~f0" __MINIMIZED__"
exit /b
:run
python -X utf8 main.py
exit

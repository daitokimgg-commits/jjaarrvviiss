"""Зрение Джарвиса и полное управление экраном через официальный Tesseract OCR (Tesseract-OCR\\tesseract.exe).

Возможности модуля screen.py:
  1. Прямая работа с официальным установленным пакетом C:\\jarvis\\jarvis\\Tesseract-OCR\\tesseract.exe:
     • Автоматическое добавление папки Tesseract-OCR в системный PATH (для подгрузки libtesseract-5.dll и libleptonica-6.dll).
     • Автоматическое подключение папки Tesseract-OCR\\tessdata и автодокачка rus.traineddata (русский язык),
       если при установке Tesseract был выбран только английский язык.
     • Автоматическое удаление устаревшей папки документации tessdoc при запуске.
  2. Улучшенная предобработка скриншотов (preprocess_for_ocr):
     • Автоопределение тёмной темы (Telegram, Discord, Steam, игры, браузер) и инверсия в тёмный текст на светлом фоне.
     • Увеличение масштаба 1.5x и повышение локального контраста (CLAHE / Autocontrast) с точным пересчётом координат.
  3. Полный набор голосовых инструментов взаимодействия с экраном через Tesseract OCR:
     • find_text_on_screen — клик (ЛКМ / двойной / ПКМ) или наведение курсора на любую кнопку, слово или фразу.
     • click_and_type_on_screen — поиск поля ввода по надписи, клик в него и печать текста.
     • list_screen_elements + click_element_by_number — нумерация всех видимых кнопок ([1], [2], [3]…) и клик по номеру.
     • scroll_until_text — автоматическая прокрутка страницы/чата вверх или вниз, пока Tesseract не увидит нужный текст.
     • wait_for_text_on_screen — ожидание появления кнопки/надписи на экране (например «Принять» в CS 2) с автокликом.
     • read_screen_text / read_aloud_screen / read_chat_on_screen — чтение экрана, активного окна, области или чата (вслух и в буфер).
     • translate_screen_text — распознавание английского текста на экране через Tesseract и мгновенный перевод на русский.
     • copy_line_with_text / save_screen_text_to_file / count_text_on_screen — копирование нужной строки, сохранение в файл, подсчёт вхождений.
"""
import glob
import io
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.parse
import urllib.request

import pyautogui
import pyperclip
from PIL import Image, ImageEnhance, ImageOps
try:
    from rapidfuzz import fuzz, process
except Exception:
    import difflib
    class fuzz:
        @staticmethod
        def WRatio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def ratio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def partial_ratio(a, b):
            a, b = str(a), str(b)
            if a in b or b in a:
                return 100
            return int(difflib.SequenceMatcher(None, a, b).ratio() * 100)
    class process:
        @staticmethod
        def extractOne(q, choices, scorer=None, score_cutoff=0):
            best_c, best_s = None, -1
            for c in choices:
                s = (scorer or fuzz.WRatio)(q, c)
                if s > best_s:
                    best_c, best_s = c, s
            if best_c is not None and best_s >= score_cutoff:
                return (best_c, best_s, 0)
            return None

import actions
from actions import CFG, normalize, tool, trace

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LAST = {
    "ocr": "",
    "elements": [],
    "indexed_elements": [],  # [(idx, text, x, y), ...]
}


def cleanup_legacy_ocr_folders():
    """Удаляет старую папку документации tessdoc, если она осталась от прошлых версий."""
    for old_name in ("tessdoc", "tessdoc-main"):
        old_path = os.path.join(BASE_DIR, old_name)
        if os.path.isdir(old_path):
            try:
                shutil.rmtree(old_path, ignore_errors=True)
                print(f"[OCR] Удалена старая папка: {old_path}")
            except Exception:
                pass


cleanup_legacy_ocr_folders()


def _scfg() -> dict:
    return CFG.get("screen") or {}


def _shots_dir() -> str:
    d = os.path.join(os.path.expanduser("~"), "Pictures", "Jarvis")
    os.makedirs(d, exist_ok=True)
    return d


def grab(region=None):
    """Делает скриншот всего экрана или указанной области (left, top, width, height)."""
    if region:
        return pyautogui.screenshot(region=tuple(int(x) for x in region))
    return pyautogui.screenshot()


def grab_active_window():
    """Делает скриншот только активного окна и возвращает (img, (left, top, width, height))."""
    hwnd, _title, _pname = actions.foreground_info()
    rect = actions.get_window_rect(hwnd) if hwnd else None
    if rect and rect[4] >= 150 and rect[5] >= 100:
        left, top, _r, _b, w, h = rect
        left, top = max(0, left), max(0, top)
        try:
            return grab(region=(left, top, w, h)), (left, top, w, h)
        except Exception:
            pass
    img = grab()
    return img, (0, 0, img.width, img.height)


def select_region(timeout: int = 40):
    """Win+Shift+S: вы выделяете область мышкой, Джарвис забирает картинку из буфера обмена."""
    from PIL import ImageGrab
    pyperclip.copy("")
    actions.win_hotkey("win", "shift", "s")
    end = time.time() + timeout
    while time.time() < end:
        time.sleep(0.4)
        try:
            img = ImageGrab.grabclipboard()
            if isinstance(img, Image.Image):
                return img
        except Exception:
            pass
    return None


def image_to_clipboard(img):
    path = os.path.join(tempfile.gettempdir(), "jarvis_clip.png")
    img.save(path)
    if os.name == "nt":
        ps = ("Add-Type -AssemblyName System.Windows.Forms,System.Drawing; "
              f"$i=[System.Drawing.Image]::FromFile('{path}'); [System.Windows.Forms.Clipboard]::SetImage($i); $i.Dispose()")
        subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], creationflags=0x08000000, timeout=20)


# ───────────────────────── Официальный Tesseract OCR (Tesseract-OCR\tesseract.exe) ─────────────────────────
_TESS_INIT_DONE = False


def _find_tesseract_exe() -> str:
    """Находит официальный установленный tesseract.exe (в приоритете папка проекта C:\\jarvis\\jarvis\\Tesseract-OCR)."""
    cfg_path = _scfg().get("tesseract_path", "")
    candidates = [
        os.path.join(BASE_DIR, "Tesseract-OCR", "tesseract.exe"),
        cfg_path,
        r"C:\jarvis\jarvis\Tesseract-OCR\tesseract.exe",
        r"C:\jarvis\Tesseract-OCR\tesseract.exe",
        os.path.join(os.path.dirname(BASE_DIR), "Tesseract-OCR", "tesseract.exe"),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        r"%LocalAppData%\Programs\Tesseract-OCR\tesseract.exe",
        r"%LocalAppData%\Tesseract-OCR\tesseract.exe",
    ]
    for c in candidates:
        if not c:
            continue
        exp = os.path.expandvars(os.path.expanduser(c))
        if not os.path.isabs(exp):
            exp = os.path.join(BASE_DIR, exp)
        if os.path.isfile(exp):
            return os.path.abspath(exp)

    for pat in ("Tesseract-OCR**/tesseract.exe", "tesseract**/tesseract.exe"):
        hits = glob.glob(os.path.join(BASE_DIR, pat), recursive=True)
        if hits and os.path.isfile(hits[0]):
            return os.path.abspath(hits[0])

    which_hit = shutil.which("tesseract")
    return which_hit or ""


def _ensure_russian_tessdata(tessdata_dir: str):
    """Проверяет наличие rus.traineddata в папке tessdata. Если его нет — автоматически скачивает (15 МБ)."""
    if not tessdata_dir or not os.path.isdir(tessdata_dir):
        return
    rus_file = os.path.join(tessdata_dir, "rus.traineddata")
    if os.path.isfile(rus_file) and os.path.getsize(rus_file) > 100_000:
        return
    # Проверяем, нет ли уже скачанного rus.traineddata в соседней папке tessdata/
    alt_rus = os.path.join(BASE_DIR, "tessdata", "rus.traineddata")
    if os.path.isfile(alt_rus) and os.path.getsize(alt_rus) > 100_000:
        try:
            shutil.copy2(alt_rus, rus_file)
            return
        except Exception:
            pass
    url = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/rus.traineddata"
    try:
        trace("Tesseract OCR: докачиваю русский языковой пакет rus.traineddata…")
        req = urllib.request.Request(url, headers={"User-Agent": "JarvisAssistant/3.0"})
        with urllib.request.urlopen(req, timeout=20) as resp, open(rus_file, "wb") as out_f:
            shutil.copyfileobj(resp, out_f)
        trace("Tesseract OCR: русский язык (rus.traineddata) успешно установлен!")
    except Exception as e:
        trace(f"Tesseract OCR: не удалось автоматически скачать rus.traineddata ({e})")


def _find_tessdata_config(exe_path: str) -> str:
    """Настраивает PATH (для DLL-библиотек Tesseract 5) и TESSDATA_PREFIX на официальную папку Tesseract-OCR\\tessdata."""
    global _TESS_INIT_DONE
    if exe_path:
        exe_dir = os.path.dirname(os.path.abspath(exe_path))
        cur_path = os.environ.get("PATH", "")
        if exe_dir.lower() not in cur_path.lower():
            os.environ["PATH"] = exe_dir + os.pathsep + cur_path

    candidates = []
    if exe_path:
        candidates.append(os.path.join(os.path.dirname(os.path.abspath(exe_path)), "tessdata"))
    candidates.extend([
        os.path.join(BASE_DIR, "Tesseract-OCR", "tessdata"),
        r"C:\jarvis\jarvis\Tesseract-OCR\tessdata",
        os.path.join(BASE_DIR, "tessdata"),
    ])

    for td in candidates:
        if os.path.isdir(td):
            if not _TESS_INIT_DONE:
                _TESS_INIT_DONE = True
                _ensure_russian_tessdata(td)
            if glob.glob(os.path.join(td, "*.traineddata")):
                os.environ["TESSDATA_PREFIX"] = td
                break
    return "--oem 3"


def _tess():
    import pytesseract
    exe = _find_tesseract_exe()
    if exe:
        pytesseract.pytesseract.tesseract_cmd = exe
        _find_tessdata_config(exe)
    return pytesseract


def _available_tess_lang(pt) -> str:
    """Определяет доступные языки в установленном Tesseract (предпочитает rus+eng)."""
    desired = _scfg().get("ocr_lang", "rus+eng")
    try:
        langs = pt.get_languages(config="")
        if "rus" in langs and "eng" in langs:
            return "rus+eng"
        if "rus" in langs:
            return "rus"
        if "eng" in langs:
            return "eng"
    except Exception:
        pass
    return desired


# ───────────────────────── Предобработка изображения для Tesseract 5 LSTM ─────────────────────────
def preprocess_for_ocr(img: Image.Image, scale: float = 1.5, invert_dark: bool = True) -> tuple:
    """Готовит скриншот для Tesseract 5:
    1. Переводит в оттенки серого.
    2. Если фон тёмный (средняя яркость < 118, как в Telegram/Discord/играх), инвертирует изображение,
       так как LSTM-модели Tesseract обучены на тёмном тексте поверх светлого фона.
    3. Увеличивает масштаб (scale) для мелкого шрифта UI и повышает локальный контраст.
    Возвращает (processed_pil_image, scale_factor).
    """
    gray = img.convert("L")

    try:
        import numpy as np
        arr = np.array(gray)
        mean_val = float(arr.mean())
        if invert_dark and mean_val < 118.0:
            arr = 255 - arr
        try:
            import cv2
            if scale and scale != 1.0:
                new_w = max(1, int(img.width * scale))
                new_h = max(1, int(img.height * scale))
                arr = cv2.resize(arr, (new_w, new_h), interpolation=cv2.INTER_CUBIC)
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            arr = clahe.apply(arr)
            return Image.fromarray(arr), float(scale or 1.0)
        except Exception:
            gray = Image.fromarray(arr)
    except Exception:
        hist = gray.histogram()
        tot = sum(hist) or 1
        mean_val = sum(i * c for i, c in enumerate(hist)) / tot
        if invert_dark and mean_val < 118.0:
            gray = ImageOps.invert(gray)

    if scale and scale != 1.0:
        new_w = max(1, int(gray.width * scale))
        new_h = max(1, int(gray.height * scale))
        resample = getattr(Image, "Resampling", Image).LANCZOS
        gray = gray.resize((new_w, new_h), resample)

    gray = ImageOps.autocontrast(gray, cutoff=1)
    gray = ImageEnhance.Sharpness(gray).enhance(1.5)
    return gray, float(scale or 1.0)


# ───────────────────────── Встроенный резервный OCR Windows 10/11 ─────────────────────────
def _winrt_ocr_data(img: Image.Image) -> list:
    """Резервный движок Windows.Media.Ocr на случай отсутствия языковых пакетов."""
    if os.name != "nt":
        return []
    tmp_img = os.path.join(tempfile.gettempdir(), "jarvis_winocr.png")
    try:
        img.save(tmp_img, "PNG")
    except Exception:
        return []

    ps_script = f"""
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Foundation, ContentType=WindowsRuntime]

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {{
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
}})[0]
Function Await($WinRtTask, $ResultType) {{
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
}}

$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync('{tmp_img}')) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) {{
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language('ru-RU')))
}}
$res = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
$out = @()
$ln = 0
foreach ($line in $res.Lines) {{
    $ln++
    foreach ($w in $line.Words) {{
        $r = $w.BoundingRect
        $out += @{{ t=$w.Text; x=[int]$r.X; y=[int]$r.Y; w=[int]$r.Width; h=[int]$r.Height; l=$ln }}
    }}
}}
$stream.Dispose()
ConvertTo-Json -InputObject $out -Compress
"""
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_script],
            capture_output=True, text=True, encoding="utf-8", timeout=12, creationflags=0x08000000
        )
        raw = (proc.stdout or "").strip()
        if not raw:
            return []
        data = json.loads(raw)
        if isinstance(data, dict):
            data = [data]
        words = []
        for item in data:
            txt = str(item.get("t", "")).strip()
            if txt:
                words.append({
                    "text": txt,
                    "left": int(item.get("x", 0)),
                    "top": int(item.get("y", 0)),
                    "width": int(item.get("w", 0)),
                    "height": int(item.get("h", 0)),
                    "conf": 90.0,
                    "line_key": (1, 1, int(item.get("l", 1))),
                })
        return words
    except Exception:
        return []


def _tesseract_ocr_data(img: Image.Image, scale: float = 1.5, psm: int = 11) -> list:
    """Распознаёт все слова и их точные координаты через официальный Tesseract OCR."""
    pt = _tess()
    from pytesseract import Output
    lang = _available_tess_lang(pt)
    proc_img, sc = preprocess_for_ocr(img, scale=scale, invert_dark=True)
    cfg_str = f"--oem 3 --psm {psm}"
    d = pt.image_to_data(proc_img, lang=lang, config=cfg_str, output_type=Output.DICT)
    words = []
    for i, t in enumerate(d.get("text", [])):
        t = (t or "").strip()
        if not t:
            continue
        try:
            conf = float(d["conf"][i])
        except (TypeError, ValueError):
            conf = 0.0
        if conf < 22:
            continue
        words.append({
            "text": t,
            "left": int(d["left"][i] / sc),
            "top": int(d["top"][i] / sc),
            "width": max(1, int(d["width"][i] / sc)),
            "height": max(1, int(d["height"][i] / sc)),
            "conf": conf,
            "line_key": (d["block_num"][i], d["par_num"][i], d["line_num"][i]),
        })
    return words


def extract_screen_words(img: Image.Image = None) -> list:
    """Извлекает все слова и их координаты с экрана через официальный Tesseract OCR."""
    img = img or grab()
    words = []
    if _find_tesseract_exe():
        try:
            words = _tesseract_ocr_data(img, scale=1.5, psm=11)
        except Exception as e:
            trace(f"Tesseract OCR: {e}")
    if not words:
        words = _winrt_ocr_data(img)
    return words


def ocr_text(img: Image.Image = None) -> str:
    """Возвращает полный распознанный текст с изображения через официальный Tesseract OCR."""
    img = img or grab()
    if _find_tesseract_exe():
        try:
            pt = _tess()
            lang = _available_tess_lang(pt)
            proc_img, _ = preprocess_for_ocr(img, scale=1.5, invert_dark=True)
            text = pt.image_to_string(proc_img, lang=lang, config="--oem 3 --psm 6")
            text = re.sub(r"\n{3,}", "\n\n", text).strip()
            if text:
                return text
        except Exception as e:
            trace(f"Tesseract text fallback: {e}")

    words = _winrt_ocr_data(img)
    if words:
        lines = {}
        for w in words:
            lines.setdefault(w["line_key"], []).append(w["text"])
        return "\n".join(" ".join(ws) for ws in lines.values()).strip()

    raise RuntimeError(
        "Не удалось распознать текст. Проверьте наличие C:\\jarvis\\jarvis\\Tesseract-OCR\\tesseract.exe."
    )


def _clean(w: str) -> str:
    return re.sub(r"[^\w]+", "", normalize(w))


def find_all_text_matches(query: str, img: Image.Image = None, region: tuple = None) -> list:
    """Находит ВСЕ вхождения слова или фразы на экране и возвращает список [(cx, cy, score, matched_str), ...]."""
    tokens = [x for x in (_clean(w) for w in (query or "").split()) if x]
    n = len(tokens)
    if not n:
        return []

    offset_x, offset_y = (int(region[0]), int(region[1])) if region else (0, 0)
    img = img or grab(region=region)

    size = pyautogui.size()
    if region:
        sx, sy = 1.0, 1.0
    else:
        sx, sy = size.width / max(1, img.width), size.height / max(1, img.height)

    engines_to_try = []
    if _find_tesseract_exe():
        engines_to_try.append(lambda: _tesseract_ocr_data(img, scale=1.5, psm=11))
    engines_to_try.append(lambda: _winrt_ocr_data(img))

    matches = []
    for get_words_fn in engines_to_try:
        try:
            words_list = get_words_fn()
        except Exception:
            words_list = []
        if not words_list:
            continue

        lines = {}
        for w in words_list:
            cl = _clean(w["text"])
            if not cl:
                continue
            lines.setdefault(w["line_key"], []).append((cl, w["left"], w["top"], w["width"], w["height"], w["text"]))

        for words in lines.values():
            if len(words) >= n:
                for i in range(len(words) - n + 1):
                    scores = [fuzz.ratio(words[i + j][0], tokens[j]) for j in range(n)]
                    avg_score = sum(scores) / n
                    if all(s >= 74 for s in scores):
                        seg = words[i:i + n]
                        x0, y0 = min(w[1] for w in seg), min(w[2] for w in seg)
                        x1, y1 = max(w[1] + w[3] for w in seg), max(w[2] + w[4] for w in seg)
                        cx = offset_x + (x0 + x1) / 2.0 * sx
                        cy = offset_y + (y0 + y1) / 2.0 * sy
                        raw_str = " ".join(w[5] for w in seg)
                        matches.append((cx, cy, avg_score, raw_str))

        if not matches:
            full_q = "".join(tokens)
            for words in lines.values():
                for w_clean, l_x, t_y, w_w, h_h, raw_w in words:
                    sc = fuzz.WRatio(full_q, w_clean)
                    if sc >= 82 and len(w_clean) >= max(2, len(full_q) - 2):
                        cx = offset_x + (l_x + w_w / 2.0) * sx
                        cy = offset_y + (t_y + h_h / 2.0) * sy
                        matches.append((cx, cy, sc, raw_w))

        if matches:
            break

    matches.sort(key=lambda item: -item[2])
    return matches


def find_text(query: str, img: Image.Image = None, region: tuple = None, occurrence: int = 1):
    """Находит координаты центра (x, y) слова или фразы на экране (учитывает масштаб DPI, region и номер вхождения)."""
    matches = find_all_text_matches(query, img=img, region=region)
    if not matches:
        return None
    idx = max(0, min(len(matches) - 1, int(occurrence or 1) - 1))
    return (matches[idx][0], matches[idx][1])


def _ocr_hint(e: Exception) -> str:
    msg = str(e).lower()
    if "tesseract" in msg and ("not installed" in msg or "not found" in msg or "path" in msg):
        return ("Не найден tesseract.exe. Убедитесь, что папка Tesseract-OCR лежит внутри папки Джарвиса "
                "(например C:\\jarvis\\jarvis\\Tesseract-OCR\\tesseract.exe).")
    if "rus" in msg or "language" in msg or "traineddata" in msg:
        return "В папке Tesseract-OCR\\tessdata нет файла rus.traineddata. Запустите install_tesseract.bat для докачки."
    return f"Не получилось распознать текст: {e}"


# ───────────────────────── Интуитивное зрение (Tesseract OCR + Локальная ИИ-модель) ─────────────────────────
def describe(img, question: str = "") -> str:
    """Осматривает экран через официальный Tesseract OCR + заголовки окон и (если запущена локальная ИИ-модель)
    формирует живой лаконичный ответ без ошибок 503."""
    _h, title, pname = actions.foreground_info()
    open_wins = actions.list_open_windows()
    try:
        txt = ocr_text(img)
    except Exception:
        txt = ""

    clean_ocr = re.sub(r"\s+", " ", (txt or "")).strip()
    LAST["ocr"] = txt or ""

    # Пробуем спросить подключённую локальную текстовую модель пользователя (передав ей распознанный через Tesseract текст!)
    brain_obj = actions.RUNTIME.get("brain")
    if brain_obj and hasattr(brain_obj, "ask_local_llm_direct") and clean_ocr:
        q_part = f"Вопрос пользователя: {question}" if question else "Кратко (в 2-3 предложениях) скажи, что сейчас открыто у пользователя на экране и что там главное написано."
        llm_prompt = (
            f"Активное окно: «{title}» ({pname}).\n"
            f"Другие открытые окна: {open_wins[:250]}\n"
            f"Распознанный через Tesseract OCR текст на экране: {clean_ocr[:1200]}\n\n"
            f"{q_part}"
        )
        ans = brain_obj.ask_local_llm_direct(llm_prompt)
        if ans:
            return ans

    head = f"Сейчас открыто окно «{title}» ({pname}). " if title else ""
    if clean_ocr:
        return f"{head}Вижу на экране (Tesseract OCR): {clean_ocr[:420]}"
    if head:
        return f"{head}Текстовых надписей в окне не обнаружено."
    return "Экран просканирован, активных текстовых окон не найдено."


# ───────────────────────── инструменты (@tool) ─────────────────────────
@tool("Проверить состояние официального Tesseract OCR, путь к tesseract.exe и установленные языки.")
def ocr_status() -> str:
    cleanup_legacy_ocr_folders()
    exe = _find_tesseract_exe()
    if exe:
        pt = _tess()
        langs = _available_tess_lang(pt)
        return f"Официальный Tesseract OCR подключён ({exe}), активные языки: {langs}."
    return "Официальный Tesseract OCR не найден. Проверьте папку Tesseract-OCR\\tesseract.exe."


@tool("Сделать скриншот. mode: full — весь экран (файл в папке Картинки\\Jarvis), area — выделить область мышкой "
      "(попадёт в буфер обмена), window — активное окно (в буфер обмена).",
      mode="full, area или window")
def take_screenshot(mode: str = "full") -> str:
    m = mode.lower()
    if m == "area":
        actions.win_hotkey("win", "shift", "s")
        return "Выделите область мышкой, она попадёт в буфер обмена."
    if m == "window":
        actions.win_hotkey("alt", "printscreen")
        return "Скриншот окна в буфере обмена. Скажите «вставь», чтобы вставить."
    path = os.path.join(_shots_dir(), time.strftime("screenshot_%Y%m%d_%H%M%S.png"))
    grab().save(path)
    return f"Скриншот сохранён: {path}"


@tool("Распознать текст на экране через Tesseract OCR и скопировать его в буфер обмена. area=true — выделить область мышкой, window_only=true — только активное окно.",
      area="true — распознать только выделенную область",
      window_only="true — распознать только активное окно")
def read_screen_text(area: bool = False, window_only: bool = False) -> str:
    try:
        if area:
            img = select_region()
        elif window_only:
            img, _ = grab_active_window()
        else:
            img = grab()
        if img is None:
            return "Область не выбрана."
        text = ocr_text(img)
    except Exception as e:
        return _ocr_hint(e)
    if not text:
        return "Текст на экране не найден."
    LAST["ocr"] = text
    actions.set_clipboard_unicode(text)
    clean_preview = re.sub(r"\s+", " ", text).strip()[:350]
    return f"Распознано {len(text)} симв. (скопировано в буфер): {clean_preview}"


@tool("Распознать текст с экрана или активного окна через Tesseract OCR и прочитать его вслух голосом Джарвиса.",
      area="true — выделить область мышкой",
      window_only="true — читать только активное окно")
def read_aloud_screen(area: bool = False, window_only: bool = True) -> str:
    try:
        if area:
            img = select_region()
        elif window_only:
            img, _ = grab_active_window()
        else:
            img = grab()
        if img is None:
            return "Область не выбрана."
        text = ocr_text(img)
    except Exception as e:
        return _ocr_hint(e)
    if not text:
        return "Текст на экране не обнаружен."
    LAST["ocr"] = text
    clean = re.sub(r"\s+", " ", text).strip()[:700]
    return clean


@tool("Прочитать последние сообщения или текст в активном окне (например в открытом чате Telegram, Discord или в игре) через Tesseract OCR.")
def read_chat_on_screen() -> str:
    try:
        img, _rect = grab_active_window()
        text = ocr_text(img)
    except Exception as e:
        return _ocr_hint(e)
    if not text:
        return "Не удалось распознать текст в текущем окне."
    LAST["ocr"] = text
    lines = [ln.strip() for ln in text.splitlines() if len(ln.strip()) > 1]
    tail = " | ".join(lines[-8:]) if lines else text[:320]
    return f"Текст в окне: {tail[:450]}"


@tool("Просканировать экран через Tesseract OCR, пронумеровать все видимые кнопки/надписи ([1], [2], [3]…) и показать их список.")
def list_screen_elements() -> str:
    try:
        img, rect = grab_active_window()
        off_x, off_y = rect[0], rect[1]
        words = extract_screen_words(img)
    except Exception as e:
        return _ocr_hint(e)
    if not words:
        return "Надписей на экране не обнаружено."

    lines = {}
    for w in words:
        lines.setdefault(w["line_key"], []).append(w)

    phrases = []
    indexed = []
    seen = set()
    idx_num = 1
    for ws in lines.values():
        p = " ".join(w["text"] for w in ws).strip()
        pn = normalize(p)
        if len(pn) >= 2 and pn not in seen:
            seen.add(pn)
            x0 = min(w["left"] for w in ws)
            y0 = min(w["top"] for w in ws)
            x1 = max(w["left"] + w["width"] for w in ws)
            y1 = max(w["top"] + w["height"] for w in ws)
            cx = int(off_x + (x0 + x1) / 2)
            cy = int(off_y + (y0 + y1) / 2)
            indexed.append((idx_num, p, cx, cy))
            phrases.append(f"[{idx_num}] {p}")
            idx_num += 1
            if idx_num > 35:
                break

    LAST["elements"] = [item[1] for item in indexed]
    LAST["indexed_elements"] = indexed
    return "Вижу элементы (можно сказать «нажми номер N»): " + "; ".join(phrases[:25])


@tool("Нажать на пронумерованный элемент экрана по его номеру (после команды «какие кнопки на экране»).",
      number="Номер элемента (1, 2, 3...)",
      double_click="true — двойной клик",
      right_click="true — правый клик")
def click_element_by_number(number: int, double_click: bool = False, right_click: bool = False) -> str:
    if not LAST.get("indexed_elements"):
        list_screen_elements()
    elems = LAST.get("indexed_elements") or []
    target = next((item for item in elems if item[0] == int(number)), None)
    if not target:
        return f"Элемент под номером {number} не найден (всего элементов: {len(elems)})."
    _, label, x, y = target
    pyautogui.moveTo(x, y, duration=0.18)
    if double_click:
        pyautogui.click(x, y, clicks=2, button="left")
        return f"Дважды нажал на [{number}] «{label}» ({x}, {y})."
    if right_click:
        pyautogui.click(x, y, button="right")
        return f"Правый клик на [{number}] «{label}» ({x}, {y})."
    pyautogui.click(x, y, button="left")
    return f"Нажал на [{number}] «{label}» ({x}, {y})."


@tool("Найти слово, кнопку или надпись на экране через Tesseract OCR и навести курсор или кликнуть по ней.",
      text="Слово или надпись на экране",
      click="true — кликнуть левой кнопкой",
      double_click="true — двойной клик",
      right_click="true — правый клик",
      hover="true — только навести курсор",
      occurrence="Какое по счёту совпадение выбрать (1, 2, 3...)")
def find_text_on_screen(
    text: str,
    click: bool = False,
    double_click: bool = False,
    right_click: bool = False,
    hover: bool = False,
    occurrence: int = 1,
) -> str:
    try:
        pos = find_text(text, occurrence=occurrence)
    except Exception as e:
        return _ocr_hint(e)
    if not pos:
        return f"Не вижу на экране надпись «{text}»."
    x, y = int(pos[0]), int(pos[1])
    pyautogui.moveTo(x, y, duration=0.18)
    if double_click:
        pyautogui.click(x, y, clicks=2, button="left")
        return f"Дважды нажал на «{text}» ({x}, {y})."
    if right_click:
        pyautogui.click(x, y, button="right")
        return f"Правый клик на «{text}» ({x}, {y})."
    if click and not hover:
        pyautogui.click(x, y, button="left")
        return f"Нажал на «{text}» ({x}, {y})."
    return f"Нашёл «{text}» ({x}, {y}), курсор наведён."


@tool("Найти поле или кнопку на экране по надписи (Tesseract OCR), кликнуть туда и напечатать текст.",
      target_text="Надпись поля или кнопки на экране (например 'Поиск' или 'Написать сообщение')",
      input_text="Какой текст ввести",
      press_enter="Нажать ли Enter после ввода")
def click_and_type_on_screen(
    target_text: str = "",
    input_text: str = "",
    press_enter: bool = True,
    target_label: str = "",
    text_to_type: str = "",
) -> str:
    target_text = target_text or target_label
    input_text = input_text or text_to_type
    try:
        pos = find_text(target_text)
    except Exception as e:
        return _ocr_hint(e)
    if not pos:
        return f"Не нашёл на экране поле «{target_text}»."
    x, y = int(pos[0]), int(pos[1])
    pyautogui.click(x, y)
    time.sleep(0.2)
    actions.type_text(input_text, press_enter=press_enter)
    return f"Нажал на «{target_text}» и ввёл «{input_text}»."


@tool("Листать (прокручивать) экран или чат вниз/вверх, пока Tesseract OCR не увидит нужный текст, и при необходимости нажать на него.",
      text="Какой текст ищем при прокрутке",
      direction="down (вниз) или up (вверх)",
      max_scrolls="Максимум шагов прокрутки (по умолчанию 8)",
      click="true — автоматически кликнуть по найденному тексту")
def scroll_until_text(text: str, direction: str = "down", max_scrolls: int = 8, click: bool = False) -> str:
    dir_norm = (direction or "down").lower().strip()
    scroll_step = -600 if dir_norm in ("down", "вниз", "низ") else 600
    steps = max(1, min(20, int(max_scrolls or 8)))

    for attempt in range(steps + 1):
        try:
            pos = find_text(text)
        except Exception as e:
            return _ocr_hint(e)
        if pos:
            x, y = int(pos[0]), int(pos[1])
            pyautogui.moveTo(x, y, duration=0.18)
            if click:
                pyautogui.click(x, y, button="left")
                return f"Нашёл «{text}» на шаге {attempt} ({x}, {y}) и нажал!"
            return f"Нашёл «{text}» на шаге {attempt} ({x}, {y}), курсор наведён."
        if attempt < steps:
            pyautogui.scroll(scroll_step)
            time.sleep(0.45)

    return f"Прокрутил экран {steps} раз(а), но надпись «{text}» не появилась."


@tool("Подождать появления надписи или кнопки на экране (например 'Принять', 'Играть', 'Пропустить') через Tesseract OCR и автоматически нажать.",
      text="Какую надпись или кнопку ждём",
      timeout="Сколько секунд ждать (по умолчанию 30)",
      click="true — сразу нажать, когда появится")
def wait_for_text_on_screen(text: str, timeout: int = 30, click: bool = True) -> str:
    wait_secs = max(2, min(180, int(timeout or 30)))
    end_t = time.time() + wait_secs
    trace(f"Tesseract OCR: жду появления «{text}» на экране (до {wait_secs} сек)…")
    while time.time() < end_t:
        try:
            pos = find_text(text)
        except Exception:
            pos = None
        if pos:
            x, y = int(pos[0]), int(pos[1])
            pyautogui.moveTo(x, y, duration=0.15)
            if click:
                pyautogui.click(x, y, button="left")
                return f"Дождался появления «{text}» ({x}, {y}) и нажал!"
            return f"Надпись «{text}» появилась на экране ({x}, {y})!"
        time.sleep(1.0)
    return f"За {wait_secs} сек надпись «{text}» на экране не появилась."


@tool("Распознать иностранный/английский текст на экране через Tesseract OCR и перевести его на русский язык.",
      area="true — выделить область мышкой",
      window_only="true — перевести только активное окно")
def translate_screen_text(area: bool = False, window_only: bool = True) -> str:
    try:
        if area:
            img = select_region()
        elif window_only:
            img, _ = grab_active_window()
        else:
            img = grab()
        if img is None:
            return "Область не выбрана."
        raw_text = ocr_text(img)
    except Exception as e:
        return _ocr_hint(e)

    clean = re.sub(r"\s+", " ", (raw_text or "")).strip()
    if not clean:
        return "Текст для перевода на экране не найден."

    snippet = clean[:900]
    try:
        q = urllib.parse.quote(snippet)
        url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ru&dt=t&q={q}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
        translated = "".join(part[0] for part in (data[0] or []) if part and part[0]).strip()
        if translated:
            actions.set_clipboard_unicode(translated)
            return f"Перевод с экрана (скопирован в буфер): {translated[:450]}"
    except Exception:
        pass

    return f"Распознанный текст (скопирован в буфер): {snippet[:400]}"


@tool("Найти на экране строку, содержащую указанное слово (например код, номер, ошибку), и скопировать всю строку в буфер обмена.",
      query="Слово или часть строки на экране")
def copy_line_with_text(query: str) -> str:
    try:
        text = ocr_text(grab())
    except Exception as e:
        return _ocr_hint(e)
    if not text:
        return "Текст на экране не найден."
    q_norm = normalize(query)
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    best_line = None
    best_score = 0.0
    for ln in lines:
        ln_norm = normalize(ln)
        if q_norm in ln_norm:
            best_line = ln
            break
        sc = fuzz.partial_ratio(q_norm, ln_norm)
        if sc >= 78 and sc > best_score:
            best_score = sc
            best_line = ln
    if not best_line:
        return f"Строка с «{query}» на экране не найдена."
    actions.set_clipboard_unicode(best_line)
    return f"Скопировал строку с экрана: «{best_line}»"


@tool("Сохранить весь распознанный через Tesseract OCR текст с экрана в текстовый файл на Рабочем столе.",
      filename="Имя файла (необязательно)",
      window_only="true — только из активного окна")
def save_screen_text_to_file(filename: str = "", window_only: bool = False) -> str:
    try:
        img = grab_active_window()[0] if window_only else grab()
        text = ocr_text(img)
    except Exception as e:
        return _ocr_hint(e)
    if not text:
        return "Текст на экране не найден."
    fname = (filename or "").strip() or f"экран_OCR_{time.strftime('%Y%m%d_%H%M%S')}.txt"
    if not fname.lower().endswith((".txt", ".md", ".log")):
        fname += ".txt"
    desktop = actions.resolve_path("рабочий стол")
    os.makedirs(desktop, exist_ok=True)
    full_path = os.path.join(desktop, fname)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(text)
    return f"Текст с экрана ({len(text)} симв.) сохранён в файл: {full_path}"


@tool("Посчитать, сколько раз слово или надпись встречается сейчас на экране (через Tesseract OCR).",
      text="Искомое слово или фраза")
def count_text_on_screen(text: str) -> str:
    try:
        matches = find_all_text_matches(text)
    except Exception as e:
        return _ocr_hint(e)
    if not matches:
        return f"Надпись «{text}» на экране сейчас не встречается (0 раз)."
    coords = ", ".join(f"({int(m[0])}, {int(m[1])})" for m in matches[:6])
    return f"Надпись «{text}» найдена на экране {len(matches)} раз(а): {coords}."


@tool("Описать, что сейчас на экране, или ответить на вопрос по экрану (нейросеть или Tesseract OCR).",
      question="Вопрос по экрану (необязательно)")
def describe_screen(question: str = "") -> str:
    try:
        return describe(grab(), question)
    except Exception as e:
        return f"Не получилось осмотреть экран: {e}"


@tool("Найти в интернете фото или картинку с экрана (поиск по картинке через Google Lens). mode: area или full.",
      mode="area или full")
def search_image_online(mode: str = "area") -> str:
    img = select_region() if mode.lower() == "area" else grab()
    if img is None:
        return "Область не выбрана."
    saved = os.path.join(_shots_dir(), time.strftime("search_%Y%m%d_%H%M%S.png"))
    img.save(saved)
    image_to_clipboard(img)
    cfg = _scfg()
    actions._open_url(cfg.get("image_search_url", "https://lens.google.com/"))
    trace("Открываю поиск по картинке…")
    time.sleep(float(cfg.get("image_search_wait", 4)))
    actions.win_hotkey("ctrl", "v")
    return f"Вставил картинку в поиск (файл сохранён: {saved})."


@tool("Нажать на картинку-шаблон (файл из папки images, например кнопка Play) на экране.",
      name="Имя файла картинки без расширения")
def click_picture(name: str) -> str:
    folder = os.path.abspath(_scfg().get("images_dir", "images"))
    if not os.path.isdir(folder):
        return f"Нет папки с картинками: {folder}"
    files = {os.path.splitext(f)[0].lower(): f for f in os.listdir(folder)
             if f.lower().endswith((".png", ".jpg", ".jpeg", ".bmp"))}
    m = process.extractOne(normalize(name), list(files), scorer=fuzz.WRatio, score_cutoff=70) if files else None
    if not m:
        return f"В папке images нет картинки «{name}»."
    return click_image_file(os.path.join(folder, files[m[0]]))


def click_image_file(path: str, confidence: float = 0.85, timeout: float = 8) -> str:
    end = time.time() + timeout
    while time.time() < end:
        try:
            pos = pyautogui.locateCenterOnScreen(path, confidence=confidence)
        except Exception:
            pos = None
        if pos:
            pyautogui.click(pos.x, pos.y)
            return "Нажал."
        time.sleep(0.4)
    return "Не нашёл эту картинку на экране."

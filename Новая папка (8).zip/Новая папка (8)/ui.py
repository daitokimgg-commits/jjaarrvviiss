"""Графический интерфейс Джарвиса с выдвижной боковой панелью (Drawer), выбором цвета и конструктором сценариев:
  1. Чистый главный экран (410x540): только верхняя строка с кнопкой меню «☰», 3D-сфера с симметричными
     глазками, закруглённые карточки сообщений и нижняя капсула ввода.
  2. Открывающаяся боковая панель «☰» (как в современном ИИ-чате, расширяет окно до 710x540):
     • 🎨 Выбор цвета Джарвиса (7 тем: Фиолетовый Неон, Голубой Реактор, Золотой Марк-85, Алый Рубин,
       Изумрудный Неон, Глубокий Сапфир, Розовый Кварц) — меняет цвет 3D-сферы, свечения и рамок чата!
     • 🎙 Голос («★ Настоящий Джарвис (Из фильма)» по умолчанию) и модель распознавания речи (Слух).
     • 🤖 Локальная ИИ-модель (Ollama) с автообновлением.
     • ⚡ Управление сценариями: запуск, удаление ненужных сценариев (🗑) и встроенный конструктор
       своих кастомных сценариев (➕ Создать свой сценарий) с автосохранением в config.yaml!
     • 🚀 Быстрые команды (Мессенджеры, Папка/Блокнот на Рабочем столе, Зрение Tesseract OCR, AI-ревью).
"""
import ctypes
import math
import os
import re
import time

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QScrollArea,
    QLineEdit, QTextEdit, QPushButton, QLabel, QComboBox, QFrame,
    QGraphicsDropShadowEffect, QSizePolicy, QFileDialog
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QEvent, QRectF
from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QLinearGradient, QPainterPath

import actions
import database
from widgets import (
    CoreWidget, LiquidGlassPanel, JARVIS_COLOR_THEMES,
    COLOR_THEME_ORDER, resolve_color_theme_key
)


STATE_LABELS = {
    "sleep":   "Так это выглядит в режиме ожидания · Скажите «Джарвис»",
    "listen":  "Слушаю вас…",
    "think":   "Думаю над ответом…",
    "speak":   "Отвечаю…",
    "muted":   "Микрофон выключен",
    "loading": "Инициализация речевого контура…",
}


def enable_windows_liquid_glass(hwnd: int):
    """Активирует нативное размытие Windows 10/11 (Acrylic / Dark Mode) через ctypes."""
    if os.name != "nt" or not hwnd:
        return
    try:
        dwmapi = ctypes.windll.dwmapi
        dark = ctypes.c_int(1)
        dwmapi.DwmSetWindowAttribute(int(hwnd), 20, ctypes.byref(dark), ctypes.sizeof(dark))
    except Exception:
        pass


# ═════════════════════════ ЗАКРУГЛЁННЫЕ ОБЛАЧКА СООБЩЕНИЙ С ДИНАМИЧЕСКОЙ ОКАНТОВКОЙ ═════════════════════════
class ChatBubbleWidget(QFrame):
    """Закруглённый виджет сообщения (QPainter drawRoundedRect + светящаяся окантовка в цвете Джарвиса)."""

    def __init__(self, text: str, is_user: bool = False, theme_key: str = "violet", parent=None):
        super().__init__(parent)
        self.is_user = is_user
        self.theme_key = theme_key
        self.clean_text = database.strip_cjk(text or "").strip() or (text or "").strip()
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(2, 3, 2, 3)
        outer.setSpacing(0)

        if is_user:
            outer.addStretch(2)

        self.card = _RoundedBubbleCard(is_user=is_user, theme_key=theme_key, parent=self)
        card_layout = QVBoxLayout(self.card)
        card_layout.setContentsMargins(13, 9, 13, 10)
        card_layout.setSpacing(3)

        self.hdr_label = None
        if not is_user:
            self.hdr_label = QLabel("ДЖАРВИС")
            self._update_header_color(theme_key)
            card_layout.addWidget(self.hdr_label)

        self.msg_label = QLabel(self.clean_text)
        self.msg_label.setWordWrap(True)
        self.msg_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.msg_label.setMaximumWidth(295 if not is_user else 275)
        self.msg_label.setStyleSheet("""
            QLabel {
                color: #f5f3ff;
                font-size: 13px;
                line-height: 1.35;
                font-family: 'Segoe UI', sans-serif;
                background: transparent;
                border: none;
            }
        """)
        card_layout.addWidget(self.msg_label)

        outer.addWidget(self.card, 0)

        if not is_user:
            outer.addStretch(1)

    def _update_header_color(self, theme_key: str):
        if self.hdr_label is None:
            return
        theme = JARVIS_COLOR_THEMES.get(theme_key, JARVIS_COLOR_THEMES["violet"])
        br, bg_c, bb = theme["border"]
        self.hdr_label.setStyleSheet(f"""
            QLabel {{
                color: rgb({br}, {bg_c}, {bb});
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 1px;
                font-family: 'Segoe UI', sans-serif;
                background: transparent;
                border: none;
            }}
        """)

    def set_theme(self, theme_key: str):
        self.theme_key = theme_key
        self._update_header_color(theme_key)
        self.card.set_theme(theme_key)


class _RoundedBubbleCard(QFrame):
    """Внутренняя карточка сообщения с идеальными закруглёнными краями (radius=15px) и окантовкой."""

    def __init__(self, is_user: bool = False, theme_key: str = "violet", parent=None):
        super().__init__(parent)
        self.is_user = is_user
        self.theme_key = theme_key
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

    def set_theme(self, theme_key: str):
        self.theme_key = theme_key
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(1.2, 1.2, max(2.0, w - 2.4), max(2.0, h - 2.4))
        radius = 15.0

        theme = JARVIS_COLOR_THEMES.get(self.theme_key, JARVIS_COLOR_THEMES["violet"])
        ar, ag, ab = theme["accent"]
        br, bg_c, bb = theme["border"]
        cr, cg, cb = theme["card_bg"]

        path = QPainterPath()
        path.addRoundedRect(rect, radius, radius)

        if self.is_user:
            bg_grad = QLinearGradient(0, 0, 0, h)
            bg_grad.setColorAt(0.0, QColor(32, 28, 44, 248))
            bg_grad.setColorAt(1.0, QColor(22, 19, 32, 252))
            p.fillPath(path, QBrush(bg_grad))

            border_pen = QPen(QColor(br, bg_c, bb, 95), 1.2)
            p.setPen(border_pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(rect, radius, radius)
        else:
            bg_grad = QLinearGradient(0, 0, w, h)
            bg_grad.setColorAt(0.0, QColor(cr, cg, cb, 248))
            bg_grad.setColorAt(1.0, QColor(max(8, int(cr * 0.68)), max(8, int(cg * 0.68)), max(12, int(cb * 0.68)), 252))
            p.fillPath(path, QBrush(bg_grad))

            border_grad = QLinearGradient(0, 0, w, h)
            border_grad.setColorAt(0.0, QColor(br, bg_c, bb, 228))
            border_grad.setColorAt(0.5, QColor(ar, ag, ab, 195))
            border_grad.setColorAt(1.0, QColor(max(0, ar - 25), max(0, ag - 25), max(0, ab - 25), 165))
            p.setPen(QPen(QBrush(border_grad), 1.35))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(rect, radius, radius)


class ChatLogWidget(QScrollArea):
    """Прокручиваемая лента закруглённых сообщений."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.theme_key = "violet"
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QWidget#chatContainer {
                background: transparent;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 4px;
                border: none;
            }
            QScrollBar::handle:vertical {
                background: rgba(148, 130, 200, 115);
                border-radius: 2px;
                min-height: 24px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(190, 170, 240, 220);
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        self.container = QWidget()
        self.container.setObjectName("chatContainer")
        self.vbox = QVBoxLayout(self.container)
        self.vbox.setContentsMargins(2, 4, 4, 4)
        self.vbox.setSpacing(6)
        self.vbox.addStretch(1)
        self.setWidget(self.container)
        self._plain_log = []
        self._bubbles = []

    def set_theme(self, theme_key: str):
        self.theme_key = theme_key
        for b in self._bubbles:
            try:
                b.set_theme(theme_key)
            except Exception:
                pass

    def add_bubble(self, text: str, is_user: bool = False):
        clean = database.strip_cjk(text or "").strip()
        if not clean:
            return
        prefix = "Вы: " if is_user else "ДЖАРВИС: "
        self._plain_log.append(prefix + clean)

        bubble = ChatBubbleWidget(clean, is_user=is_user, theme_key=self.theme_key, parent=self.container)
        self._bubbles.append(bubble)
        count = self.vbox.count()
        self.vbox.insertWidget(max(0, count - 1), bubble)
        QTimer.singleShot(15, self._scroll_to_bottom)

    def _scroll_to_bottom(self):
        bar = self.verticalScrollBar()
        if bar is not None:
            bar.setValue(bar.maximum())

    def clear(self):
        self._plain_log.clear()
        self._bubbles.clear()
        while self.vbox.count() > 1:
            item = self.vbox.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()

    def toPlainText(self) -> str:
        return "\n".join(self._plain_log)

    def append(self, html_or_text: str):
        raw = re.sub(r"<[^>]+>", " ", str(html_or_text or "")).strip()
        if raw:
            self.add_bubble(raw, is_user=False)


# ───────────────────────── фоновый обработчик запросов ─────────────────────────
class QueryWorker(QThread):
    finished = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, brain, text, from_voice, force_handle_text=False):
        super().__init__()
        self.brain = brain
        self.text = text
        self.from_voice = from_voice
        self.force_handle_text = force_handle_text

    def run(self):
        try:
            self.brain.last_active = time.time()
            if self.force_handle_text:
                answer = self.brain.handle_text(self.text, from_voice=False)
            elif self.from_voice:
                answer = self.brain.handle_voice(self.text)
            else:
                answer = self.brain.process_query(self.text, from_voice=False)
            self.brain.last_active = time.time()
            clean_ans = database.strip_cjk(answer or "")
            self.finished.emit(clean_ans)
        except Exception as e:
            self.failed.emit(f"Ошибка: {e}")


# ───────────────────────── фоновый слушатель аудио ─────────────────────────
class AudioWorker(QThread):
    text_recognized = pyqtSignal(str)
    loaded = pyqtSignal()
    failed = pyqtSignal(str)

    def __init__(self, listener):
        super().__init__()
        self.listener = listener

    def run(self):
        if self.listener is None:
            self.failed.emit("Микрофон недоступен")
            return
        try:
            self.listener.listen_stream(
                lambda t: self.text_recognized.emit(t),
                on_loaded=lambda: self.loaded.emit(),
                on_error=lambda msg: self.failed.emit(msg),
            )
        except Exception as e:
            print(f"Ошибка потока прослушивания: {e}")
            self.failed.emit(str(e))


# ═════════════════════════ ГЛАВНОЕ ОКНО ДЖАРВИСА ═════════════════════════
class JarvisUI(QWidget):
    sig_jarvis_msg = pyqtSignal(str)
    sig_trace_msg = pyqtSignal(str, str)
    sig_color_changed = pyqtSignal(str)
    sig_style_changed = pyqtSignal(str)
    sig_sidebar_toggle = pyqtSignal(bool)
    sig_scenarios_updated = pyqtSignal()

    COMPACT_WIDTH = 410
    EXPANDED_WIDTH = 710
    WINDOW_HEIGHT = 550

    def __init__(self, brain, speaker, listener):
        super().__init__()
        self.brain = brain
        self.speaker = speaker
        self.listener = listener
        self.listener_available = listener is not None
        self.is_muted = False
        self.is_pinned = False
        self.sidebar_open = False
        self.theme_key = resolve_color_theme_key((brain.cfg or {}).get("ui_color", "violet"))
        self.worker = None
        self.query_worker = None
        self._drag_pos = None
        self._loading = self.listener_available
        self._cmd_history = []
        self._cmd_index = -1
        self._query_started_at = 0.0
        self._terminal_minimized = True
        self._color_swatch_btns = {}

        self.sig_jarvis_msg.connect(self._append_jarvis_slot)
        self.sig_trace_msg.connect(self._append_trace_slot)
        self.sig_color_changed.connect(self._apply_color_theme_slot)
        self.sig_style_changed.connect(self._apply_visual_style_slot)
        self.sig_sidebar_toggle.connect(self._set_sidebar_open_slot)
        self.sig_scenarios_updated.connect(self._refresh_scenarios_combo)

        # Регистрируем колбэки в actions.RUNTIME для голосового управления цветом, панелью и сценариями
        actions.RUNTIME["set_ui_color"] = lambda k: self.sig_color_changed.emit(str(k))
        actions.RUNTIME["set_visual_style"] = lambda s: self.sig_style_changed.emit(str(s))
        actions.RUNTIME["toggle_sidebar"] = lambda open_flag: self.sig_sidebar_toggle.emit(bool(open_flag))
        actions.RUNTIME["refresh_scenarios_ui"] = lambda: self.sig_scenarios_updated.emit()

        self._setup_window()
        self._build_ui()
        self._wire_signals()
        self._apply_color_theme_slot(self.theme_key, announce=False)

        try:
            enable_windows_liquid_glass(int(self.winId()))
        except Exception:
            pass

        if self._loading:
            self._set_state("loading")
        else:
            self._set_state("sleep")

        if self.listener_available:
            self._start_listener()

        self._bg_time = 0.0
        self._bg_timer = QTimer(self)
        self._bg_timer.timeout.connect(self._on_bg_tick)
        self._bg_timer.start(80)

    def _setup_window(self):
        self.setWindowTitle("J.A.R.V.I.S.")
        self.resize(self.COMPACT_WIDTH, self.WINDOW_HEIGHT)
        self.setMinimumSize(375, 475)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._current_state = "sleep"

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)

        self.panel = LiquidGlassPanel(self)
        self.panel.setObjectName("liquidGlassPanel")

        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(32)
        self.shadow.setColor(QColor(124, 58, 237, 90))
        self.shadow.setOffset(0, 0)
        self.panel.setGraphicsEffect(self.shadow)

        outer.addWidget(self.panel)

        # Горизонтальный контейнер: [ Выдвижная Боковая Панель (слева) | Главный экран Джарвиса (справа) ]
        self.root_hbox = QHBoxLayout(self.panel)
        self.root_hbox.setContentsMargins(12, 10, 14, 12)
        self.root_hbox.setSpacing(10)

        # 1. Выдвижная боковая панель (по умолчанию скрыта — открывается по кнопке «☰»)
        self._build_side_drawer()
        self.root_hbox.addWidget(self.sidebar_frame, 0)

        # 2. Правая основная колонка: Шапка -> 3D-сфера -> Лента чата -> Статус -> Ввод
        main_col = QVBoxLayout()
        main_col.setContentsMargins(2, 0, 2, 0)
        main_col.setSpacing(6)

        self._build_title_bar(main_col)

        self.core = CoreWidget(listener=self.listener, brain=self.brain)
        main_col.addWidget(self.core)

        self.log_area = ChatLogWidget(self.panel)
        main_col.addWidget(self.log_area, 1)

        self.status_label = QLabel("Готов к работе · Нажмите «☰» слева вверху для открытия всех функций")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet("""
            QLabel {
                color: #7c7398;
                font-size: 11px;
                font-family: 'Segoe UI', sans-serif;
                background: transparent;
                padding: 1px 0;
            }
        """)
        main_col.addWidget(self.status_label)

        self._build_input(main_col)
        self.root_hbox.addLayout(main_col, 1)

    # ═════════════════════════ ВЫДВИЖНАЯ БОКОВАЯ ПАНЕЛЬ (DRAWER) ═════════════════════════
    def _build_side_drawer(self):
        self.sidebar_frame = QFrame(self.panel)
        self.sidebar_frame.setFixedWidth(282)
        self.sidebar_frame.setStyleSheet("""
            QFrame#sideDrawerFrame {
                background-color: rgba(18, 15, 30, 235);
                border: 1px solid rgba(148, 130, 210, 55);
                border-radius: 16px;
            }
        """)
        self.sidebar_frame.setObjectName("sideDrawerFrame")

        sb_outer = QVBoxLayout(self.sidebar_frame)
        sb_outer.setContentsMargins(8, 8, 8, 8)
        sb_outer.setSpacing(6)

        # Заголовок боковой панели
        sb_hdr = QHBoxLayout()
        sb_title = QLabel("⚙ ПАНЕЛЬ ФУНКЦИЙ")
        sb_title.setStyleSheet("""
            QLabel {
                color: #ddd6fe;
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 1px;
                background: transparent;
                border: none;
            }
        """)
        sb_hdr.addWidget(sb_title)
        sb_hdr.addStretch()

        close_sb_btn = QPushButton("✕")
        close_sb_btn.setFixedSize(22, 20)
        close_sb_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_sb_btn.setToolTip("Скрыть боковую панель")
        close_sb_btn.setStyleSheet(self._icon_btn_style())
        close_sb_btn.clicked.connect(lambda: self._set_sidebar_open_slot(False))
        sb_hdr.addWidget(close_sb_btn)
        sb_outer.addLayout(sb_hdr)

        # Прокручиваемая область боковой панели
        self.sb_scroll = QScrollArea(self.sidebar_frame)
        self.sb_scroll.setWidgetResizable(True)
        self.sb_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.sb_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.sb_scroll.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QWidget#sbContent { background: transparent; }
            QScrollBar:vertical { background: transparent; width: 4px; border: none; }
            QScrollBar::handle:vertical { background: rgba(148, 130, 200, 100); border-radius: 2px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        """)

        sb_content = QWidget()
        sb_content.setObjectName("sbContent")
        sb = QVBoxLayout(sb_content)
        sb.setContentsMargins(2, 2, 4, 4)
        sb.setSpacing(8)

        # ─── 1. ЦВЕТ ДЖАРВИСА ───
        sb.addWidget(self._section_label("🎨 ЦВЕТ ДЖАРВИСА"))

        swatches_row = QHBoxLayout()
        swatches_row.setSpacing(5)
        for tkey in COLOR_THEME_ORDER:
            tinfo = JARVIS_COLOR_THEMES[tkey]
            btn = QPushButton("")
            btn.setFixedSize(28, 24)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setToolTip(tinfo["title"])
            btn.clicked.connect(lambda _c=False, k=tkey: self._on_color_selected(k))
            self._color_swatch_btns[tkey] = btn
            swatches_row.addWidget(btn)
        swatches_row.addStretch()
        sb.addLayout(swatches_row)

        self.color_combo = QComboBox()
        for tkey in COLOR_THEME_ORDER:
            self.color_combo.addItem(JARVIS_COLOR_THEMES[tkey]["title"])
        self.color_combo.setStyleSheet(self._combo_style())
        sb.addWidget(self.color_combo)

        # ─── 2. СТИЛЬ (ДЖАРВИС / ВЕРИТИ), ГОЛОС И СЛУХ ───
        sb.addWidget(self._section_label("✨ СТИЛЬ И ГОЛОС (JARVIS-SOUND / ВЕРИТИ)"))

        style_row = QHBoxLayout()
        style_row.setSpacing(4)
        self.style_jarvis_btn = QPushButton("🤖 Джарвис (Оригинал)")
        self.style_jarvis_btn.setCheckable(True)
        self.style_jarvis_btn.setChecked(True)
        self.style_jarvis_btn.setFixedHeight(25)
        self.style_jarvis_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.style_jarvis_btn.setToolTip("Оригинальный голос из FitoDomik/Jarvis-Sound + тактическое ядро HUD")
        self.style_jarvis_btn.setStyleSheet(self._pill_btn_style(font_size=10))
        self.style_jarvis_btn.clicked.connect(lambda: self._on_style_btn_clicked("jarvis"))
        style_row.addWidget(self.style_jarvis_btn)

        self.style_verity_btn = QPushButton("✨ Стиль Верити")
        self.style_verity_btn.setCheckable(True)
        self.style_verity_btn.setFixedHeight(25)
        self.style_verity_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.style_verity_btn.setToolTip("Стиль Верити (Verity): живой дружеский голос + гладкая 3D-сфера с глазками")
        self.style_verity_btn.setStyleSheet(self._pill_btn_style(font_size=10))
        self.style_verity_btn.clicked.connect(lambda: self._on_style_btn_clicked("verity"))
        style_row.addWidget(self.style_verity_btn)
        sb.addLayout(style_row)

        self.voice_combo = QComboBox()
        self._voice_items = [
            ("jarvis", "★ Настоящий Джарвис (Jarvis-Sound + Фильм)"),
            ("verity", "✨ Верити (Стиль Verity / Друг-помощник)"),
            ("dmitry", "🎙 Дмитрий (Мягкий баритон)"),
            ("friday", "🎙 Пятница / Светлана"),
            ("ruslan", "🎙 Руслан (Глубокий диктор)"),
            ("irina",  "🎙 Ирина (Тёплый женский)"),
            ("denis",  "🎙 Денис (Быстрый)"),
        ]
        for _vk, vlabel in self._voice_items:
            self.voice_combo.addItem(vlabel)
        self.voice_combo.setToolTip("Выбор голоса Джарвиса (основной — Настоящий Джарвис из FitoDomik/Jarvis-Sound, либо стиль Верити)")
        self.voice_combo.setStyleSheet(self._combo_style())
        sb.addWidget(self.voice_combo)

        self.stt_combo = QComboBox()
        self._stt_items = [
            ("multipath_pro", "🎧 Слух: Multipath Pro (Whisper + Google)"),
            ("whisper_base",  "🚀 Слух: Whisper Base (Быстрая офлайн)"),
            ("whisper_small", "🧠 Слух: Whisper Small (Точная офлайн)"),
            ("whisper_turbo", "🔥 Слух: Whisper Large-v3-Turbo"),
            ("google_direct", "🌐 Слух: Google Direct (Без прокси)"),
        ]
        for _sk, slabel in self._stt_items:
            self.stt_combo.addItem(slabel)
        self.stt_combo.setToolTip("Модель распознавания речи")
        self.stt_combo.setStyleSheet(self._combo_style())
        sb.addWidget(self.stt_combo)

        self.mic_combo = QComboBox()
        self._mic_items = actions.get_microphone_devices()
        for _mdev, mlabel in self._mic_items:
            self.mic_combo.addItem(mlabel)
        self.mic_combo.setToolTip("Выбор микрофона из списка аудиоустройств Windows")
        self.mic_combo.setStyleSheet(self._combo_style())
        sb.addWidget(self.mic_combo)

        # ─── 3. ЛОКАЛЬНАЯ ИИ-МОДЕЛЬ (OLLAMA) ───
        sb.addWidget(self._section_label("🤖 ЛОКАЛЬНАЯ ИИ-МОДЕЛЬ (OLLAMA)"))
        ai_row = QHBoxLayout()
        ai_row.setSpacing(4)
        self.model_combo = QComboBox()
        self.model_combo.setStyleSheet(self._combo_style())
        ai_row.addWidget(self.model_combo, 1)

        self.refresh_models_btn = QPushButton("🔄")
        self.refresh_models_btn.setFixedSize(28, 25)
        self.refresh_models_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refresh_models_btn.setToolTip("Обновить список ваших локальных моделей Ollama")
        self.refresh_models_btn.setStyleSheet(self._pill_btn_style())
        self.refresh_models_btn.clicked.connect(self._refresh_local_models)
        ai_row.addWidget(self.refresh_models_btn)
        sb.addLayout(ai_row)

        # ─── 4. СЦЕНАРИИ: ЗАПУСК, ДОБАВЛЕНИЕ СВОИХ И УДАЛЕНИЕ ───
        sb.addWidget(self._section_label("⚡ СЦЕНАРИИ (ЗАПУСК · СВОИ · УДАЛЕНИЕ)"))

        scen_row = QHBoxLayout()
        scen_row.setSpacing(4)
        self.scenario_combo = QComboBox()
        self.scenario_combo.setStyleSheet(self._combo_style())
        scen_row.addWidget(self.scenario_combo, 1)

        self.run_scen_btn = QPushButton("▶")
        self.run_scen_btn.setFixedSize(28, 25)
        self.run_scen_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.run_scen_btn.setToolTip("Запустить выбранный сценарий")
        self.run_scen_btn.setStyleSheet(self._pill_btn_style(accent="#ffffff"))
        scen_row.addWidget(self.run_scen_btn)

        self.del_scen_btn = QPushButton("🗑")
        self.del_scen_btn.setFixedSize(28, 25)
        self.del_scen_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.del_scen_btn.setToolTip("Удалить выбранный сценарий из Джарвиса")
        self.del_scen_btn.setStyleSheet(self._pill_btn_style(accent="#fca5a5"))
        self.del_scen_btn.clicked.connect(self._on_delete_selected_scenario)
        scen_row.addWidget(self.del_scen_btn)
        sb.addLayout(scen_row)

        builder_btns_row = QHBoxLayout()
        builder_btns_row.setSpacing(4)
        self.toggle_builder_btn = QPushButton("➕ Создать свой сценарий")
        self.toggle_builder_btn.setFixedHeight(26)
        self.toggle_builder_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toggle_builder_btn.setStyleSheet(self._pill_btn_style())
        self.toggle_builder_btn.clicked.connect(self._toggle_scenario_builder)
        builder_btns_row.addWidget(self.toggle_builder_btn, 1)

        self.edit_scen_btn = QPushButton("✏ Изменить")
        self.edit_scen_btn.setFixedSize(74, 26)
        self.edit_scen_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.edit_scen_btn.setToolTip("Загрузить выбранный сценарий в конструктор для редактирования")
        self.edit_scen_btn.setStyleSheet(self._pill_btn_style(font_size=10))
        self.edit_scen_btn.clicked.connect(self._on_load_selected_scenario_to_builder)
        builder_btns_row.addWidget(self.edit_scen_btn)
        sb.addLayout(builder_btns_row)

        # Выпадающий конструктор кастомного сценария (любые сайты и любые приложения на выбор пользователя!)
        self.builder_frame = QFrame()
        self.builder_frame.setStyleSheet("""
            QFrame {
                background-color: rgba(26, 21, 44, 225);
                border: 1px solid rgba(139, 92, 246, 85);
                border-radius: 10px;
            }
        """)
        bf_layout = QVBoxLayout(self.builder_frame)
        bf_layout.setContentsMargins(7, 7, 7, 7)
        bf_layout.setSpacing(5)

        input_style_small = """
            QLineEdit {
                background-color: #131020;
                border: 1px solid rgba(148, 130, 210, 80);
                border-radius: 7px;
                padding: 3px 6px;
                color: #f5f3ff;
                font-size: 11px;
            }
        """

        self.scen_name_input = QLineEdit()
        self.scen_name_input.setPlaceholderText("1. Название сценария (напр.: мой запуск)")
        self.scen_name_input.setStyleSheet(input_style_small)
        bf_layout.addWidget(self.scen_name_input)

        # Добавление ЛЮБОГО сайта (или нескольких сайтов сразу)
        site_add_row = QHBoxLayout()
        site_add_row.setSpacing(4)
        self.custom_site_input = QLineEdit()
        self.custom_site_input.setPlaceholderText("Любые сайты: youtube.com, ozon.ru, кинопоиск…")
        self.custom_site_input.setStyleSheet(input_style_small)
        self.custom_site_input.returnPressed.connect(self._on_add_custom_site_step)
        site_add_row.addWidget(self.custom_site_input, 1)

        add_site_btn = QPushButton("+ 🌐 Сайт")
        add_site_btn.setFixedSize(68, 23)
        add_site_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        add_site_btn.setToolTip("Добавить открытие этого сайта (или нескольких сайтов через запятую) в сценарий")
        add_site_btn.setStyleSheet(self._pill_btn_style(font_size=10))
        add_site_btn.clicked.connect(self._on_add_custom_site_step)
        site_add_row.addWidget(add_site_btn)
        bf_layout.addLayout(site_add_row)

        # Добавление ЛЮБОГО приложения / игры (по имени, пути или через проводник .exe/.lnk)
        app_add_row = QHBoxLayout()
        app_add_row.setSpacing(4)
        self.custom_app_input = QLineEdit()
        self.custom_app_input.setPlaceholderText("Любая программа/игра или путь C:\…\app.exe")
        self.custom_app_input.setStyleSheet(input_style_small)
        self.custom_app_input.returnPressed.connect(self._on_add_custom_app_step)
        app_add_row.addWidget(self.custom_app_input, 1)

        add_app_btn = QPushButton("+ 🚀 Прогр.")
        add_app_btn.setFixedSize(68, 23)
        add_app_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        add_app_btn.setToolTip("Добавить открытие этой программы или игры в сценарий")
        add_app_btn.setStyleSheet(self._pill_btn_style(font_size=10))
        add_app_btn.clicked.connect(self._on_add_custom_app_step)
        app_add_row.addWidget(add_app_btn)
        bf_layout.addLayout(app_add_row)

        browse_exe_btn = QPushButton("📂 Выбрать любые .exe / ярлыки на ПК…")
        browse_exe_btn.setFixedHeight(23)
        browse_exe_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        browse_exe_btn.setToolTip("Открыть проводник Windows и выбрать одну или сразу несколько программ/игр (.exe, .lnk, .bat, .url)")
        browse_exe_btn.setStyleSheet(self._pill_btn_style(font_size=10, accent="#c4b5fd"))
        browse_exe_btn.clicked.connect(self._on_browse_exe_for_scenario)
        bf_layout.addWidget(browse_exe_btn)

        self.scen_steps_input = QTextEdit()
        self.scen_steps_input.setPlaceholderText(
            "Все шаги сценария (по одному на строке):\n"
            "открой сайт youtube.com\n"
            "открой сайт ozon.ru\n"
            "открой C:\\Games\\game.exe\n"
            "громкость 40"
        )
        self.scen_steps_input.setFixedHeight(82)
        self.scen_steps_input.setStyleSheet("""
            QTextEdit {
                background-color: #131020;
                border: 1px solid rgba(148, 130, 210, 75);
                border-radius: 7px;
                padding: 3px 6px;
                color: #f5f3ff;
                font-size: 11px;
            }
        """)
        bf_layout.addWidget(self.scen_steps_input)

        # Быстрые кнопки-добавки для конструктора сценариев
        chips_grid = QGridLayout()
        chips_grid.setSpacing(3)
        chip_templates = [
            ("+ Громк. 40", "громкость 40"),
            ("+ Пауза 2с", "подожди 2"),
            ("+ Сказать", "скажи Все сайты и программы запущены"),
            ("+ Обход", "включи обход"),
            ("+ Свернуть", "сверни все окна"),
            ("🧹 Очистить", "__CLEAR__"),
        ]
        for idx_c, (clabel, cstep) in enumerate(chip_templates):
            cb = QPushButton(clabel)
            cb.setFixedHeight(21)
            cb.setCursor(Qt.CursorShape.PointingHandCursor)
            cb.setStyleSheet(self._pill_btn_style(font_size=10))
            cb.clicked.connect(lambda _ch=False, s=cstep: self._append_step_chip(s))
            chips_grid.addWidget(cb, idx_c // 3, idx_c % 3)
        bf_layout.addLayout(chips_grid)

        self.save_scen_btn = QPushButton("💾 Сохранить свой сценарий")
        self.save_scen_btn.setFixedHeight(27)
        self.save_scen_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.save_scen_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(124, 58, 237, 210);
                border: 1px solid #a78bfa;
                border-radius: 8px;
                color: #ffffff;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: rgba(139, 92, 246, 245);
            }
        """)
        self.save_scen_btn.clicked.connect(self._on_save_custom_scenario)
        bf_layout.addWidget(self.save_scen_btn)

        self.builder_frame.hide()
        sb.addWidget(self.builder_frame)

        # ─── 5. БЫСТРЫЕ КОМАНДЫ, ФАЙЛЫ И ЗРЕНИЕ OCR ───
        sb.addWidget(self._section_label("🚀 БЫСТРЫЕ ФУНКЦИИ И ЗРЕНИЕ OCR"))

        quick_grid = QGridLayout()
        quick_grid.setSpacing(4)
        quick_actions = [
            ("Telegram", "открой телеграм"),
            ("Даня (ТГ)", "открой чат с даней в телеграме"),
            ("Варюша (ТГ)", "открой чат с варюшей в телеграме"),
            ("Discord", "открой дискорд"),
            ("Вкл. Обход", "включи обход"),
            ("📁 +Папка", "создай папку на рабочем столе"),
            ("📝 +Блокнот", "создай блокнот на рабочем столе"),
            ("👁 Что тут", "что у меня на экране"),
            ("📄 Читать OCR", "прочитай экран"),
            ("🔊 Озвучить", "озвучь окно"),
            ("🌐 Перевод", "переведи окно"),
            ("🎯 Кнопки", "какие кнопки на экране"),
        ]
        for idx_q, (qlabel, qcmd) in enumerate(quick_actions):
            qb = QPushButton(qlabel)
            qb.setFixedHeight(25)
            qb.setCursor(Qt.CursorShape.PointingHandCursor)
            qb.setStyleSheet(self._pill_btn_style(font_size=11))
            qb.clicked.connect(lambda _c=False, c=qcmd: self._run_quick_cmd(c))
            quick_grid.addWidget(qb, idx_q // 2, idx_q % 2)
        sb.addLayout(quick_grid)

        # ─── 5.5 КОНТАКТЫ МЕССЕНДЖЕРОВ (ДОБАВЛЕНИЕ И ОТКРЫТИЕ) ───
        sb.addWidget(self._section_label("👥 СВОИ КОНТАКТЫ (TELEGRAM / DISCORD)"))

        ct_row = QHBoxLayout()
        ct_row.setSpacing(4)
        self.contact_combo = QComboBox()
        self.contact_combo.setStyleSheet(self._combo_style())
        ct_row.addWidget(self.contact_combo, 1)

        open_ct_btn = QPushButton("💬")
        open_ct_btn.setFixedSize(28, 25)
        open_ct_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        open_ct_btn.setToolTip("Открыть чат с выбранным контактом")
        open_ct_btn.setStyleSheet(self._pill_btn_style(accent="#ffffff"))
        open_ct_btn.clicked.connect(self._on_open_selected_contact)
        ct_row.addWidget(open_ct_btn)

        del_ct_btn = QPushButton("🗑")
        del_ct_btn.setFixedSize(28, 25)
        del_ct_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        del_ct_btn.setToolTip("Удалить выбранный контакт")
        del_ct_btn.setStyleSheet(self._pill_btn_style(accent="#fca5a5"))
        del_ct_btn.clicked.connect(self._on_delete_selected_contact)
        ct_row.addWidget(del_ct_btn)
        sb.addLayout(ct_row)

        self.toggle_ct_btn = QPushButton("➕ Добавить свой контакт")
        self.toggle_ct_btn.setFixedHeight(24)
        self.toggle_ct_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toggle_ct_btn.setStyleSheet(self._pill_btn_style(font_size=10))
        self.toggle_ct_btn.clicked.connect(self._toggle_contact_builder)
        sb.addWidget(self.toggle_ct_btn)

        self.ct_builder_frame = QFrame()
        self.ct_builder_frame.setStyleSheet("""
            QFrame {
                background-color: rgba(26, 21, 44, 215);
                border: 1px solid rgba(139, 92, 246, 75);
                border-radius: 10px;
            }
        """)
        ctf_l = QVBoxLayout(self.ct_builder_frame)
        ctf_l.setContentsMargins(7, 6, 7, 6)
        ctf_l.setSpacing(4)

        self.ct_name_input = QLineEdit()
        self.ct_name_input.setPlaceholderText("Имя контакта (напр.: макс)")
        self.ct_name_input.setStyleSheet(input_style_small)
        ctf_l.addWidget(self.ct_name_input)

        self.ct_user_input = QLineEdit()
        self.ct_user_input.setPlaceholderText("@username или как записан в чате")
        self.ct_user_input.setStyleSheet(input_style_small)
        ctf_l.addWidget(self.ct_user_input)

        ct_bot_row = QHBoxLayout()
        ct_bot_row.setSpacing(4)
        self.ct_msg_combo = QComboBox()
        self.ct_msg_combo.addItems(["Телеграм", "Дискорд", "Ватсап"])
        self.ct_msg_combo.setStyleSheet(self._combo_style())
        ct_bot_row.addWidget(self.ct_msg_combo, 1)

        save_ct_btn = QPushButton("💾 Сохранить")
        save_ct_btn.setFixedHeight(24)
        save_ct_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        save_ct_btn.setStyleSheet(self._pill_btn_style(font_size=10, accent="#ffffff"))
        save_ct_btn.clicked.connect(self._on_save_custom_contact)
        ct_bot_row.addWidget(save_ct_btn)
        ctf_l.addLayout(ct_bot_row)

        self.ct_builder_frame.hide()
        sb.addWidget(self.ct_builder_frame)

        # ─── 6. СИСТЕМНЫЕ ПЕРЕКЛЮЧАТЕЛИ, АВТОСКАНЕР И ПЛАГИНЫ ───
        sb.addWidget(self._section_label("🛠 ИНСТРУМЕНТЫ СИСТЕМЫ И ПЛАГИНЫ"))
        tools_row = QHBoxLayout()
        tools_row.setSpacing(4)

        self.dict_btn = QPushButton("✍ Диктовка")
        self.dict_btn.setCheckable(True)
        self.dict_btn.setFixedHeight(25)
        self.dict_btn.setStyleSheet(self._pill_btn_style(font_size=11))
        tools_row.addWidget(self.dict_btn)

        self.term_btn = QPushButton("🖥 Терминал")
        self.term_btn.setFixedHeight(25)
        self.term_btn.setStyleSheet(self._pill_btn_style(font_size=11))
        self.term_btn.clicked.connect(self._on_toggle_terminal)
        tools_row.addWidget(self.term_btn)

        self.glass_btn = QPushButton("💧 Фон")
        self.glass_btn.setFixedHeight(25)
        self.glass_btn.setStyleSheet(self._pill_btn_style(font_size=11))
        self.glass_btn.clicked.connect(self._on_cycle_glass)
        tools_row.addWidget(self.glass_btn)
        sb.addLayout(tools_row)

        scan_plug_row = QHBoxLayout()
        scan_plug_row.setSpacing(4)
        self.scan_pc_btn = QPushButton("🔍 Сканировать игры/ПК")
        self.scan_pc_btn.setFixedHeight(24)
        self.scan_pc_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.scan_pc_btn.setToolTip("Автоматически найти все установленные игры Steam и программы на ПК")
        self.scan_pc_btn.setStyleSheet(self._pill_btn_style(font_size=10))
        self.scan_pc_btn.clicked.connect(lambda: self._run_quick_cmd("просканируй пк"))
        scan_plug_row.addWidget(self.scan_pc_btn, 1)

        self.plugins_btn = QPushButton("🧩 Плагины")
        self.plugins_btn.setFixedHeight(24)
        self.plugins_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.plugins_btn.setToolTip("Перезагрузить пользовательские плагины из папки plugins/")
        self.plugins_btn.setStyleSheet(self._pill_btn_style(font_size=10))
        self.plugins_btn.clicked.connect(lambda: self._run_quick_cmd("перезагрузи плагины"))
        scan_plug_row.addWidget(self.plugins_btn)
        sb.addLayout(scan_plug_row)

        # Совместимость со старой кнопкой переключения голоса
        self.voice_cycle_btn = QPushButton("🗣 Сменить голос")
        self.voice_cycle_btn.setFixedHeight(24)
        self.voice_cycle_btn.setStyleSheet(self._pill_btn_style(font_size=11))
        self.voice_cycle_btn.clicked.connect(self._on_cycle_voice)
        sb.addWidget(self.voice_cycle_btn)

        sb.addStretch(1)
        self.sb_scroll.setWidget(sb_content)
        sb_outer.addWidget(self.sb_scroll, 1)

        self._refresh_scenarios_combo()
        self._refresh_contacts_combo()
        self._populate_local_models(initial=True)
        self.sidebar_frame.hide()

    @staticmethod
    def _section_label(text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setStyleSheet("""
            QLabel {
                color: #9d94ba;
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 0.8px;
                margin-top: 3px;
                background: transparent;
                border: none;
            }
        """)
        return lbl

    def _build_title_bar(self, parent_layout):
        bar = QHBoxLayout()
        bar.setContentsMargins(2, 0, 2, 0)
        bar.setSpacing(4)

        # Кнопка открытия/закрытия выдвижной боковой панели «☰»
        self.menu_btn = QPushButton("☰")
        self.menu_btn.setCheckable(True)
        self.menu_btn.setFixedSize(28, 24)
        self.menu_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.menu_btn.setToolTip("Открыть / скрыть боковую панель всех функций Джарвиса")
        self.menu_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 10);
                border: 1px solid rgba(167, 139, 250, 80);
                border-radius: 7px;
                color: #ede9fe;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(124, 58, 237, 145);
                color: #ffffff;
            }
            QPushButton:checked {
                background-color: rgba(124, 58, 237, 195);
                border: 1px solid #c4b5fd;
                color: #ffffff;
            }
        """)
        self.menu_btn.clicked.connect(self._on_toggle_sidebar)
        bar.addWidget(self.menu_btn)

        title = QLabel("J.A.R.V.I.S.")
        title.setStyleSheet("""
            QLabel {
                color: #8b82a8;
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 2px;
                font-family: 'Segoe UI', sans-serif;
                background: transparent;
                margin-left: 4px;
            }
        """)
        bar.addWidget(title)
        bar.addStretch()

        self.mute_btn = QPushButton("🎙")
        self.mute_btn.setCheckable(True)
        self.mute_btn.setFixedSize(24, 22)
        self.mute_btn.setToolTip("Включить / выключить микрофон")
        self.mute_btn.setStyleSheet(self._toggle_btn_style())
        bar.addWidget(self.mute_btn)

        self.tts_btn = QPushButton("🔊")
        self.tts_btn.setCheckable(True)
        self.tts_btn.setChecked(bool(self.speaker and self.speaker.muted))
        self.tts_btn.setFixedSize(24, 22)
        self.tts_btn.setToolTip("Включить / выключить озвучку голосом")
        self.tts_btn.setStyleSheet(self._toggle_btn_style())
        bar.addWidget(self.tts_btn)

        self.pin_btn = QPushButton("📌")
        self.pin_btn.setCheckable(True)
        self.pin_btn.setFixedSize(24, 22)
        self.pin_btn.setToolTip("Закрепить поверх всех окон")
        self.pin_btn.setStyleSheet(self._icon_btn_style())
        self.pin_btn.clicked.connect(self._toggle_pin)
        bar.addWidget(self.pin_btn)

        self.stop_btn = QPushButton("⏹")
        self.stop_btn.setFixedSize(24, 22)
        self.stop_btn.setToolTip("Остановить речь или прервать сценарий")
        self.stop_btn.setStyleSheet(self._icon_btn_style(color="#d8b4fe"))
        bar.addWidget(self.stop_btn)

        self.clear_btn = QPushButton("🗑")
        self.clear_btn.setFixedSize(24, 22)
        self.clear_btn.setToolTip("Очистить чат")
        self.clear_btn.setStyleSheet(self._icon_btn_style())
        bar.addWidget(self.clear_btn)

        min_btn = QPushButton("—")
        min_btn.setFixedSize(24, 22)
        min_btn.setStyleSheet(self._icon_btn_style())
        min_btn.clicked.connect(self.showMinimized)
        bar.addWidget(min_btn)

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(24, 22)
        close_btn.setStyleSheet(self._icon_btn_style(hover_bg="rgba(220, 38, 90, 175)", color="#f472b6"))
        close_btn.clicked.connect(self.close)
        bar.addWidget(close_btn)

        parent_layout.addLayout(bar)

    # ───────────────────────── управление боковой панелью, цветом и сценариями ─────────────────────────
    def _on_toggle_sidebar(self):
        self._set_sidebar_open_slot(not self.sidebar_open)

    def _set_sidebar_open_slot(self, open_flag: bool):
        self.sidebar_open = bool(open_flag)
        self.menu_btn.blockSignals(True)
        self.menu_btn.setChecked(self.sidebar_open)
        self.menu_btn.blockSignals(False)

        if self.sidebar_open:
            self.sidebar_frame.show()
            target_w = max(self.width(), self.EXPANDED_WIDTH)
            self.resize(target_w, self.height())
        else:
            self.sidebar_frame.hide()
            self.resize(self.COMPACT_WIDTH, self.height())

    def _on_color_selected(self, theme_key: str):
        actions.change_jarvis_color(theme_key)

    def _apply_color_theme_slot(self, theme_key: str, announce: bool = True):
        key = resolve_color_theme_key(theme_key)
        self.theme_key = key
        tinfo = JARVIS_COLOR_THEMES[key]
        ar, ag, ab = tinfo["accent"]
        br, bg_c, bb = tinfo["border"]

        self.core.set_color_theme(key)
        self.panel.set_color_theme(key)
        self.log_area.set_theme(key)

        try:
            self.shadow.setColor(QColor(ar, ag, ab, 95))
        except Exception:
            pass

        # Обновляем кружки выбора цвета и комбобокс
        for k, btn in self._color_swatch_btns.items():
            hex_c = JARVIS_COLOR_THEMES[k]["hex"]
            border_str = "2px solid #ffffff" if k == key else "1px solid rgba(255,255,255,45)"
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {hex_c};
                    border: {border_str};
                    border-radius: 12px;
                }}
            """)

        if hasattr(self, "color_combo"):
            self.color_combo.blockSignals(True)
            if key in COLOR_THEME_ORDER:
                self.color_combo.setCurrentIndex(COLOR_THEME_ORDER.index(key))
            self.color_combo.blockSignals(False)

        if hasattr(self, "send_btn"):
            self.send_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: rgba({ar}, {ag}, {ab}, 205);
                    border: 1px solid rgb({br}, {bg_c}, {bb});
                    border-radius: 17px;
                    color: #ffffff;
                    font-size: 13px;
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: rgba({ar}, {ag}, {ab}, 245);
                    border: 1px solid #ffffff;
                }}
            """)

        if announce:
            self.status_label.setText(f"Цвет Джарвиса: {tinfo['title']}")

    def _refresh_scenarios_combo(self):
        if not hasattr(self, "scenario_combo"):
            return
        self.scenario_combo.blockSignals(True)
        self.scenario_combo.clear()
        self.scenario_combo.addItem("⚡ Выберите сценарий…")
        for sname in (self.brain.scenarios or {}).keys():
            self.scenario_combo.addItem(f"▸ {sname}")
        self.scenario_combo.blockSignals(False)

    def _on_style_btn_clicked(self, style_key: str):
        msg = actions.change_jarvis_style(style_key)
        self.status_label.setText(msg)
        self._append_jarvis_slot(msg)

    def _apply_visual_style_slot(self, style_name: str):
        s = (style_name or "").lower()
        is_verity = "verity" in s or "верит" in s
        if hasattr(self, "core") and hasattr(self.core, "set_visual_style"):
            self.core.set_visual_style("verity" if is_verity else "jarvis_hud")
        if hasattr(self, "style_jarvis_btn") and hasattr(self, "style_verity_btn"):
            self.style_jarvis_btn.blockSignals(True)
            self.style_verity_btn.blockSignals(True)
            self.style_jarvis_btn.setChecked(not is_verity)
            self.style_verity_btn.setChecked(is_verity)
            self.style_jarvis_btn.blockSignals(False)
            self.style_verity_btn.blockSignals(False)
        if hasattr(self, "voice_combo"):
            target_v = "verity" if is_verity else "jarvis"
            for idx_v, (vk, _vl) in enumerate(getattr(self, "_voice_items", [])):
                if vk == target_v:
                    self.voice_combo.blockSignals(True)
                    self.voice_combo.setCurrentIndex(idx_v)
                    self.voice_combo.blockSignals(False)
                    break

    def _toggle_scenario_builder(self):
        vis = not self.builder_frame.isVisible()
        self.builder_frame.setVisible(vis)
        self.toggle_builder_btn.setText("➖ Скрыть конструктор" if vis else "➕ Создать свой сценарий")

    def _append_step_chip(self, step_text: str):
        if step_text == "__CLEAR__":
            self.scen_steps_input.clear()
            return
        cur = self.scen_steps_input.toPlainText().strip()
        new_txt = (cur + "\n" + step_text) if cur else step_text
        self.scen_steps_input.setPlainText(new_txt)

    def _on_add_custom_site_step(self):
        raw = self.custom_site_input.text().strip()
        if not raw:
            self.status_label.setText("Введите адрес или название сайта (например: ozon.ru, youtube.com)")
            return
        sites = [s.strip() for s in re.split(r"\s*,\s*", raw) if s and s.strip()]
        for s in sites:
            clean_s = re.sub(r"^(?:открой\s+сайт|сайт|открой)\s+", "", s, flags=re.IGNORECASE).strip()
            self._append_step_chip(f"открой сайт {clean_s}")
        self.custom_site_input.clear()
        self.status_label.setText(f"Добавлено сайтов в сценарий: {len(sites)}")

    def _on_add_custom_app_step(self):
        raw = self.custom_app_input.text().strip()
        if not raw:
            self.status_label.setText("Введите название программы/игры или нажмите «📂 Выбрать .exe»")
            return
        apps = [a.strip() for a in re.split(r"\s*,\s*", raw) if a and a.strip()]
        for a in apps:
            clean_a = re.sub(r"^(?:открой|запусти|включи)\s+", "", a, flags=re.IGNORECASE).strip()
            self._append_step_chip(f"открой {clean_a}")
        self.custom_app_input.clear()
        self.status_label.setText(f"Добавлено программ в сценарий: {len(apps)}")

    def _on_browse_exe_for_scenario(self):
        start_dir = actions.get_real_desktop_path()
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Выберите одну или несколько программ / игр / ярлыков для сценария",
            start_dir,
            "Программы и ярлыки (*.exe *.lnk *.url *.bat *.cmd);;Все файлы (*.*)",
        )
        if not files:
            return
        for fp in files:
            norm_fp = os.path.normpath(fp)
            self._append_step_chip(f"открой {norm_fp}")
        self.status_label.setText(f"Добавлено выбранных программ в сценарий: {len(files)}")

    def _on_load_selected_scenario_to_builder(self):
        idx = self.scenario_combo.currentIndex()
        if idx <= 0:
            self.status_label.setText("Выберите сценарий из списка выше, чтобы изменить его")
            return
        sname = self.scenario_combo.currentText().lstrip("▸ ").strip()
        steps = (self.brain.scenarios or {}).get(sname) or []
        lines = []
        for st in steps:
            if not isinstance(st, dict):
                continue
            if "url" in st:
                lines.append(f"открой сайт {st['url']}")
            elif st.get("tool") == "open_site":
                lines.append(f"открой сайт {(st.get('args') or {}).get('name', '')}")
            elif "open" in st:
                op = st["open"]
                if isinstance(op, list):
                    for item_op in op:
                        lines.append(f"открой {item_op}")
                else:
                    lines.append(f"открой {op}")
            elif "open_steam_game" in st:
                lines.append(f"открой {st['open_steam_game']}")
            elif "close" in st:
                lines.append(f"закрой {st['close']}")
            elif "volume" in st:
                lines.append(f"громкость {st['volume']}")
            elif "brightness" in st:
                lines.append(f"яркость {st['brightness']}")
            elif "wait" in st:
                lines.append(f"подожди {st['wait']}")
            elif "say" in st:
                lines.append(f"скажи {st['say']}")
            elif "minimize_all" in st and st["minimize_all"]:
                lines.append("сверни все окна")
            elif "command" in st:
                lines.append(str(st["command"]))
        self.scen_name_input.setText(sname)
        self.scen_steps_input.setPlainText("\n".join(lines))
        self.builder_frame.show()
        self.toggle_builder_btn.setText("➖ Скрыть конструктор")
        self.status_label.setText(f"Сценарий «{sname}» загружен в конструктор — добавьте свои сайты/программы и нажмите Сохранить")

    def _on_save_custom_scenario(self):
        # Если пользователь ввёл сайт или программу в верхние поля, но не нажал «+», автоматически добавляем их!
        if self.custom_site_input.text().strip():
            self._on_add_custom_site_step()
        if self.custom_app_input.text().strip():
            self._on_add_custom_app_step()
        name = self.scen_name_input.text().strip()
        steps_txt = self.scen_steps_input.toPlainText().strip()
        msg = actions.add_custom_scenario(name=name, steps_text=steps_txt)
        self.status_label.setText(msg)
        self._append_jarvis_slot(msg)
        if "сохранён" in msg:
            self.scen_name_input.clear()
            self.scen_steps_input.clear()
            self.builder_frame.hide()
            self.toggle_builder_btn.setText("➕ Создать свой сценарий")
            self._refresh_scenarios_combo()

    def _on_delete_selected_scenario(self):
        idx = self.scenario_combo.currentIndex()
        if idx <= 0:
            self.status_label.setText("Сначала выберите сценарий в списке для удаления")
            return
        raw = self.scenario_combo.currentText().lstrip("▸ ").strip()
        if not raw:
            return
        msg = actions.delete_custom_scenario(raw)
        self._refresh_scenarios_combo()
        self.status_label.setText(msg)
        self._append_jarvis_slot(msg)

    def _populate_local_models(self, initial: bool = False):
        if hasattr(self.brain, "get_available_models"):
            models = list(self.brain.get_available_models() or [])
        else:
            models = [self.brain.model]
        if not models:
            models = [self.brain.model]
        self.model_combo.blockSignals(True)
        self.model_combo.clear()
        for m in models:
            self.model_combo.addItem(f"🤖 {m}")
        cur = self.brain.model
        for i, m in enumerate(models):
            if m == cur:
                self.model_combo.setCurrentIndex(i)
                break
        self.model_combo.blockSignals(False)
        if not initial:
            self._append_jarvis_slot(f"Список ваших локальных моделей обновлён ({len(models)}). Активна: {self.brain.model}")

    def _refresh_local_models(self):
        if hasattr(self.brain, "_discover_and_select_local_model"):
            self.brain._discover_and_select_local_model()
        self._populate_local_models(initial=False)

    def _build_input(self, parent_layout):
        inp = QHBoxLayout()
        inp.setSpacing(6)

        self.wake_btn = QPushButton("🎤")
        self.wake_btn.setFixedSize(34, 34)
        self.wake_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.wake_btn.setToolTip("Активировать голосовое слушание")
        self.wake_btn.setStyleSheet("""
            QPushButton {
                background-color: #181426;
                border: 1px solid rgba(148, 130, 210, 95);
                border-radius: 17px;
                color: #ddd6fe;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: rgba(124, 58, 237, 165);
                color: #ffffff;
                border: 1px solid #ffffff;
            }
        """)
        self.wake_btn.clicked.connect(self._on_core_clicked)
        inp.addWidget(self.wake_btn)

        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Говорите в микрофон или напишите команду…")
        self.input_field.installEventFilter(self)
        self.input_field.setStyleSheet("""
            QLineEdit {
                background-color: #161324;
                border: 1px solid rgba(148, 130, 210, 75);
                border-radius: 16px;
                padding: 6px 13px;
                color: #f3f0ff;
                font-size: 12px;
                font-family: 'Segoe UI', sans-serif;
            }
            QLineEdit:focus {
                border: 1px solid #a78bfa;
                background-color: #1c1730;
            }
        """)
        inp.addWidget(self.input_field, 1)

        self.send_btn = QPushButton("▶")
        self.send_btn.setFixedSize(34, 34)
        self.send_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_btn.setToolTip("Отправить (Enter)")
        inp.addWidget(self.send_btn)
        parent_layout.addLayout(inp)

    @staticmethod
    def _icon_btn_style(hover_bg: str = "rgba(124, 58, 237, 110)", color: str = "#7c7396") -> str:
        return f"""
            QPushButton {{
                background-color: transparent;
                color: {color};
                border: none;
                border-radius: 6px;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: {hover_bg};
                color: #f3f0ff;
            }}
            QPushButton:checked {{
                background-color: rgba(124, 58, 237, 165);
                color: #ffffff;
            }}
        """

    @staticmethod
    def _combo_style() -> str:
        return """
            QComboBox {
                background-color: #171426;
                border: 1px solid rgba(148, 130, 210, 70);
                border-radius: 9px;
                padding: 3px 8px;
                color: #ede9fe;
                font-size: 11px;
                font-family: 'Segoe UI', sans-serif;
                min-height: 21px;
            }
            QComboBox:hover {
                border: 1px solid #c4b5fd;
                color: #ffffff;
            }
            QComboBox::drop-down {
                border: none;
                width: 16px;
            }
            QComboBox QAbstractItemView {
                background-color: #141122;
                color: #ede9fe;
                selection-background-color: #6d28d9;
                selection-color: #ffffff;
                border: 1px solid #8b5cf6;
                outline: none;
            }
        """

    @staticmethod
    def _toggle_btn_style(
        checked_bg: str = "rgba(190, 24, 93, 165)",
        checked_border: str = "#f472b6",
        checked_text: str = "#fce7f3",
    ) -> str:
        return f"""
            QPushButton {{
                background-color: transparent;
                border: none;
                border-radius: 6px;
                color: #7c7396;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: rgba(124, 58, 237, 90);
                color: #ffffff;
            }}
            QPushButton:checked {{
                background-color: {checked_bg};
                border: 1px solid {checked_border};
                color: {checked_text};
            }}
        """

    @staticmethod
    def _pill_btn_style(accent: str = "#ddd6fe", font_size: int = 11) -> str:
        return f"""
            QPushButton {{
                background-color: #171426;
                border: 1px solid rgba(148, 130, 210, 65);
                border-radius: 9px;
                color: {accent};
                font-size: {font_size}px;
                font-weight: 500;
                padding: 0 7px;
                font-family: 'Segoe UI', sans-serif;
            }}
            QPushButton:hover {{
                background-color: rgba(124, 58, 237, 135);
                border: 1px solid #c4b5fd;
                color: #ffffff;
            }}
            QPushButton:pressed {{
                background-color: #7c3aed;
                color: #ffffff;
            }}
        """

    def _wire_signals(self):
        self.model_combo.currentTextChanged.connect(self._on_model_changed)
        self.color_combo.activated.connect(self._on_color_combo_activated)
        self.mute_btn.clicked.connect(self._toggle_mute)
        self.tts_btn.clicked.connect(self._toggle_tts)
        self.dict_btn.clicked.connect(self._toggle_dictation)
        self.clear_btn.clicked.connect(self._clear_log)
        self.run_scen_btn.clicked.connect(self._on_run_selected_scenario)
        self.voice_combo.activated.connect(self._on_voice_combo_changed)
        self.stt_combo.activated.connect(self._on_stt_combo_changed)
        self.mic_combo.activated.connect(self._on_mic_combo_changed)
        self.stop_btn.clicked.connect(self._on_stop_clicked)
        self.core.clicked.connect(self._on_core_clicked)
        self.input_field.returnPressed.connect(self._on_text_input)
        self.send_btn.clicked.connect(self._on_text_input)

    def _on_color_combo_activated(self, idx: int):
        if 0 <= idx < len(COLOR_THEME_ORDER):
            self._on_color_selected(COLOR_THEME_ORDER[idx])

    def eventFilter(self, obj, event):
        if obj is self.input_field and event.type() == QEvent.Type.KeyPress:
            key = event.key()
            if key == Qt.Key.Key_Up and self._cmd_history:
                self._cmd_index = max(0, self._cmd_index - 1) if self._cmd_index >= 0 else len(self._cmd_history) - 1
                self.input_field.setText(self._cmd_history[self._cmd_index])
                return True
            if key == Qt.Key.Key_Down and self._cmd_history:
                if 0 <= self._cmd_index < len(self._cmd_history) - 1:
                    self._cmd_index += 1
                    self.input_field.setText(self._cmd_history[self._cmd_index])
                else:
                    self._cmd_index = -1
                    self.input_field.clear()
                return True
        return super().eventFilter(obj, event)

    def _on_cycle_glass(self):
        mode_name = self.panel.cycle_preset()
        self.status_label.setText(f"Тема фона: {mode_name}")

    def _on_cycle_voice(self):
        if self.speaker and hasattr(self.speaker, "next_voice_preset"):
            msg = self.speaker.next_voice_preset()
            self.status_label.setText(msg)
            self.speaker.say("Голосовой профиль обновлён", force=True, show=False)

    def _on_voice_combo_changed(self, idx: int):
        if 0 <= idx < len(getattr(self, "_voice_items", [])):
            vkey, _vlabel = self._voice_items[idx]
            if self.speaker and hasattr(self.speaker, "set_voice_preset"):
                msg = self.speaker.set_voice_preset(vkey)
                self.status_label.setText(msg)
                self.speaker.say("Голос Джарвиса активирован", force=True, show=False)

    def _on_stt_combo_changed(self, idx: int):
        if 0 <= idx < len(getattr(self, "_stt_items", [])):
            skey, _slabel = self._stt_items[idx]
            if self.listener and hasattr(self.listener, "switch_stt_model"):
                msg = self.listener.switch_stt_model(skey)
                self.status_label.setText(msg)
                self._append_jarvis_slot(msg)

    def _on_mic_combo_changed(self, idx: int):
        if 0 <= idx < len(getattr(self, "_mic_items", [])):
            dev_id, _mlabel = self._mic_items[idx]
            arg = "авто" if dev_id is None else str(dev_id)
            msg = actions.change_microphone(arg)
            self.status_label.setText(msg)
            self._append_jarvis_slot(msg)

    def _refresh_contacts_combo(self):
        if not hasattr(self, "contact_combo"):
            return
        self.contact_combo.blockSignals(True)
        self.contact_combo.clear()
        self.contact_combo.addItem("👥 Выберите контакт…")
        contacts = (self.brain.cfg or {}).get("contacts") or actions.CFG.get("contacts") or {}
        for cname, cinfo in contacts.items():
            m_tag = (cinfo or {}).get("messenger", "телеграм") if isinstance(cinfo, dict) else "телеграм"
            self.contact_combo.addItem(f"• {cname} ({m_tag})")
        self.contact_combo.blockSignals(False)

    def _toggle_contact_builder(self):
        vis = not self.ct_builder_frame.isVisible()
        self.ct_builder_frame.setVisible(vis)
        self.toggle_ct_btn.setText("➖ Скрыть форму контакта" if vis else "➕ Добавить свой контакт")

    def _on_save_custom_contact(self):
        cname = self.ct_name_input.text().strip()
        cuser = self.ct_user_input.text().strip()
        cmsg = self.ct_msg_combo.currentText().strip().lower()
        msg = actions.add_custom_contact(name=cname, username_or_search=cuser, messenger=cmsg)
        self._refresh_contacts_combo()
        self.status_label.setText(msg)
        self._append_jarvis_slot(msg)
        if "сохранён" in msg:
            self.ct_name_input.clear()
            self.ct_user_input.clear()
            self.ct_builder_frame.hide()
            self.toggle_ct_btn.setText("➕ Добавить свой контакт")

    def _on_open_selected_contact(self):
        idx = self.contact_combo.currentIndex()
        if idx <= 0:
            return
        raw = self.contact_combo.currentText().lstrip("• ").split(" (")[0].strip()
        if raw:
            self._run_quick_cmd(f"открой чат с {raw}")

    def _on_delete_selected_contact(self):
        idx = self.contact_combo.currentIndex()
        if idx <= 0:
            return
        raw = self.contact_combo.currentText().lstrip("• ").split(" (")[0].strip()
        if raw:
            msg = actions.delete_custom_contact(raw)
            self._refresh_contacts_combo()
            self.status_label.setText(msg)
            self._append_jarvis_slot(msg)

    def _on_toggle_terminal(self):
        self._terminal_minimized = not self._terminal_minimized
        actions.set_console_window_state(minimize=self._terminal_minimized)
        state_str = "свёрнут в панель задач" if self._terminal_minimized else "развёрнут на экран"
        self.status_label.setText(f"Терминал {state_str}")

    def _toggle_pin(self):
        self.is_pinned = self.pin_btn.isChecked()
        flags = Qt.WindowType.FramelessWindowHint
        if self.is_pinned:
            flags |= Qt.WindowType.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.show()
        try:
            enable_windows_liquid_glass(int(self.winId()))
        except Exception:
            pass

    def _on_model_changed(self, name):
        clean_name = (name or "").replace("🤖", "").strip()
        if not clean_name:
            return
        self.brain.model = clean_name
        self.status_label.setText(f"Подключена локальная ИИ-модель: {self.brain.model}")

    def _toggle_mute(self):
        self.is_muted = self.mute_btn.isChecked()
        self.mute_btn.setText("🔇" if self.is_muted else "🎙")
        if self._loading:
            return
        self._set_state("muted" if self.is_muted else "sleep")

    def _toggle_tts(self):
        muted = self.tts_btn.isChecked()
        if self.speaker:
            self.speaker.muted = muted
            if muted:
                self.speaker.stop()
        self.tts_btn.setText("🔇" if muted else "🔊")

    def _toggle_dictation(self):
        self.brain.dictation = self.dict_btn.isChecked()
        if self.brain.dictation:
            self.brain.last_active = time.time()
            self.status_label.setText("✍ Режим диктовки включён — говорите текст")
        else:
            self.status_label.setText("Режим диктовки выключен")

    def _clear_log(self):
        self.log_area.clear()
        self.status_label.setText("Диалог очищен")

    def _on_core_clicked(self):
        if self.speaker and self.speaker.busy():
            self.brain.stop_all()
            return
        self.brain.last_active = time.time()
        if not self.is_muted and not self._loading:
            self._set_state("listen")

    def _detach_stuck_worker(self):
        if self.query_worker is not None:
            try:
                self.query_worker.finished.disconnect()
                self.query_worker.failed.disconnect()
            except Exception:
                pass
            self.query_worker = None
        self.input_field.setEnabled(True)
        self.send_btn.setEnabled(True)

    def _on_stop_clicked(self):
        msg = self.brain.stop_all()
        self._detach_stuck_worker()
        self._set_state("muted" if self.is_muted else "sleep")
        self.status_label.setText(msg)

    def _on_run_selected_scenario(self):
        idx = self.scenario_combo.currentIndex()
        if idx <= 0:
            return
        raw = self.scenario_combo.currentText().lstrip("▸ ").strip()
        if raw:
            self._run_quick_cmd(f"сценарий {raw}")

    def _run_quick_cmd(self, cmd: str):
        if self.query_worker and self.query_worker.isRunning():
            self._detach_stuck_worker()
        self.brain.last_active = time.time()
        self.append_user(cmd)
        self._set_state("think")
        self._run_query(cmd, from_voice=False, force_handle_text=True)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.pos()
            event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None

    def _set_state(self, state: str, custom_label: str = None):
        self._current_state = state
        self.core.set_state(state)
        tinfo = JARVIS_COLOR_THEMES.get(self.theme_key, JARVIS_COLOR_THEMES["violet"])
        ar, ag, ab = tinfo["accent"]
        self.panel.set_accent(QColor(ar, ag, ab))
        label_text = custom_label or STATE_LABELS.get(state, state)
        self.status_label.setText(label_text)

    def _on_bg_tick(self):
        self._bg_time += 0.08
        if self.speaker and self.tts_btn.isChecked() != bool(self.speaker.muted):
            self.tts_btn.blockSignals(True)
            self.tts_btn.setChecked(bool(self.speaker.muted))
            self.tts_btn.setText("🔇" if self.speaker.muted else "🔊")
            self.tts_btn.blockSignals(False)

        if self.dict_btn.isChecked() != bool(self.brain.dictation):
            self.dict_btn.blockSignals(True)
            self.dict_btn.setChecked(bool(self.brain.dictation))
            self.dict_btn.blockSignals(False)

        if self._loading:
            return

        if self.query_worker is not None and self.query_worker.isRunning():
            if self._query_started_at > 0 and (time.time() - self._query_started_at) > 22.0:
                self._detach_stuck_worker()
                self._set_state("muted" if self.is_muted else "sleep")
            else:
                return
        if self.speaker and self.speaker.busy():
            if self._current_state != "speak":
                self._set_state("speak")
            return

        if self.is_muted:
            if self._current_state != "muted":
                self._set_state("muted")
            return

        if self.brain.dictation:
            self._set_state("listen", "✍ Диктовка · Говорите текст")
        elif self.brain.pending:
            self._set_state("listen", "⏳ Подтвердите: «да» или «нет»")
        elif self.brain.is_awake():
            rem = int(math.ceil(self.brain.remaining_active_seconds()))
            self._set_state("listen", f"Слушаю вас… ({rem} сек)")
        else:
            if self._current_state != "sleep":
                self._set_state("sleep")

    def append_user(self, text: str):
        self.log_area.add_bubble(text, is_user=True)

    def append_jarvis(self, text: str):
        if text:
            self.sig_jarvis_msg.emit(str(text))

    def _append_jarvis_slot(self, text: str):
        clean = database.strip_cjk(text or "").strip()
        if not clean:
            return
        if hasattr(self.core, "trigger_happy") and any(w in clean.lower() for w in ("привет", "услугам", "готов", "выполнен", "сохранён")):
            self.core.trigger_happy(1.4)
        self.log_area.add_bubble(clean, is_user=False)

    def append_trace(self, kind: str, text: str):
        if text:
            self.sig_trace_msg.emit(str(kind), str(text))

    def _append_trace_slot(self, kind: str, text: str):
        clean = database.strip_cjk(text or "").strip()
        if clean:
            self.status_label.setText(f"{clean[:65]}")

    def _start_listener(self):
        if self.listener is not None:
            self.listener.on_speech_state = lambda msg: self.sig_trace_msg.emit("stt", msg)
        self.worker = AudioWorker(self.listener)
        self.worker.text_recognized.connect(self._on_voice_input)
        self.worker.loaded.connect(self._on_listener_loaded)
        self.worker.failed.connect(self._on_listener_failed)
        self.worker.start()

    def _on_listener_loaded(self):
        self._loading = False
        self.brain.last_active = time.time()
        self.status_label.setText(f"Готов к работе · Нажмите «☰» для функций · Слушаю вас")
        if not self.is_muted:
            self._set_state("listen")
        if self.speaker:
            try:
                self.speaker.say("К вашим услугам, сэр", force=True, show=False)
            except Exception as e:
                print("Ошибка голосового подтверждения:", e)

    def _on_listener_failed(self, err: str):
        self._loading = False
        self.listener_available = False
        self.status_label.setText(f"Микрофон недоступен ({err[:45]})")
        self._set_state("muted")

    def _on_voice_input(self, text: str):
        if self.is_muted:
            return
        raw = database.strip_cjk(text or "").strip()
        if len(raw) < 2:
            return
        if self.query_worker and self.query_worker.isRunning():
            if "стоп" in raw.lower() or "хватит" in raw.lower():
                self.brain.stop_all()
            return
        if not self.brain.should_process_voice(raw):
            self.status_label.setText(f"🎙 Услышано: «{raw[:30]}» · Скажите «Джарвис»")
            return
        self.brain.last_active = time.time()
        self.append_user(raw)
        self._set_state("think")
        self._run_query(raw, from_voice=True)

    def _on_text_input(self):
        text = self.input_field.text().strip()
        if not text:
            return
        if self.speaker and self.speaker.busy():
            self.speaker.stop()
        if self.query_worker and self.query_worker.isRunning():
            if text.lower() in ("стоп", "отмена", "хватит"):
                self.brain.stop_all()
                self._detach_stuck_worker()
                self.input_field.clear()
                return
            self._detach_stuck_worker()
        self._cmd_history.append(text)
        self._cmd_index = -1
        self.input_field.clear()
        self.brain.last_active = time.time()
        self.append_user(text)
        self._set_state("think")
        self._run_query(text, from_voice=False, force_handle_text=True)

    def _run_query(self, text: str, from_voice: bool, force_handle_text: bool = False):
        self._query_started_at = time.time()
        self.brain.last_active = time.time()
        self.query_worker = QueryWorker(self.brain, text, from_voice, force_handle_text)
        self.query_worker.finished.connect(self._on_query_done)
        self.query_worker.failed.connect(self._on_query_failed)
        self.query_worker.start()

    def _on_query_done(self, answer: str):
        self.query_worker = None
        self.brain.last_active = time.time()
        clean_ans = database.strip_cjk(answer or "").strip()
        if clean_ans:
            self._append_jarvis_slot(clean_ans)
            self._set_state("speak")
            try:
                if self.speaker:
                    self.speaker.say(clean_ans, show=False)
            except Exception as e:
                print("Ошибка озвучки:", e)
        self.input_field.setEnabled(True)
        self.send_btn.setEnabled(True)

    def _on_query_failed(self, err: str):
        self.query_worker = None
        self.brain.last_active = time.time()
        self._append_jarvis_slot(err)
        self._set_state("muted" if self.is_muted else "listen")
        self.input_field.setEnabled(True)
        self.send_btn.setEnabled(True)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        super().paintEvent(event)

    def closeEvent(self, event):
        self.brain.stop_all()
        try:
            actions.close_console_window()
        except Exception:
            pass
        event.accept()
        os._exit(0)

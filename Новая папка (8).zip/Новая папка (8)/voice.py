"""Голосовой контур Джарвиса:
  1. Оригинальный звуковой пакет J.A.R.V.I.S. из репозитория FitoDomik/Jarvis-Sound (61 студийный .wav файл) — ОСНОВА ОЗВУЧКИ:
     • Полная база и интеллектуальный маршрутизатор всех 61 оригинальных реплик Джарвиса (1.wav .. 61.wav)
       из https://github.com/FitoDomik/Jarvis-Sound:
       - Приветствия и запуск: 35.wav, 36.wav («Джарвис — приветствие»), 42.wav («Доброе утро»), 50.wav («Мы подключены и готовы»), 51.wav («Я перезагрузился, сэр»).
       - Отклик на «Джарвис»: 54.wav («К вашим услугам, сэр»), 41.wav («Всегда к вашим услугам, сэр»), 33.wav / 19.wav («Да, сэр»).
       - Открытие сайтов, программ и сценариев: 52.wav («Загружаю, сэр»), 48.wav («Как пожелаете»), 53.wav («Есть»), 16.wav («Запрос выполнен, сэр»).
       - Создание папок, блокнотов и сценариев: 28.wav / 29.wav («Образ создан»), 31.wav («Начинаю автоматическую сборку»), 40.wav («Сохранить его в центральной базе данных Stark Industries»).
       - Диагностика, AI-ревью и OCR-сканирование экрана: 13.wav / 43.wav («Начинаю диагностику системы»), 47.wav («Проверка завершена»), 5.wav («Сканирование макета завершено»), 49.wav («Импортирую установки, начинаю калибровку виртуальной среды»).
       - Выключение / закрытие: 46.wav («Отключаю питание»), 45.wav («Отключаю питание, начинаю диагностику системы»).
       - Ошибки / не найдено: 18.wav («Другой информации нет»), 15.wav («К сожалению, его невозможно синтезировать»), 2.wav («Чего вы пытаетесь добиться, сэр»).
       - Благодарность / комплименты: 41.wav («Всегда к вашим услугам, сэр»), 10.wav («Поздравляю, сэр»), 37.wav («Очень тонкое замечание, сэр»).
       - Заряд / энергия: 55.wav .. 61.wav (2%, 7%, 11%, 13%, 15%, 19%, 48%).
     • Автоматическая фоновая докачка всех 61 файлов (1.wav..61.wav) напрямую из https://github.com/FitoDomik/Jarvis-Sound
       в папку sounds/jarvis_sound/ (плюс мгновенная подгрузка нужного .wav на лету при первом воспроизведении!).
     • Для динамического текста (чтение экрана, точное время, свободные ответы ИИ) — бесшовный синтез в том же
       тембре Джарвиса после фирменной реплики из пака.

  2. Стиль и голос «Верити» (Verity — «Привет! Я Верити, твой друг-помощник!»):
     • Доступен на выбор в боковой панели и голосом («включи стиль верити», «голос верити»).

  3. Неубиваемое распознавание речи (Listener — Neural Multipath Pro):
     • Изолированные потоки распознавания с жёстким таймаутом 2.4 сек, фильтрация шума кулеров и автоусиление AGC.
"""
import collections
import glob
import io
import json
import os
import queue
import random
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import wave
import zipfile


import database
try:
    from rapidfuzz import fuzz, process
except Exception:
    import difflib
    class fuzz:
        @staticmethod
        def ratio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)
        @staticmethod
        def WRatio(a, b):
            return int(difflib.SequenceMatcher(None, str(a), str(b)).ratio() * 100)


BASE = os.path.dirname(os.path.abspath(__file__))
JARVIS_SOUND_DIR = os.path.join(BASE, "sounds", "jarvis_sound")
FITODOMIK_REPO_URL = "https://github.com/FitoDomik/Jarvis-Sound"
FITODOMIK_RAW_BASES = [
    "https://raw.githubusercontent.com/FitoDomik/Jarvis-Sound/main",
    "https://raw.githubusercontent.com/FitoDomik/Jarvis-Sound/master",
]
FITODOMIK_ZIP_URLS = [
    "https://github.com/FitoDomik/Jarvis-Sound/archive/refs/heads/main.zip",
    "https://github.com/FitoDomik/Jarvis-Sound/archive/refs/heads/master.zip",
]


def _abs(p: str) -> str:
    p = os.path.expandvars(os.path.expanduser(p or ""))
    return p if os.path.isabs(p) else os.path.join(BASE, p)


# ═════════════════════════════════════════════════════════════════════════════
# ПОЛНЫЙ КАТАЛОГ 61 ОРИГИНАЛЬНОГО ФАЙЛА ИЗ FITODOMIK/JARVIS-SOUND
# ═════════════════════════════════════════════════════════════════════════════
FITODOMIK_SOUND_CATALOG = {
    1:  "Я провел симуляции со всеми известными элементами",
    2:  "Чего вы пытаетесь добиться сэр",
    3:  "У вас на исходе и время, и варианты решения проблемы",
    4:  "Судя по всему, использование костюма железного человека усугубляет ваше состояние",
    5:  "Сканирование макета завершено",
    6:  "Реактор принял модифицированное ядро",
    7:  "Рассказ про Ивана Ванко",
    8:  "Район Нью-Йорка, Манхэттэн и окрестности",
    9:  "Приближается мисс Поттс",
    10: "Поздравляю сэр",
    11: "Предлагаемый элемент может стать безвредной заменой палладию",
    12: "Отслеживание звонка не завершено",
    13: "Начинаю диагностику системы",
    14: "К сожалению устройство которое сохраняет вам жизнь в то же время убивает вас",
    15: "К сожалению его невозможно синтезировать",
    16: "Запрос выполнен сэр",
    17: "Еще один заряд израсходован",
    18: "Другой информации нет",
    19: "Да сэр",
    20: "Выхожу на грид оракл",
    21: "Вы создали новый элемент",
    22: "Восточное побережье",
    23: "Сэр, похоже его костюм может летать",
    24: "Сэр, не будете дергаться больно не будет",
    25: "Сэр, вы под прицелом, нужен обманный маневр",
    26: "Создать визуальный образ по новым спецификациям",
    27: "Реактор не предназначен для длительных полетов",
    28: "Образ создан",
    29: "Образ создан",
    30: "О чем я думал, обычно у нас все веселенькое",
    31: "Начинаю автоматическую сборку",
    32: "Да, это поможет вам оставаться незамеченным",
    33: "Да сэр",
    34: "Включилось аварийное резервное питание",
    35: "Джарвис - приветствие",
    36: "Джарвис - приветствие (полное)",
    37: "Очень тонкое замечание сэр",
    38: "Для полетов на другие планеты следует усовершенствовать экзосистемы",
    39: "Мы работаем над проектом сэр",
    40: "Сохранить его в центральной базе данных Stark Industries",
    41: "Всегда к вашим услугам сэр",
    42: "Доброе утро",
    43: "Начинаю диагностику системы",
    44: "Сэр, для реальной попытки полета не просчитаны еще терабайты данных",
    45: "Отключаю питание, начинаю диагностику системы",
    46: "Отключаю питание",
    47: "Проверка завершена",
    48: "Как пожелаете",
    49: "Импортирую установки, начинаю калибровку виртуальной среды",
    50: "Мы подключены и готовы",
    51: "Я перезагрузился сэр",
    52: "Загружаю сэр",
    53: "Есть",
    54: "К вашим услугам сэр",
    55: "2 %",
    56: "7 %",
    57: "11 %",
    58: "Энергия 13%",
    59: "Энергия 15 %",
    60: "Сэр, энергия 19 %",
    61: "Энергия 48% и падает сэр",
}


class JarvisSoundPack:
    """Менеджер оригинальной озвучки Джарвиса из репозитория FitoDomik/Jarvis-Sound (1.wav .. 61.wav)."""

    def __init__(self):
        os.makedirs(JARVIS_SOUND_DIR, exist_ok=True)
        self._download_lock = threading.Lock()
        self._sync_started = False

    def find_wav_path(self, clip_id: int) -> str:
        """Ищет файл {clip_id}.wav в папке sounds/jarvis_sound/ или соседних папках проекта."""
        fname = f"{int(clip_id)}.wav"
        candidates = [
            os.path.join(JARVIS_SOUND_DIR, fname),
            os.path.join(BASE, "Jarvis-Sound", fname),
            os.path.join(BASE, "Jarvis-Sound-main", fname),
            os.path.join(BASE, "sounds", fname),
        ]
        for c in candidates:
            if os.path.isfile(c) and os.path.getsize(c) > 500:
                return c
        return ""

    def ensure_clip_downloaded(self, clip_id: int, timeout: float = 3.2) -> str:
        """Возвращает путь к {clip_id}.wav. Если файла ещё нет на диске — мгновенно скачивает его с GitHub FitoDomik/Jarvis-Sound."""
        existing = self.find_wav_path(clip_id)
        if existing:
            return existing

        target = os.path.join(JARVIS_SOUND_DIR, f"{int(clip_id)}.wav")
        for raw_base in FITODOMIK_RAW_BASES:
            url = f"{raw_base}/{int(clip_id)}.wav"
            for use_direct in (True, False):
                try:
                    opener = (
                        urllib.request.build_opener(urllib.request.ProxyHandler({}))
                        if use_direct
                        else urllib.request.build_opener()
                    )
                    req = urllib.request.Request(url, headers={"User-Agent": "JarvisAssistant/3.5"})
                    with opener.open(req, timeout=timeout) as resp:
                        data = resp.read()
                    if data and len(data) > 500 and data[:4] == b"RIFF":
                        with open(target, "wb") as f:
                            f.write(data)
                        return target
                except Exception:
                    pass
        return ""

    def count_installed_clips(self) -> int:
        count = 0
        for i in range(1, 62):
            if self.find_wav_path(i):
                count += 1
        return count

    def sync_all_in_background(self):
        """В фоновом потоке скачивает все 61 оригинальных .wav файлов из FitoDomik/Jarvis-Sound."""
        if self._sync_started:
            return
        self._sync_started = True

        def _worker():
            with self._download_lock:
                if self.count_installed_clips() >= 55:
                    return
                # 1) Сначала пробуем скачать весь архив репозитория FitoDomik/Jarvis-Sound одним ZIP-файлом
                for z_url in FITODOMIK_ZIP_URLS:
                    for use_direct in (True, False):
                        try:
                            opener = (
                                urllib.request.build_opener(urllib.request.ProxyHandler({}))
                                if use_direct
                                else urllib.request.build_opener()
                            )
                            req = urllib.request.Request(z_url, headers={"User-Agent": "JarvisAssistant/3.5"})
                            with opener.open(req, timeout=25) as resp:
                                zip_bytes = resp.read()
                            if len(zip_bytes) > 10_000:
                                with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                                    for member in zf.namelist():
                                        base_name = os.path.basename(member)
                                        if re.fullmatch(r"\d+\.wav", base_name, flags=re.IGNORECASE):
                                            out_p = os.path.join(JARVIS_SOUND_DIR, base_name.lower())
                                            with zf.open(member) as src_f, open(out_p, "wb") as dst_f:
                                                shutil.copyfileobj(src_f, dst_f)
                                if self.count_installed_clips() >= 50:
                                    print(f"[Jarvis-Sound] Успешно загружен полный звуковой пакет FitoDomik/Jarvis-Sound ({self.count_installed_clips()}/61 файлов)!")
                                    return
                        except Exception:
                            pass

                # 2) Если ZIP был заблокирован — докачиваем ключевые .wav файлы по одному
                priority_order = [
                    54, 41, 33, 19, 35, 42, 50, 52, 48, 53, 16, 28, 29, 31,
                    13, 43, 47, 5, 49, 46, 45, 18, 15, 10, 37, 51, 36,
                ] + [i for i in range(1, 62)]
                seen = set()
                for cid in priority_order:
                    if cid not in seen:
                        seen.add(cid)
                        self.ensure_clip_downloaded(cid, timeout=4.0)

        threading.Thread(target=_worker, daemon=True).start()

    def match_clips_for_text(self, text: str) -> tuple:
        """Подбирает подходящий оригинальный .wav файл из FitoDomik/Jarvis-Sound по смыслу ответа Джарвиса.
        Возвращает (clip_id, exact_only_bool):
          • exact_only_bool = True  -> фраза полностью озвучивается оригинальным .wav файлом из фильма!
          • exact_only_bool = False -> сначала звучит короткий оригинальный .wav («Да, сэр» / «Загружаю, сэр»),
                                       затем при необходимости дочитывается динамическая информация."""
        raw = (text or "").strip()
        low = re.sub(r"\s+", " ", raw.lower().replace("ё", "е")).strip(" .,!?:;—-«»\"'")
        if not low:
            return None, True

        # 1. Прямое совпадение по номеру («звук 35», «фраза 54») или тексту из каталога FitoDomik/Jarvis-Sound
        m_num = re.fullmatch(r"(?:звук|фраза|сэмпл|аудио|wav)\s*(\d{1,2})", low)
        if m_num:
            num = int(m_num.group(1))
            if 1 <= num <= 61:
                return num, True

        for cid, ctext in FITODOMIK_SOUND_CATALOG.items():
            c_norm = re.sub(r"[^а-яa-z0-9\s%]", "", ctext.lower().replace("ё", "е")).strip()
            low_clean = re.sub(r"[^а-яa-z0-9\s%]", "", low).strip()
            if low_clean and (low_clean == c_norm or fuzz.ratio(low_clean, c_norm) >= 88):
                return cid, True

        # 2. Категория: Старт системы / Готовность / Перезагрузка
        if any(p in low for p in ("система готова", "мы подключены и готовы", "к вашим услугам")):
            return random.choice([54, 50, 41]), True
        if "перезагруз" in low and len(low) < 45:
            return 51, True

        # 3. Категория: Отклик на слово активации «Джарвис» / Приветствие
        if low in (
            "слушаю егор", "на связи егор слушаю вас", "слушаю вас", "на связи",
            "слушаю сэр", "да сэр", "я здесь", "тут",
        ):
            return random.choice([54, 41, 33, 19]), True

        if "доброе утро" in low:
            return 42, True

        if any(p in low for p in ("привет егор", "приветствую", "все системы в норме чем могу помочь", "все системы функционируют")):
            return random.choice([35, 54, 41, 50]), True

        # 4. Категория: Благодарность / Комплименты
        if any(p in low for p in ("всегда к вашим услугам", "рад помочь", "обращайтесь")):
            return 41, True
        if "поздравляю" in low:
            return 10, True
        if "тонкое замечание" in low:
            return 37, True

        # 5. Категория: Открытие приложений, игр, сайтов, папок и запуск сценариев
        if low.startswith(("открываю ", "запускаю ", "переключился на ", "ищу:")):
            return random.choice([52, 48, 53, 16]), True

        if low.startswith("сценарий ") and ("выполнен" in low or "запущен" in low):
            return random.choice([16, 48, 52]), True

        if low.startswith("сценарий ") and "сохранен" in low:
            return random.choice([28, 29, 40]), True

        if low.startswith("сценарий ") and "удален" in low:
            return 16, True

        # 6. Категория: Создание папок, блокнотов, скриншотов и сохранение файлов
        if any(p in low for p in ("папка «", "папка создана", "блокнот «", "записал файл", "скриншот сохранен", "скопировал", "вставил")):
            return random.choice([28, 29, 16, 40]), True

        # 7. Категория: Отправка сообщений в Telegram / Discord / WhatsApp
        if low.startswith(("отправил ", "открыл чат ", "открыл телеграм", "открыл дискорд")):
            return random.choice([16, 48, 53]), True

        # 8. Категория: Громкость, яркость, окна, цвет, таймеры, настройки
        if low.startswith(("громкость ", "яркость ", "звук ", "цвет джарвиса", "голос изменен", "модель распознавания", "таймер ", "автозапуск ", "терминал ", "боковая панель", "готово")):
            return random.choice([16, 48, 53, 33]), True

        # 9. Категория: Компьютерное зрение Tesseract OCR и AI-ревью / Диагностика
        if low.startswith(("ai-ревью", "официальный tesseract ocr подключен", "активная модель слуха")):
            return 47, True
        if low.startswith(("распознано ", "вижу элементы", "текст в окне:", "перевод с экрана", "надпись «")):
            return 5, True
        if low.startswith(("нажал на ", "дважды нажал", "правый клик", "нашел «")):
            return random.choice([16, 53, 48]), True

        # 10. Категория: Выключение / Закрытие / Остановка
        if low.startswith(("закрыл ", "остановлено", "молчу", "выключаю компьютер", "перехожу в спящий")):
            return 46, True

        # 11. Категория: Ошибки / Не найдено
        if low.startswith(("не нашел", "не вижу на экране", "ничего не нашел", "файл не найден", "папка не найдена", "окно «")):
            return 18, True

        # 12. Для развёрнутых ответов ИИ / чтения текста вслух — возвращаем (None, False), чтобы озвучить полный текст
        return None, False



    @property
    def base_dir(self) -> str:
        return JARVIS_SOUND_DIR

    def get_clip_path(self, clip_id: int) -> str:
        return self.ensure_clip_downloaded(clip_id)

    def installed_count(self) -> int:
        return self.count_installed_clips()

    def match_clip_for_text(self, text: str):
        cid, _exact = self.match_clips_for_text(text)
        return cid

    def _download_zip_pack(self):
        self._sync_started = False
        self.sync_all_in_background()


SOUND_PACK = JarvisSoundPack()


# ═════════════════════════════════════════════════════════════════════════════
# КАТАЛОГ МОДЕЛЕЙ РАСПОЗНАВАНИЯ РЕЧИ (STT)
# ═════════════════════════════════════════════════════════════════════════════
STT_MODELS_CATALOG = [
    ("multipath_pro", "⚡ Multipath Pro (Whisper + Google)"),
    ("whisper_base",  "🚀 Whisper Base (Быстрая офлайн)"),
    ("whisper_small", "🧠 Whisper Small (Точная офлайн)"),
    ("whisper_turbo", "🔥 Whisper Large-v3-Turbo"),
    ("google_direct", "🌐 Google Neural (Без прокси)"),
]


# ═════════════════════════════════════════════════════════════════════════════
# КАТАЛОГ ГОЛОСОВ ДЖАРВИСА (ОСНОВА: FITODOMIK/JARVIS-SOUND + СТИЛЬ ВЕРИТИ)
# ═════════════════════════════════════════════════════════════════════════════
VOICE_PRESETS = {
    "jarvis": {
        "title": "★ Джарвис (Оригинал Jarvis-Sound)",
        "aliases": [
            "джарвис", "настоящий джарвис", "голос настоящего джарвиса", "оригинал", "оригинальный",
            "оригинальный голос", "оригинальный голос джарвиса", "кино", "из фильма", "железный человек",
            "пол беттани", "основной", "стандартный", "jarvis", "jarvis sound", "fitodomik",
        ],
        "use_sound_pack": True,
        "piper_models": ["ru_RU-dmitri-medium.onnx", "ru_RU-ruslan-medium.onnx", "ru_RU-denis-medium.onnx"],
        "edge_voice": "ru-RU-DmitryNeural",
        "edge_rate": "+6%",
        "edge_pitch": "-4Hz",
        "piper_speed": 0.91,
        "dsp": "jarvis",
        "piper_download_url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/ru/ru_RU/dmitri/medium/ru_RU-dmitri-medium.onnx",
    },
    "verity": {
        "title": "✨ Верити (Стиль Verity / Друг-помощник)",
        "aliases": [
            "верити", "вирти", "стиль верити", "голос верити", "verity", "друг помощник", "помощник верити",
        ],
        "use_sound_pack": False,
        "piper_models": ["ru_RU-dmitri-medium.onnx", "ru_RU-irina-medium.onnx", "ru_RU-denis-medium.onnx"],
        "edge_voice": "ru-RU-DmitryNeural",
        "edge_rate": "+11%",
        "edge_pitch": "+9Hz",
        "piper_speed": 0.87,
        "dsp": "verity",
        "piper_download_url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/ru/ru_RU/dmitri/medium/ru_RU-dmitri-medium.onnx",
    },
    "dmitry": {
        "title": "🎙 Дмитрий (Мягкий баритон)",
        "aliases": [
            "дмитрий", "дима", "мягкий", "мягкий мужской", "приятный мужской", "мужской", "баритон", "dmitry", "dmitri",
        ],
        "use_sound_pack": False,
        "piper_models": ["ru_RU-dmitri-medium.onnx", "ru_RU-denis-medium.onnx"],
        "edge_voice": "ru-RU-DmitryNeural",
        "edge_rate": "+2%",
        "edge_pitch": "-1Hz",
        "piper_speed": 0.94,
        "dsp": "warm",
        "piper_download_url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/ru/ru_RU/dmitri/medium/ru_RU-dmitri-medium.onnx",
    },
    "friday": {
        "title": "🎙 Пятница / Светлана (Нежный женский)",
        "aliases": [
            "пятница", "светлана", "света", "женский", "приятный женский", "нежный", "девушка", "friday", "svetlana",
        ],
        "use_sound_pack": False,
        "piper_models": ["ru_RU-irina-medium.onnx", "ru_RU-dmitri-medium.onnx", "ru_RU-denis-medium.onnx"],
        "edge_voice": "ru-RU-SvetlanaNeural",
        "edge_rate": "+4%",
        "edge_pitch": "+2Hz",
        "piper_speed": 0.94,
        "dsp": "friday",
        "piper_download_url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/ru/ru_RU/irina/medium/ru_RU-irina-medium.onnx",
    },
    "ruslan": {
        "title": "🎙 Руслан (Глубокий диктор)",
        "aliases": [
            "руслан", "диктор", "глубокий", "низкий", "серьезный", "спокойный", "ruslan",
        ],
        "use_sound_pack": False,
        "piper_models": ["ru_RU-ruslan-medium.onnx", "ru_RU-dmitri-medium.onnx", "ru_RU-denis-medium.onnx"],
        "edge_voice": "ru-RU-DmitryNeural",
        "edge_rate": "-2%",
        "edge_pitch": "-8Hz",
        "piper_speed": 0.95,
        "dsp": "deep",
        "piper_download_url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/ru/ru_RU/ruslan/medium/ru_RU-ruslan-medium.onnx",
    },
    "irina": {
        "title": "🎙 Ирина (Тёплый женский)",
        "aliases": [
            "ирина", "ира", "теплый женский", "спокойный женский", "irina",
        ],
        "use_sound_pack": False,
        "piper_models": ["ru_RU-irina-medium.onnx", "ru_RU-denis-medium.onnx"],
        "edge_voice": "ru-RU-SvetlanaNeural",
        "edge_rate": "+0%",
        "edge_pitch": "+0Hz",
        "piper_speed": 0.95,
        "dsp": "warm",
        "piper_download_url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/ru/ru_RU/irina/medium/ru_RU-irina-medium.onnx",
    },
    "denis": {
        "title": "🎙 Денис (Быстрый классический)",
        "aliases": [
            "денис", "быстрый", "классический", "старый", "denis",
        ],
        "use_sound_pack": False,
        "piper_models": ["ru_RU-denis-medium.onnx"],
        "edge_voice": "ru-RU-DmitryNeural",
        "edge_rate": "+8%",
        "edge_pitch": "+0Hz",
        "piper_speed": 0.93,
        "dsp": "warm",
        "piper_download_url": "",
    },
}

VOICE_ORDER = ["jarvis", "verity", "dmitry", "friday", "ruslan", "irina", "denis"]


# ═════════════════════════════════════════════════════════════════════════════
# ФИЛЬТР АНТИ-ГАЛЛЮЦИНАЦИЙ WHISPER И CJK-ИЕРОГЛИФОВ
# ═════════════════════════════════════════════════════════════════════════════
_WHISPER_HALLUCINATION_PATTERNS = (
    "субтитры сделал", "субтитры создавал", "субтитры подготовил", "редактор субтитров",
    "корректор", "продолжение следует", "спасибо за просмотр", "подписывайтесь на канал",
    "ставь лайк", "ставьте лайки", "dimatorzok", "amara.org", "dima torzok",
    "а.синецкая", "а.семкин", "в.теплухин", "музыкальная заставка", "динамичная музыка",
    "субтитры подогнал", "торзок", "перевод и озвучка",
)


def is_whisper_hallucination(text: str) -> bool:
    clean = database.strip_cjk(text or "").strip().lower().replace("ё", "е")
    if not clean or len(clean) < 2:
        return True
    alpha = re.sub(r"[^а-яa-z0-9]+", "", clean)
    if len(alpha) < 2:
        return True
    for pat in _WHISPER_HALLUCINATION_PATTERNS:
        if pat in clean:
            return True
    words = clean.split()
    if len(words) >= 5 and len(set(words)) == 1:
        return True
    return False


def build_whisper_context_prompt(cfg: dict = None) -> tuple:
    cfg = cfg or {}
    contacts = list((cfg.get("contacts") or {}).keys())
    apps = list((cfg.get("apps") or {}).keys())
    steam = list((cfg.get("steam_apps") or {}).keys())
    scenarios = list((cfg.get("scenarios") or {}).keys())

    hot_list = [
        "Джарвис", "Верити", "телеграм", "дискорд", "стим", "сценарий", "обход", "впн",
        "прочитай экран", "озвучь окно", "переведи окно", "нажми на", "кликни по",
        "Принять", "Отправить", "Избранное",
    ]
    hot_list.extend(contacts[:15])
    hot_list.extend(apps[:12])
    hot_list.extend(steam[:10])
    hot_list.extend(scenarios[:10])

    seen = set()
    unique_hot = []
    for w in hot_list:
        wl = str(w).strip()
        if wl and wl.lower() not in seen:
            seen.add(wl.lower())
            unique_hot.append(wl)

    prompt = (
        "Джарвис, Верити, привет, открой телеграм, напиши Дане, напиши Варюше, напиши Тимохе, "
        "открой дискорд, включи обход, запусти контр страйк, что у меня на экране, прочитай экран, "
        "какие кнопки на экране, нажми Принять, который час."
    )
    hotwords_str = ", ".join(unique_hot[:35])
    return prompt, hotwords_str


# ═════════════════════════════════════════════════════════════════════════════
# ЦИФРОВАЯ ПРЕДОБРАБОТКА МИКРОФОНА (HIGH-PASS ФИЛЬТР + AGC УСИЛЕНИЕ)
# ═════════════════════════════════════════════════════════════════════════════
def filter_and_measure_chunk(raw_pcm_bytes: bytes) -> tuple:
    if not raw_pcm_bytes or len(raw_pcm_bytes) < 4:
        return 0.0, 0.0
    try:
        import numpy as np
        samples = np.frombuffer(raw_pcm_bytes, dtype=np.int16).astype(np.float32)
        if len(samples) < 8:
            return 0.0, 0.0
        samples = samples - float(np.mean(samples))
        hp = np.empty_like(samples)
        hp[0] = samples[0]
        hp[1:] = samples[1:] - 0.88 * samples[:-1]

        rms_hp = float(np.sqrt(np.mean(hp ** 2)))
        lvl = min(1.0, (rms_hp / 32768.0) * 5.4)

        signs = np.signbit(hp)
        zcr = float(np.mean(signs[1:] != signs[:-1]))
        is_voice_like = 1.0 if (0.018 <= zcr <= 0.46) else 0.70
        return lvl * is_voice_like, zcr
    except Exception:
        return 0.0, 0.0


def normalize_pcm_audio(raw_pcm_bytes: bytes, sample_rate: int = 16000) -> bytes:
    if not raw_pcm_bytes or len(raw_pcm_bytes) < 64:
        return raw_pcm_bytes
    try:
        import numpy as np
        samples = np.frombuffer(raw_pcm_bytes, dtype=np.int16).astype(np.float32)
        if len(samples) < 32:
            return raw_pcm_bytes
        samples = samples - float(np.mean(samples))
        filtered = np.copy(samples)
        filtered[1:] = samples[1:] - 0.94 * samples[:-1]
        clean = 0.74 * samples + 0.26 * filtered

        peak = float(np.max(np.abs(clean)))
        if peak > 70.0:
            gain = min(8.5, 26000.0 / peak)
            if gain > 1.05:
                clean = clean * gain

        pcm_norm = np.clip(clean, -32767.0, 32767.0).astype(np.int16)
        return pcm_norm.tobytes()
    except Exception:
        return raw_pcm_bytes


def _run_with_hard_timeout(fn, args=(), timeout: float = 2.4, default=""):
    res_box = [default]
    done_evt = threading.Event()

    def _target():
        try:
            res_box[0] = fn(*args)
        except Exception:
            pass
        finally:
            done_evt.set()

    t = threading.Thread(target=_target, daemon=True)
    t.start()
    done_evt.wait(timeout=max(0.2, float(timeout)))
    return res_box[0]


def apply_jarvis_dsp_to_wav(wav_path: str, dsp_mode: str = "jarvis"):
    """Применяет студийную обработку звука к WAV-файлу (тембр J.A.R.V.I.S. или живой тембр Верити)."""
    if not wav_path or not os.path.isfile(wav_path) or dsp_mode == "none":
        return
    try:
        import numpy as np
        with wave.open(wav_path, "rb") as wf:
            n_channels = wf.getnchannels()
            sampwidth = wf.getsampwidth()
            framerate = wf.getframerate()
            n_frames = wf.getnframes()
            raw_bytes = wf.readframes(n_frames)

        if sampwidth != 2 or n_frames < 100:
            return

        samples = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        smoothed = np.copy(samples)
        smoothed[1:-1] = 0.20 * samples[:-2] + 0.60 * samples[1:-1] + 0.20 * samples[2:]

        win = max(3, int(framerate / 900))
        kernel = np.ones(win, dtype=np.float32) / win
        low_band = np.convolve(smoothed, kernel, mode="same")
        high_band = smoothed - low_band

        if dsp_mode == "jarvis":
            pitch_factor = 0.972
            target_len = int(len(smoothed) / pitch_factor)
            if target_len > 100:
                idx_old = np.linspace(0.0, 1.0, len(smoothed), endpoint=False)
                idx_new = np.linspace(0.0, 1.0, target_len, endpoint=False)
                pitched = np.interp(idx_new, idx_old, smoothed).astype(np.float32)
            else:
                pitched = smoothed
            low_p = np.convolve(pitched, kernel, mode="same")
            high_p = pitched - low_p
            voiced = low_p * 1.34 + high_p * 1.14
            d1 = max(1, int(framerate * 0.0068))
            d2 = max(1, int(framerate * 0.0145))
            d3 = max(1, int(framerate * 0.0225))
            echo = np.zeros_like(voiced)
            if len(voiced) > d3:
                echo[d1:] += voiced[:-d1] * 0.165
                echo[d2:] += voiced[:-d2] * 0.085
                echo[d3:] += voiced[:-d3] * 0.035
            out = voiced + echo
        elif dsp_mode == "verity":
            # Стиль «Верити»: молодой, энергичный, кристально чистый голос друга-помощника
            pitch_factor = 1.045
            target_len = int(len(smoothed) / pitch_factor)
            if target_len > 100:
                idx_old = np.linspace(0.0, 1.0, len(smoothed), endpoint=False)
                idx_new = np.linspace(0.0, 1.0, target_len, endpoint=False)
                pitched = np.interp(idx_new, idx_old, smoothed).astype(np.float32)
            else:
                pitched = smoothed
            low_p = np.convolve(pitched, kernel, mode="same")
            high_p = pitched - low_p
            out = low_p * 1.06 + high_p * 1.24
            d1 = max(1, int(framerate * 0.008))
            if len(out) > d1:
                out[d1:] += out[:-d1] * 0.075
        elif dsp_mode == "deep":
            out = low_band * 1.42 + high_band * 0.80
        elif dsp_mode == "friday":
            out = low_band * 1.05 + high_band * 1.06
            d1 = max(1, int(framerate * 0.009))
            if len(out) > d1:
                out[d1:] += out[:-d1] * 0.08
        else:
            out = low_band * 1.22 + high_band * 0.88

        out = np.tanh(out * 1.12) * 0.92
        fade_len = min(int(framerate * 0.015), len(out) // 4)
        if fade_len > 2:
            fade_in = np.linspace(0.0, 1.0, fade_len, dtype=np.float32)
            fade_out = np.linspace(1.0, 0.0, fade_len, dtype=np.float32)
            out[:fade_len] *= fade_in
            out[-fade_len:] *= fade_out

        pcm = np.clip(out * 32767.0, -32768, 32767).astype(np.int16)
        with wave.open(wav_path, "wb") as wf_out:
            wf_out.setnchannels(n_channels)
            wf_out.setsampwidth(2)
            wf_out.setframerate(framerate)
            wf_out.writeframes(pcm.tobytes())
    except Exception:
        pass


def resolve_voice_preset_key(raw_query: str) -> str:
    q = (raw_query or "").lower().replace("ё", "е").strip()
    if not q:
        return "jarvis"
    if q in VOICE_PRESETS:
        return q
    alias_map = {}
    for k, info in VOICE_PRESETS.items():
        alias_map[k] = k
        alias_map[info["title"].lower().replace("ё", "е")] = k
        for a in info.get("aliases", []):
            alias_map[a.lower().replace("ё", "е")] = k
    if q in alias_map:
        return alias_map[q]
    m = process.extractOne(q, list(alias_map.keys()), scorer=fuzz.WRatio, score_cutoff=70)
    return alias_map[m[0]] if m else "jarvis"


class Speaker:
    """Многоголосая система озвучки на базе оригинального пакета FitoDomik/Jarvis-Sound (61 .wav) + стиля Верити."""

    def __init__(self, enabled=True, rate=185, volume=1.0, engine="piper", piper=None, voice_preset="jarvis"):
        self.enabled = enabled
        self.rate = rate
        self.volume = volume
        self.engine = engine
        self.piper = piper or {}
        self.voice_preset = resolve_voice_preset_key(voice_preset or self.piper.get("preset", "jarvis"))
        self.muted = False
        self.last = ""
        self.on_say = None
        self.on_voice_changed = None
        self.engine_name = VOICE_PRESETS[self.voice_preset]["title"]
        self._q = queue.Queue()
        self._pending = 0
        self._last_end = 0.0
        self._speak_started_at = 0.0
        self._wav_seq = 0
        self._lock = threading.Lock()
        if enabled:
            SOUND_PACK.sync_all_in_background()
            threading.Thread(target=self._worker, daemon=True).start()

    @classmethod
    def from_config(cls, tts: dict):
        tts = tts or {}
        preset = tts.get("voice_preset") or (tts.get("piper") or {}).get("preset") or "jarvis"
        sp = cls(
            enabled=tts.get("enabled", True),
            rate=tts.get("rate", 185),
            volume=tts.get("volume", 1.0),
            engine=tts.get("engine", "piper"),
            piper=tts.get("piper"),
            voice_preset=preset,
        )
        sp.muted = bool(tts.get("start_muted", False))
        return sp

    def get_current_voice_title(self) -> str:
        return VOICE_PRESETS.get(self.voice_preset, VOICE_PRESETS["jarvis"])["title"]

    def list_voices_text(self) -> str:
        items = []
        for k in VOICE_ORDER:
            mark = "★ " if k == self.voice_preset else ""
            items.append(f"{mark}{VOICE_PRESETS[k]['title']}")
        return "Доступные голоса: " + "; ".join(items) + ". Скажите: «голос Джарвис», «стиль Верити», «голос Пятница» или «голос Дмитрий»."

    def set_voice_preset(self, preset_name: str) -> str:
        key = resolve_voice_preset_key(preset_name)
        self.voice_preset = key
        preset_info = VOICE_PRESETS[key]
        self.engine_name = preset_info["title"]
        threading.Thread(target=self._ensure_piper_voice_downloaded, args=(key,), daemon=True).start()
        if self.on_voice_changed:
            try:
                self.on_voice_changed(key, preset_info["title"])
            except Exception:
                pass
        return f"Голос изменён на «{preset_info['title']}»."

    def next_voice_preset(self) -> str:
        try:
            idx = VOICE_ORDER.index(self.voice_preset)
        except ValueError:
            idx = 0
        next_key = VOICE_ORDER[(idx + 1) % len(VOICE_ORDER)]
        return self.set_voice_preset(next_key)

    def play_jarvis_sound_clip(self, clip_id: int) -> bool:
        """Воспроизводит оригинальный .wav файл {clip_id}.wav из пакета FitoDomik/Jarvis-Sound."""
        if os.name != "nt" or not (1 <= int(clip_id) <= 61):
            return False
        wav_path = SOUND_PACK.ensure_clip_downloaded(int(clip_id), timeout=3.0)
        if not wav_path or not os.path.isfile(wav_path):
            return False
        try:
            import winsound
            winsound.PlaySound(wav_path, winsound.SND_FILENAME | winsound.SND_NODEFAULT)
            return True
        except Exception:
            try:
                winmm = __import__("ctypes").windll.winmm
                alias = f"jclip_{int(clip_id)}"
                winmm.mciSendStringW(f"close {alias}", None, 0, None)
                if winmm.mciSendStringW(f'open "{wav_path}" type waveaudio alias {alias}', None, 0, None) == 0:
                    winmm.mciSendStringW(f"play {alias} wait", None, 0, None)
                    winmm.mciSendStringW(f"close {alias}", None, 0, None)
                    return True
            except Exception:
                pass
        return False

    def _speak_with_jarvis_soundpack(self, text: str) -> bool:
        """Основной голосовой контур FitoDomik/Jarvis-Sound:
        если ответ соответствует одной из 61 оригинальных реплик Джарвиса из фильма —
        воспроизводит студийный оригинал {N}.wav из FitoDomik/Jarvis-Sound!"""
        preset_info = VOICE_PRESETS.get(self.voice_preset, VOICE_PRESETS["jarvis"])
        if not preset_info.get("use_sound_pack", False):
            return False
        clip_id, exact_only = SOUND_PACK.match_clips_for_text(text)
        if clip_id is not None:
            played = self.play_jarvis_sound_clip(clip_id)
            if played and exact_only:
                return True
        return False

    def _ensure_piper_voice_downloaded(self, preset_key: str):
        info = VOICE_PRESETS.get(preset_key) or {}
        url = info.get("piper_download_url", "")
        if not url:
            return
        voices_dir = _abs("piper/voices")
        os.makedirs(voices_dir, exist_ok=True)
        fname = os.path.basename(url)
        onnx_path = os.path.join(voices_dir, fname)
        json_path = onnx_path + ".json"
        if os.path.isfile(onnx_path) and os.path.isfile(json_path) and os.path.getsize(onnx_path) > 1_000_000:
            return
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            for target_url, target_file in [(url, onnx_path), (url + ".json", json_path)]:
                req = urllib.request.Request(target_url, headers={"User-Agent": "JarvisAssistant/3.5"})
                with opener.open(req, timeout=25) as resp, open(target_file + ".part", "wb") as out_f:
                    shutil.copyfileobj(resp, out_f)
                os.replace(target_file + ".part", target_file)
            print(f"[Озвучка] Загружен нейросетевой голос Piper: {fname}")
        except Exception:
            pass

    def find_piper(self):
        exe = _abs(self.piper.get("exe", "piper/piper.exe"))
        if not os.path.isfile(exe):
            hits = glob.glob(os.path.join(BASE, "piper", "**", "piper.exe"), recursive=True)
            exe = hits[0] if hits else None
        if not exe:
            hits = glob.glob(os.path.join(BASE, "piper", "**", "piper"), recursive=True)
            exe = hits[0] if hits else None

        preset_info = VOICE_PRESETS.get(self.voice_preset, VOICE_PRESETS["jarvis"])
        preferred_names = preset_info.get("piper_models", [])

        onnx_all = glob.glob(os.path.join(BASE, "piper", "**", "*.onnx"), recursive=True)
        by_name = {os.path.basename(p).lower(): p for p in onnx_all if os.path.isfile(p + ".json")}

        model = None
        for pref in preferred_names:
            if pref.lower() in by_name:
                model = by_name[pref.lower()]
                break

        if not model:
            cfg_model = _abs(self.piper.get("model", ""))
            if os.path.isfile(cfg_model) and os.path.isfile(cfg_model + ".json"):
                model = cfg_model
            else:
                ru = [m for m in onnx_all if "ru_ru" in os.path.basename(m).lower() and os.path.isfile(m + ".json")]
                model = (ru or onnx_all or [None])[0]

        return exe, model

    def _speak_with_piper(self, text: str) -> bool:
        exe, model = self.find_piper()
        if not exe or not model or not os.path.isfile(model + ".json"):
            return False
        import winsound
        preset_info = VOICE_PRESETS.get(self.voice_preset, VOICE_PRESETS["jarvis"])
        self._wav_seq = (self._wav_seq + 1) % 4
        out = os.path.join(tempfile.gettempdir(), f"jarvis_tts_{self._wav_seq}.wav")
        scale = str(preset_info.get("piper_speed", self.piper.get("speed", 0.93)))
        dsp_mode = preset_info.get("dsp", "jarvis")
        self.engine_name = f"{preset_info['title']}"

        clean = database.strip_cjk(text or "").replace("\n", " ").strip()
        if not clean:
            return True

        cmd = [exe, "--model", model, "--output_file", out, "--length_scale", scale]
        r = subprocess.run(
            cmd,
            input=clean.encode("utf-8"),
            capture_output=True,
            creationflags=0x08000000 if os.name == "nt" else 0,
            cwd=os.path.dirname(exe),
            timeout=12,
        )
        if r.returncode != 0:
            raise RuntimeError(r.stderr.decode("utf-8", "replace")[-300:] or f"код {r.returncode}")

        apply_jarvis_dsp_to_wav(out, dsp_mode=dsp_mode)
        winsound.PlaySound(out, winsound.SND_FILENAME | winsound.SND_NODEFAULT)
        return True

    def _speak_with_edge_neural(self, text: str) -> bool:
        if os.name != "nt":
            return False
        clean = database.strip_cjk(text or "").replace("\n", " ").strip()[:600]
        if not clean:
            return True
        preset_info = VOICE_PRESETS.get(self.voice_preset, VOICE_PRESETS["jarvis"])
        edge_voice = preset_info.get("edge_voice") or (
            "ru-RU-SvetlanaNeural" if self.voice_preset in ("friday", "irina") else "ru-RU-DmitryNeural"
        )
        edge_rate = preset_info.get("edge_rate", "+6%")
        edge_pitch = preset_info.get("edge_pitch", "-4Hz")
        try:
            import asyncio
            import edge_tts
            import ctypes
            self._wav_seq = (self._wav_seq + 1) % 4
            mp3_path = os.path.join(tempfile.gettempdir(), f"jarvis_edge_{self._wav_seq}.mp3")

            async def _gen():
                comm = edge_tts.Communicate(clean, voice=edge_voice, rate=edge_rate, pitch=edge_pitch)
                await comm.save(mp3_path)

            asyncio.run(asyncio.wait_for(_gen(), timeout=4.5))
            if not os.path.isfile(mp3_path) or os.path.getsize(mp3_path) < 200:
                return False

            winmm = ctypes.windll.winmm
            alias = f"jtts_{self._wav_seq}"
            winmm.mciSendStringW(f"close {alias}", None, 0, None)
            rc = winmm.mciSendStringW(f'open "{mp3_path}" type mpegvideo alias {alias}', None, 0, None)
            if rc != 0:
                return False
            winmm.mciSendStringW(f"play {alias} wait", None, 0, None)
            winmm.mciSendStringW(f"close {alias}", None, 0, None)
            return True
        except Exception:
            return False

    def _speak_with_sapi_safe(self, text: str):
        if os.name != "nt":
            return
        clean = re.sub(r"[\"'`$]", "", database.strip_cjk(text or "").replace("\n", " ")).strip()[:500]
        if not clean:
            return
        preset_info = VOICE_PRESETS.get(self.voice_preset, VOICE_PRESETS["jarvis"])
        dsp_mode = preset_info.get("dsp", "jarvis")
        self._wav_seq = (self._wav_seq + 1) % 4
        out_wav = os.path.join(tempfile.gettempdir(), f"jarvis_sapi_{self._wav_seq}.wav")
        ps = (
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            "$s.Rate = 1; "
            f"$s.SetOutputToWaveFile('{out_wav}'); "
            f"$s.Speak('{clean}'); "
            "$s.Dispose()"
        )
        try:
            subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps],
                capture_output=True,
                creationflags=0x08000000,
                timeout=12,
            )
            if os.path.isfile(out_wav) and os.path.getsize(out_wav) > 200:
                apply_jarvis_dsp_to_wav(out_wav, dsp_mode=dsp_mode)
                import winsound
                winsound.PlaySound(out_wav, winsound.SND_FILENAME | winsound.SND_NODEFAULT)
        except Exception:
            pass

    def _worker(self):
        threading.Thread(target=self._ensure_piper_voice_downloaded, args=(self.voice_preset,), daemon=True).start()
        while True:
            text = self._q.get()
            self._speak_started_at = time.time()
            try:
                # 0) ОСНОВА ОЗВУЧКИ: Оригинальные .wav реплики Джарвиса из репозитория FitoDomik/Jarvis-Sound!
                ok = self._speak_with_jarvis_soundpack(text)
                # 1) Если это динамический текст (время, чтение экрана, свободный ответ ИИ) — озвучиваем через Piper + DSP
                if not ok:
                    ok = self._speak_with_piper(text)
                # 2) Или через студийный нейроголос (Джарвис / Верити)
                if not ok:
                    ok = self._speak_with_edge_neural(text)
                # 3) Офлайн-резерв с обработкой через DSP
                if not ok:
                    self._speak_with_sapi_safe(text)
            except Exception as e:
                print("Ошибка озвучки, переключаюсь на резервный контур:", e)
                self._speak_with_sapi_safe(text)
            finally:
                with self._lock:
                    self._pending = max(0, self._pending - 1)
                self._last_end = time.time()
                self._speak_started_at = 0.0
                try:
                    import actions
                    b_obj = actions.RUNTIME.get("brain")
                    if b_obj is not None:
                        b_obj.last_active = time.time()
                    lst_obj = actions.RUNTIME.get("listener")
                    if lst_obj is not None and hasattr(lst_obj, "_drain_queue"):
                        lst_obj._drain_queue()
                except Exception:
                    pass

    def say(self, text: str, force: bool = False, show: bool = True):
        clean_text = database.strip_cjk(text or "")
        if not clean_text:
            return
        print(f"[Джарвис] {clean_text}")
        self.last = clean_text
        if show and self.on_say:
            try:
                self.on_say(clean_text)
            except Exception:
                pass
        if not self.enabled or (self.muted and not force):
            return
        with self._lock:
            self._pending += 1
        self._q.put(clean_text)

    def stop(self):
        while not self._q.empty():
            try:
                self._q.get_nowait()
            except queue.Empty:
                break
        with self._lock:
            self._pending = 0
        self._speak_started_at = 0.0
        if os.name == "nt":
            try:
                import winsound
                winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception:
                pass

    def busy(self) -> bool:
        if self._speak_started_at > 0 and (time.time() - self._speak_started_at) > 12.0:
            with self._lock:
                self._pending = 0
            self._speak_started_at = 0.0
            return False
        return self._pending > 0 or (time.time() - self._last_end) < 0.28


# ═════════════════════════════════════════════════════════════════════════════
# МУЛЬТИ-КАСКАДНАЯ СИСТЕМА РАСПОЗНАВАНИЯ РЕЧИ (NEURAL MULTIPATH PRO)
# ═════════════════════════════════════════════════════════════════════════════
def _recognize_via_google_neural_pcm(pcm_int16_bytes: bytes, sample_rate: int = 16000, timeout: float = 2.0) -> str:
    try:
        import speech_recognition as sr
        audio_data = sr.AudioData(pcm_int16_bytes, int(sample_rate), 2)
        flac_data = audio_data.get_flac_data(convert_rate=16000 if sample_rate > 16000 else None, convert_width=2)
        rate_sent = 16000 if sample_rate > 16000 else int(sample_rate)
        key = getattr(sr.Recognizer, "GOOGLE_SPEECH_RECOGNITION_API_KEY", None)
        if key:
            url = (
                f"http://www.google.com/speech-api/v2/recognize?"
                f"client=chromium&lang=ru-RU&key={urllib.parse.quote(key)}"
            )
            req = urllib.request.Request(
                url,
                data=flac_data,
                headers={"Content-Type": f"audio/x-flac; rate={rate_sent}"},
                method="POST",
            )
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(req, timeout=float(timeout)) as resp:
                raw_lines = resp.read().decode("utf-8", errors="replace").splitlines()
            for line in raw_lines:
                if not line.strip():
                    continue
                obj = json.loads(line)
                res_list = obj.get("result") or []
                if res_list and res_list[0].get("alternative"):
                    transcript = database.strip_cjk(res_list[0]["alternative"][0].get("transcript", "")).strip()
                    if transcript:
                        return transcript
    except Exception:
        pass

    try:
        import speech_recognition as sr
        recognizer = sr.Recognizer()
        recognizer.operation_timeout = float(timeout)
        audio_data = sr.AudioData(pcm_int16_bytes, int(sample_rate), 2)
        text = database.strip_cjk(recognizer.recognize_google(audio_data, language="ru-RU") or "").strip()
        if text:
            return text
    except Exception:
        pass
    return ""


class Listener:
    """Непрерывный многоходовой слушатель Джарвиса (Neural Multipath Pro)."""

    def __init__(
        self,
        model_path=None,
        speaker: Speaker = None,
        device=None,
        pause_check=None,
        stt_engine: str = "multipath_pro",
        whisper_model: str = "base",
        cfg: dict = None,
    ):
        self.model_path = model_path
        self.speaker = speaker
        self.device = device
        self.pause_check = pause_check or (lambda: False)
        eng = (stt_engine or "multipath_pro").lower().strip()
        if eng in ("vosk", "hybrid_best", "hybrid"):
            eng = "multipath_pro"
        self.stt_engine = eng
        self.whisper_model_name = whisper_model or "base"
        self.cfg = cfg or {}
        self.ready = False
        self.q = queue.Queue()
        self.rate = 16000
        self.whisper_model = None
        self.active_backend_name = "Neural Multipath Pro (Whisper + Google)"
        self.current_level = 0.0
        self.on_speech_state = None
        self._context_prompt, self._hotwords = build_whisper_context_prompt(self.cfg)
        self._whisper_lock = threading.Lock()
        self._last_callback_time = time.time()

    def get_current_stt_key(self) -> str:
        if self.stt_engine in ("google_direct", "google_neural"):
            return "google_direct"
        if self.stt_engine == "faster_whisper":
            wm = (self.whisper_model_name or "").lower()
            if "turbo" in wm or "large" in wm:
                return "whisper_turbo"
            if "small" in wm:
                return "whisper_small"
            return "whisper_base"
        return "multipath_pro"

    def get_status_text(self) -> str:
        return (
            f"Активная модель слуха: {self.active_backend_name} "
            f"(режим: {self.stt_engine}, локальная модель: {self.whisper_model_name}, автоусиление AGC включено)."
        )

    def switch_stt_model(self, engine_or_size: str) -> str:
        q = (engine_or_size or "").lower().strip()
        if q == "google_direct" or "google" in q or "гугл" in q or "облак" in q or "онлайн" in q:
            self.stt_engine = "google_direct"
            self.active_backend_name = "Google Neural Direct (Без прокси)"
            self.ready = True
            return f"Модель распознавания речи переключена на «{self.active_backend_name}»."

        if q in ("multipath_pro", "hybrid_best") or any(w in q for w in ("multipath", "мульти", "каскад", "гибрид", "hybrid", "лучш", "про")):
            self.stt_engine = "multipath_pro"
            self.active_backend_name = f"Neural Multipath Pro (Whisper {self.whisper_model_name} + Google)"
            self.ready = True
            if self.whisper_model is None:
                threading.Thread(target=self._reload_whisper_async, args=(self.whisper_model_name, self.active_backend_name), daemon=True).start()
            return f"Модель распознавания речи переключена на «{self.active_backend_name}»."

        if "turbo" in q or "турбо" in q or "large" in q:
            target_size = "deepdml/faster-whisper-large-v3-turbo-ct2"
            human_name = "Faster-Whisper Large-v3-Turbo"
        elif "small" in q or "смол" in q:
            target_size = "small"
            human_name = "Faster-Whisper Small (Точная офлайн)"
        elif "medium" in q or "медиум" in q:
            target_size = "medium"
            human_name = "Faster-Whisper Medium"
        else:
            target_size = "base"
            human_name = "Faster-Whisper Base (Быстрая офлайн)"

        self.stt_engine = "faster_whisper"
        self.whisper_model_name = target_size
        self.active_backend_name = human_name
        threading.Thread(target=self._reload_whisper_async, args=(target_size, human_name), daemon=True).start()
        return f"Модель распознавания речи переключена на «{human_name}»."

    def _reload_whisper_async(self, model_size: str, human_name: str):
        try:
            self._load_whisper_model(model_size)
            if self.stt_engine == "faster_whisper":
                self.active_backend_name = human_name
            elif self.stt_engine == "multipath_pro":
                self.active_backend_name = f"Neural Multipath Pro (Whisper {self.whisper_model_name} + Google)"
            print(f"[Слух] Подгружена локальная нейросеть: {self.active_backend_name}")
        except Exception as e:
            print(f"[Слух] Не удалось загрузить {model_size}: {e}")

    def _try_instantiate_whisper(self, model_size: str, local_only: bool):
        from faster_whisper import WhisperModel
        whisper_dir = os.path.join(BASE, "models", "whisper")
        os.makedirs(whisper_dir, exist_ok=True)
        cpu_threads = max(2, min(8, (os.cpu_count() or 4)))
        for dev, ctype in [("cuda", "float16"), ("cpu", "int8")]:
            try:
                kwargs = dict(device=dev, compute_type=ctype, download_root=whisper_dir, local_files_only=local_only)
                if dev == "cpu":
                    kwargs["cpu_threads"] = cpu_threads
                model = WhisperModel(model_size, **kwargs)
                with self._whisper_lock:
                    self.whisper_model = model
                    self.whisper_model_name = model_size
                return True
            except Exception:
                pass
        return False

    def _load_whisper_model(self, preferred_size: str):
        candidates_local = []
        for c in (preferred_size, "base", "small", "tiny"):
            if c and c not in candidates_local:
                candidates_local.append(c)

        for cand in candidates_local:
            if self._try_instantiate_whisper(cand, local_only=True):
                print(f"[Слух] Мгновенно подключена локальная модель из кэша: {cand}")
                if cand != preferred_size and preferred_size:
                    threading.Thread(
                        target=lambda: self._try_instantiate_whisper(preferred_size, local_only=False),
                        daemon=True,
                    ).start()
                return

        for cand in candidates_local:
            if self._try_instantiate_whisper(cand, local_only=False):
                return
        raise RuntimeError(f"Не удалось инициализировать Faster-Whisper ({preferred_size})")

    def load(self):
        import sounddevice as sd
        rate = 16000
        try:
            sd.check_input_settings(device=self.device, samplerate=16000, channels=1, dtype="int16")
        except Exception:
            try:
                rate = int(sd.query_devices(self.device, "input")["default_samplerate"])
            except Exception:
                rate = 16000
        self.rate = rate
        self.ready = True

        def _bg_init():
            target = self.whisper_model_name or "base"
            try:
                self._load_whisper_model(target)
                print(f"[Слух] {self.active_backend_name} полностью готов!")
            except Exception as e:
                print(f"[Слух] Работаю через прямой Google Neural Speech ({e})")

        threading.Thread(target=_bg_init, daemon=True).start()

    def _callback(self, indata, frames, t, status):
        self._last_callback_time = time.time()
        if self.speaker and self.speaker.busy():
            self.current_level = 0.0
            return
        if self.pause_check():
            self.current_level = 0.0
            return
        self.q.put(bytes(indata))

    def _transcribe_with_whisper(self, pcm_bytes: bytes) -> str:
        with self._whisper_lock:
            model = self.whisper_model
        if model is None:
            return ""
        try:
            import numpy as np
            audio_np = np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32) / 32768.0
            if self.rate != 16000 and len(audio_np) > 100:
                duration = len(audio_np) / float(self.rate)
                target_len = int(duration * 16000)
                if target_len > 100:
                    audio_np = np.interp(
                        np.linspace(0.0, 1.0, target_len, endpoint=False),
                        np.linspace(0.0, 1.0, len(audio_np), endpoint=False),
                        audio_np,
                    ).astype(np.float32)

            kwargs = dict(
                language="ru",
                beam_size=1,
                best_of=1,
                temperature=0.0,
                vad_filter=False,
                without_timestamps=True,
                condition_on_previous_text=False,
                no_speech_threshold=0.72,
                initial_prompt=self._context_prompt,
            )
            if self._hotwords:
                kwargs["hotwords"] = self._hotwords

            try:
                segments, _ = model.transcribe(audio_np, **kwargs)
            except TypeError:
                kwargs.pop("hotwords", None)
                segments, _ = model.transcribe(audio_np, **kwargs)

            text = database.strip_cjk(" ".join(s.text.strip() for s in segments if s.text)).strip()
            if text and not is_whisper_hallucination(text):
                return text
        except Exception as e:
            print(f"[Whisper] ошибка распознавания: {e}")
        return ""

    def _transcribe_chunk(self, pcm_bytes: bytes) -> str:
        norm_pcm = normalize_pcm_audio(pcm_bytes, sample_rate=self.rate)

        if self.stt_engine in ("google_direct", "google_neural"):
            text_g = _run_with_hard_timeout(_recognize_via_google_neural_pcm, (norm_pcm, self.rate, 2.0), timeout=2.3, default="")
            if text_g and not is_whisper_hallucination(text_g):
                print(f"[Слух · Google Direct] «{text_g}»")
                return text_g
            text_w = _run_with_hard_timeout(self._transcribe_with_whisper, (norm_pcm,), timeout=3.0, default="")
            if text_w:
                print(f"[Слух · Whisper Fallback] «{text_w}»")
                return text_w
            return ""

        if self.stt_engine == "faster_whisper":
            if self.whisper_model is not None:
                text_w = _run_with_hard_timeout(self._transcribe_with_whisper, (norm_pcm,), timeout=3.2, default="")
                if text_w:
                    print(f"[Слух · Whisper] «{text_w}»")
                    return text_w
            text_g = _run_with_hard_timeout(_recognize_via_google_neural_pcm, (norm_pcm, self.rate, 2.0), timeout=2.3, default="")
            if text_g and not is_whisper_hallucination(text_g):
                print(f"[Слух · Google Direct] «{text_g}»")
                return text_g
            return ""

        results = {"google": "", "whisper": ""}
        ready_evt = threading.Event()

        def _worker_g():
            r = _recognize_via_google_neural_pcm(norm_pcm, self.rate, 1.9)
            if r and not is_whisper_hallucination(r):
                results["google"] = r
                ready_evt.set()

        def _worker_w():
            r = self._transcribe_with_whisper(norm_pcm)
            if r and not is_whisper_hallucination(r):
                results["whisper"] = r
                ready_evt.set()

        threading.Thread(target=_worker_g, daemon=True).start()
        if self.whisper_model is not None:
            threading.Thread(target=_worker_w, daemon=True).start()

        ready_evt.wait(timeout=2.4)
        if not (results["google"] and results["whisper"]):
            time.sleep(0.06)

        winner = results["google"] or results["whisper"]
        if winner:
            src_name = "Google Direct" if results["google"] else f"Whisper {self.whisper_model_name}"
            print(f"[Слух · {src_name}] «{winner}»")
            return winner

        if self.whisper_model is not None and not results["whisper"]:
            for _ in range(12):
                if results["whisper"]:
                    print(f"[Слух · Whisper {self.whisper_model_name}] «{results['whisper']}»")
                    return results["whisper"]
                time.sleep(0.1)

        return ""

    def _drain_queue(self):
        while not self.q.empty():
            try:
                self.q.get_nowait()
            except queue.Empty:
                break

    def phrases(self):
        import sounddevice as sd

        if not self.ready:
            self.load()

        blocksize = int(self.rate * 0.12)
        chunk_sec = 0.12
        pre_roll = collections.deque(maxlen=5)
        speech_buf = bytearray()
        speaking = False
        speech_dur = 0.0
        silence_dur = 0.0
        noise_floor = 0.015
        was_speaker_busy = False
        self._last_callback_time = time.time()

        with sd.RawInputStream(
            samplerate=self.rate,
            blocksize=blocksize,
            device=self.device,
            dtype="int16",
            channels=1,
            callback=self._callback,
        ):
            while True:
                if self.speaker and self.speaker.busy():
                    was_speaker_busy = True
                    speech_buf.clear()
                    pre_roll.clear()
                    speaking = False
                    speech_dur = 0.0
                    silence_dur = 0.0
                    self.current_level = 0.0
                    self._drain_queue()
                    time.sleep(0.08)
                    continue

                if was_speaker_busy:
                    was_speaker_busy = False
                    time.sleep(0.12)
                    self._drain_queue()
                    speech_buf.clear()
                    pre_roll.clear()
                    speaking = False
                    speech_dur = 0.0
                    silence_dur = 0.0
                    noise_floor = max(0.012, min(0.050, noise_floor))
                    try:
                        import actions
                        b_obj = actions.RUNTIME.get("brain")
                        if b_obj is not None:
                            b_obj.last_active = time.time()
                    except Exception:
                        pass

                try:
                    data = self.q.get(timeout=0.35)
                except queue.Empty:
                    if self.speaker and self.speaker.busy():
                        was_speaker_busy = True
                        continue
                    if (time.time() - self._last_callback_time) > 3.5 and not self.pause_check():
                        raise RuntimeError("Перезапуск аудиопотока микрофона после паузы драйвера")
                    continue

                if self.speaker and self.speaker.busy():
                    was_speaker_busy = True
                    speech_buf.clear()
                    pre_roll.clear()
                    speaking = False
                    continue

                lvl, _zcr = filter_and_measure_chunk(data)
                self.current_level = lvl

                trigger_level = max(0.017, min(0.080, noise_floor * 2.1 + 0.005))

                if not speaking:
                    if lvl > trigger_level:
                        speaking = True
                        speech_dur = chunk_sec
                        silence_dur = 0.0
                        try:
                            import actions
                            b_obj = actions.RUNTIME.get("brain")
                            if b_obj is not None:
                                b_obj.last_active = time.time()
                        except Exception:
                            pass
                        speech_buf.clear()
                        for prev_chunk in pre_roll:
                            speech_buf.extend(prev_chunk)
                        speech_buf.extend(data)
                    else:
                        pre_roll.append(data)
                        noise_floor = max(0.008, min(0.060, 0.94 * noise_floor + 0.06 * lvl))
                else:
                    speech_buf.extend(data)
                    speech_dur += chunk_sec

                    keep_threshold = max(trigger_level * 0.76, noise_floor * 1.60)
                    if speech_dur > 2.2:
                        noise_floor = max(0.008, min(0.060, 0.97 * noise_floor + 0.03 * lvl))

                    if lvl > keep_threshold:
                        silence_dur = 0.0
                        try:
                            import actions
                            b_obj = actions.RUNTIME.get("brain")
                            if b_obj is not None:
                                b_obj.last_active = time.time()
                        except Exception:
                            pass
                    else:
                        silence_dur += chunk_sec

                    if silence_dur >= 0.36 or speech_dur >= 7.2:
                        raw_pcm = bytes(speech_buf)
                        speech_buf.clear()
                        pre_roll.clear()
                        speaking = False
                        speech_dur = 0.0
                        silence_dur = 0.0
                        noise_floor = max(0.010, min(0.055, noise_floor))

                        if len(raw_pcm) >= int(self.rate * 2 * 0.20):
                            if self.on_speech_state:
                                try:
                                    self.on_speech_state("🎙 Распознаю фразу…")
                                except Exception:
                                    pass
                            text = self._transcribe_chunk(raw_pcm)
                            self._drain_queue()
                            if text:
                                yield text

    def listen_stream(self, callback_func, on_loaded=None, on_error=None):
        if not self.ready:
            try:
                self.load()
            except Exception as e:
                if on_error:
                    try:
                        on_error(str(e))
                    except Exception:
                        pass
                return

        if on_loaded:
            try:
                on_loaded()
            except Exception:
                pass

        while True:
            try:
                for phrase in self.phrases():
                    try:
                        callback_func(phrase)
                    except Exception as cb_err:
                        print(f"[Слух] Ошибка обработчика фразы: {cb_err}")
            except Exception as stream_err:
                print(f"[Слух] Обновление аудиопотока микрофона: {stream_err}")
                time.sleep(0.25)

"""Кастомные виджеты Джарвиса — 3D-поворот сферы, симметричные живые глазки и 7 цветовых тем:
  1. JARVIS_COLOR_THEMES — 7 полноценных цветовых палитр 3D-сферы, фонового свечения и карточек чата:
     • 'violet'   — Фиолетовый Неон (По умолчанию)
     • 'cyan'     — Голубой Реактор (Классический J.A.R.V.I.S.)
     • 'gold'     — Золотой Марк-85 (Ядро J.A.R.V.I.S. из фильма)
     • 'crimson'  — Алый Рубин (Iron Man Red)
     • 'emerald'  — Изумрудный Неон
     • 'sapphire' — Глубокий Сапфир
     • 'rose'     — Розовый Кварц
  2. LiquidGlassPanel — глубокий тёмно-обсидиановый фон с мягким радиальным свечением выбранного цвета.
  3. CoreWidget — объёмная 3D-сфера выбранного цвета с симметричными белыми глазками, которые
     плавно (60 FPS) поворачиваются в 3D-пространстве за курсором мыши без деформации размера.
"""
import math
import random

from PyQt6.QtWidgets import QWidget, QFrame
from PyQt6.QtCore import QTimer, Qt, QPointF, QRectF, pyqtSignal
from PyQt6.QtGui import (
    QPainter, QColor, QPen, QBrush, QRadialGradient,
    QLinearGradient, QPainterPath, QCursor
)


# ═════════════════════════════════════════════════════════════════════════════
# КАТАЛОГ ЦВЕТОВЫХ ТЕМ ДЖАРВИСА (ДЛЯ 3D-СФЕРЫ, ФОНА И ИНТЕРФЕЙСА)
# ═════════════════════════════════════════════════════════════════════════════
JARVIS_COLOR_THEMES = {
    "violet": {
        "title": "🟣 Фиолетовый Неон",
        "hex": "#8b5cf6",
        "accent": (139, 92, 246),
        "border": (167, 139, 250),
        "card_bg": (38, 22, 68),
        "sphere": [
            (0.00, (236, 224, 255)),
            (0.24, (182, 144, 255)),
            (0.58, (126, 68, 242)),
            (0.88, (86, 34, 194)),
            (1.00, (52, 18, 128)),
        ],
        "aliases": ["фиолетовый", "сиреневый", "пурпурный", "лавандовый", "неон", "стандартный", "violet", "purple"],
    },
    "cyan": {
        "title": "🔵 Голубой Реактор",
        "hex": "#06b6d4",
        "accent": (6, 182, 212),
        "border": (56, 189, 248),
        "card_bg": (14, 38, 56),
        "sphere": [
            (0.00, (224, 248, 255)),
            (0.24, (103, 232, 249)),
            (0.58, (6, 182, 212)),
            (0.88, (14, 116, 144)),
            (1.00, (8, 58, 82)),
        ],
        "aliases": ["голубой", "бирюзовый", "циановый", "реактор", "арк реактор", "классический", "cyan", "aqua"],
    },
    "gold": {
        "title": "🟡 Золотой Марк-85",
        "hex": "#f59e0b",
        "accent": (245, 158, 11),
        "border": (251, 191, 36),
        "card_bg": (52, 32, 12),
        "sphere": [
            (0.00, (255, 248, 220)),
            (0.24, (253, 212, 92)),
            (0.58, (245, 158, 11)),
            (0.88, (180, 83, 9)),
            (1.00, (108, 42, 6)),
        ],
        "aliases": ["золотой", "желтый", "жёлтый", "янтарный", "оранжевый", "золото", "марк", "gold", "yellow", "orange"],
    },
    "crimson": {
        "title": "🔴 Алый Рубин",
        "hex": "#ef4444",
        "accent": (239, 68, 68),
        "border": (248, 113, 113),
        "card_bg": (56, 16, 24),
        "sphere": [
            (0.00, (255, 228, 230)),
            (0.24, (252, 136, 136)),
            (0.58, (225, 45, 60)),
            (0.88, (153, 20, 32)),
            (1.00, (88, 10, 18)),
        ],
        "aliases": ["красный", "алый", "рубиновый", "бордовый", "red", "crimson"],
    },
    "emerald": {
        "title": "🟢 Изумрудный Неон",
        "hex": "#10b981",
        "accent": (16, 185, 129),
        "border": (52, 211, 153),
        "card_bg": (12, 46, 36),
        "sphere": [
            (0.00, (220, 255, 240)),
            (0.24, (110, 238, 183)),
            (0.58, (16, 185, 129)),
            (0.88, (5, 122, 85)),
            (1.00, (4, 68, 48)),
        ],
        "aliases": ["зеленый", "зелёный", "изумрудный", "мятный", "матрица", "green", "emerald"],
    },
    "sapphire": {
        "title": "🔷 Глубокий Сапфир",
        "hex": "#3b82f6",
        "accent": (59, 130, 246),
        "border": (96, 165, 250),
        "card_bg": (16, 28, 62),
        "sphere": [
            (0.00, (226, 240, 255)),
            (0.24, (130, 182, 255)),
            (0.58, (59, 130, 246)),
            (0.88, (29, 78, 216)),
            (1.00, (16, 42, 118)),
        ],
        "aliases": ["синий", "сапфир", "сапфировый", "кобальт", "индиго", "blue", "sapphire"],
    },
    "rose": {
        "title": "🌸 Розовый Кварц",
        "hex": "#ec4899",
        "accent": (236, 72, 153),
        "border": (244, 114, 182),
        "card_bg": (54, 16, 42),
        "sphere": [
            (0.00, (255, 228, 246)),
            (0.24, (249, 148, 204)),
            (0.58, (236, 72, 153)),
            (0.88, (168, 28, 98)),
            (1.00, (96, 14, 56)),
        ],
        "aliases": ["розовый", "малиновый", "фуксия", "маджента", "pink", "rose"],
    },
}

COLOR_THEME_ORDER = ["violet", "cyan", "gold", "crimson", "emerald", "sapphire", "rose"]


def resolve_color_theme_key(query: str) -> str:
    q = (query or "").lower().replace("ё", "е").strip()
    if not q:
        return "violet"
    if q in JARVIS_COLOR_THEMES:
        return q
    for key, info in JARVIS_COLOR_THEMES.items():
        if q == info["title"].lower().replace("ё", "е"):
            return key
        for a in info.get("aliases", []):
            if a in q or q in a:
                return key
    return "violet"


STATE_COLORS = {
    "sleep":   QColor(139, 92, 246),
    "listen":  QColor(168, 85, 247),
    "think":   QColor(124, 58, 237),
    "speak":   QColor(167, 139, 250),
    "muted":   QColor(100, 85, 135),
    "loading": QColor(139, 92, 246),
}


class LiquidGlassPanel(QFrame):
    """Тёмно-обсидиановая панель с мягким радиальным свечением выбранного цвета."""

    GLASS_PRESETS = [
        {"name": "НЕОНОВЫЙ ОБСИДИАН", "base_alpha": 246, "glow_mult": 1.0},
        {"name": "ГЛУБОКИЙ КРИСТАЛЛ", "base_alpha": 232, "glow_mult": 1.3},
        {"name": "ПРОЗРАЧНЫЙ ЭФИР",   "base_alpha": 212, "glow_mult": 0.8},
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.preset_index = 0
        self.phase = 0.0
        self.theme_key = "violet"
        self.accent_color = QColor(139, 92, 246)

        self._anim_timer = QTimer(self)
        self._anim_timer.timeout.connect(self._tick)
        self._anim_timer.start(45)

    def set_color_theme(self, theme_key: str):
        key = resolve_color_theme_key(theme_key)
        self.theme_key = key
        r, g, b = JARVIS_COLOR_THEMES[key]["accent"]
        self.accent_color = QColor(r, g, b)
        self.update()

    def cycle_preset(self) -> str:
        self.preset_index = (self.preset_index + 1) % len(self.GLASS_PRESETS)
        self.update()
        return self.GLASS_PRESETS[self.preset_index]["name"]

    def set_accent(self, color: QColor):
        self.accent_color = QColor(color)
        self.update()

    def _tick(self):
        self.phase += 0.03
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)
        radius = 22.0

        preset = self.GLASS_PRESETS[self.preset_index]
        base_alpha = preset["base_alpha"]
        glow_m = preset["glow_mult"]

        clip_path = QPainterPath()
        clip_path.addRoundedRect(rect, radius, radius)

        p.save()
        p.setClipPath(clip_path)

        bg_grad = QLinearGradient(0, 0, 0, h)
        bg_grad.setColorAt(0.0, QColor(16, 13, 26, base_alpha))
        bg_grad.setColorAt(0.45, QColor(11, 9, 18, min(254, base_alpha + 6)))
        bg_grad.setColorAt(1.0, QColor(8, 7, 13, min(255, base_alpha + 8)))
        p.fillPath(clip_path, QBrush(bg_grad))

        p.setPen(Qt.PenStyle.NoPen)
        orb_cy = h * 0.22
        rg1 = QRadialGradient(QPointF(w * 0.5, orb_cy), w * 0.56)
        ac = QColor(self.accent_color)
        ac.setAlpha(int(min(255, 56 * glow_m)))
        ac_mid = QColor(self.accent_color).darker(135)
        ac_mid.setAlpha(int(min(255, 25 * glow_m)))
        rg1.setColorAt(0.0, ac)
        rg1.setColorAt(0.48, ac_mid)
        rg1.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setBrush(QBrush(rg1))
        p.drawRect(rect)

        p.restore()

        br, bg_c, bb = JARVIS_COLOR_THEMES.get(self.theme_key, JARVIS_COLOR_THEMES["violet"])["border"]
        border_grad = QLinearGradient(0, 0, 0, h)
        border_grad.setColorAt(0.0, QColor(br, bg_c, bb, 115))
        border_grad.setColorAt(0.5, QColor(br, bg_c, bb, 52))
        border_grad.setColorAt(1.0, QColor(br, bg_c, bb, 75))
        p.setPen(QPen(QBrush(border_grad), 1.2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(rect, radius, radius)


class CoreWidget(QWidget):
    """3D-сфера выбранного цвета, которая плавно поворачивается в 3D-пространстве за курсором мыши
    с идеально симметричными живыми глазками без искажений размера."""
    clicked = pyqtSignal()

    def __init__(self, listener=None, brain=None, parent=None):
        super().__init__(parent)
        self.listener = listener
        self.brain = brain
        self.state = "sleep"
        self.theme_key = "violet"
        self.visual_style = "verity"  # "verity" (гладкая 3D-сфера с глазками) или "jarvis_hud" (с голографическими кольцами J.A.R.V.I.S.)
        self.audio_level = 0.0
        self.smoothed_level = 0.0
        self.time_val = 0.0

        self.yaw = 0.0
        self.pitch = 0.0
        self.target_yaw = 0.0
        self.target_pitch = 0.0

        self.gaze_x = 0.0
        self.gaze_y = 0.0
        self.target_gaze_x = 0.0
        self.target_gaze_y = 0.0
        self.cursor_dist = 999.0

        self._blink_factor = 1.0
        self._blink_phase = 0
        self._next_blink_time = 2.5
        self._happy_until = 0.0
        self._last_mouse_pos = QPointF(0, 0)
        self._mouse_idle_time = 0.0

        self.setFixedHeight(154)
        self.setMinimumWidth(220)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Нажмите на Джарвиса, чтобы активировать микрофон или остановить речь")

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(16)

    def set_color_theme(self, theme_key: str):
        self.theme_key = resolve_color_theme_key(theme_key)
        self.update()

    def set_visual_style(self, style_name: str):
        s = (style_name or "").lower().strip()
        if "hud" in s or "джарвис" in s or "jarvis" in s or "реактор" in s:
            self.visual_style = "jarvis_hud"
        else:
            self.visual_style = "verity"
        self.update()

    def set_state(self, state: str):
        if state == "speak" and self.state != "speak":
            self._blink_phase = 1
        self.state = state

    def trigger_happy(self, duration: float = 1.4):
        self._happy_until = self.time_val + duration

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.trigger_happy(1.2)
            self.clicked.emit()
            event.accept()
            return
        super().mousePressEvent(event)

    def _update_gaze_target(self):
        w, h = float(self.width()), float(self.height())
        cx, cy = w / 2.0, h / 2.0

        max_yaw = 0.44
        max_pitch = 0.34

        if self.state == "think":
            self.target_yaw = math.sin(self.time_val * 2.4) * 0.30
            self.target_pitch = -0.14 + math.cos(self.time_val * 1.7) * 0.08
            self.cursor_dist = 999.0
            return

        if self.state == "muted":
            self.target_yaw = 0.0
            self.target_pitch = 0.10
            self.cursor_dist = 999.0
            return

        try:
            global_pos = QCursor.pos()
            local_pos = self.mapFromGlobal(global_pos)
            mx, my = float(local_pos.x()), float(local_pos.y())
        except Exception:
            mx, my = cx, cy

        if math.hypot(mx - self._last_mouse_pos.x(), my - self._last_mouse_pos.y()) > 1.5:
            self._last_mouse_pos = QPointF(mx, my)
            self._mouse_idle_time = 0.0
        else:
            self._mouse_idle_time += 0.016

        dx = mx - cx
        dy = my - cy
        dist = math.hypot(dx, dy)
        self.cursor_dist = dist

        if dist > 1.0:
            norm_factor = math.tanh(dist / 180.0)
            tyaw = (dx / dist) * norm_factor * max_yaw
            tpitch = (dy / dist) * norm_factor * max_pitch
        else:
            tyaw, tpitch = 0.0, 0.0

        if self._mouse_idle_time > 6.0:
            tyaw += math.sin(self.time_val * 0.85) * 0.07
            tpitch += math.cos(self.time_val * 0.65) * 0.05

        if self.state == "speak":
            tyaw *= 0.72
            tpitch = tpitch * 0.72 + math.sin(self.time_val * 8.0) * 0.04

        self.target_yaw = max(-max_yaw, min(max_yaw, tyaw))
        self.target_pitch = max(-max_pitch, min(max_pitch, tpitch))

    def _update_blink(self):
        if self._blink_phase == 0:
            if self.time_val >= self._next_blink_time:
                self._blink_phase = 1
        elif self._blink_phase == 1:
            self._blink_factor -= 0.24
            if self._blink_factor <= 0.06:
                self._blink_factor = 0.06
                self._blink_phase = 2
        elif self._blink_phase == 2:
            self._blink_factor += 0.20
            if self._blink_factor >= 1.0:
                self._blink_factor = 1.0
                self._blink_phase = 0
                if random.random() < 0.16:
                    self._next_blink_time = self.time_val + 0.18
                else:
                    self._next_blink_time = self.time_val + random.uniform(2.8, 5.2)

    def _tick(self):
        self.time_val += 0.016
        self._update_gaze_target()
        self._update_blink()

        smooth_k = 0.16 if self.state != "speak" else 0.20
        self.yaw += (self.target_yaw - self.yaw) * smooth_k
        self.pitch += (self.target_pitch - self.pitch) * smooth_k

        self.gaze_x = math.sin(self.yaw) * 42.0
        self.gaze_y = math.sin(self.pitch) * 38.0
        self.target_gaze_x = math.sin(self.target_yaw) * 42.0
        self.target_gaze_y = math.sin(self.target_pitch) * 38.0

        if self.state == "speak":
            wave1 = abs(math.sin(self.time_val * 9.5))
            wave2 = abs(math.cos(self.time_val * 14.2)) * 0.6
            self.audio_level = 0.28 + 0.52 * (wave1 * 0.65 + wave2 * 0.35)
        elif self.listener and hasattr(self.listener, "current_level") and self.state != "muted":
            self.audio_level = float(self.listener.current_level)
        else:
            self.audio_level = 0.04 + 0.02 * math.sin(self.time_val * 2.0)

        self.smoothed_level += (self.audio_level - self.smoothed_level) * 0.28
        self.update()

    def _draw_dome_eye(self, p: QPainter, cx: float, cy: float, w: float, h: float, mode: str = "dome", roll_deg: float = 0.0):
        p.save()
        p.translate(cx, cy)
        if abs(roll_deg) > 0.08:
            p.rotate(roll_deg)

        if mode == "sleep" or h <= 2.6:
            pen = QPen(QColor(255, 255, 255, 238), 2.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawLine(QPointF(-w * 0.45, 0), QPointF(w * 0.45, 0))
            p.restore()
            return

        if mode == "happy":
            path = QPainterPath()
            path.moveTo(-w * 0.46, h * 0.24)
            path.quadTo(0, -h * 0.76, w * 0.46, h * 0.24)
            pen = QPen(QColor(255, 255, 255, 252), 3.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(path)
            p.restore()
            return

        glow_grad = QRadialGradient(QPointF(0, 0), max(w, h) * 0.90)
        glow_grad.setColorAt(0.0, QColor(255, 255, 255, 68))
        glow_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(glow_grad))
        p.drawEllipse(QRectF(-w * 0.68, -h * 0.78, w * 1.36, h * 1.56))

        path = QPainterPath()
        hw = w / 2.0
        hh = h / 2.0
        if mode == "wide":
            path.addRoundedRect(QRectF(-hw, -hh, w, h), hw * 0.82, hh * 0.82)
        else:
            bottom_y = hh * 0.72
            top_y = -hh * 1.05
            corner_r = min(4.0, hw * 0.28)
            path.moveTo(-hw + corner_r, bottom_y)
            path.lineTo(hw - corner_r, bottom_y)
            path.quadTo(hw, bottom_y, hw, bottom_y - corner_r)
            path.cubicTo(hw, top_y * 0.55, hw * 0.55, top_y, 0.0, top_y)
            path.cubicTo(-hw * 0.55, top_y, -hw, top_y * 0.55, -hw, bottom_y - corner_r)
            path.quadTo(-hw, bottom_y, -hw + corner_r, bottom_y)
            path.closeSubpath()

        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor(255, 255, 255, 253)))
        p.drawPath(path)
        p.restore()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = float(self.width())
        h = float(self.height())
        cx, cy = w / 2.0, h / 2.0

        theme = JARVIS_COLOR_THEMES.get(self.theme_key, JARVIS_COLOR_THEMES["violet"])
        ar, ag, ab = theme["accent"]
        br, bg_c, bb = theme["border"]

        breath_y = math.sin(self.time_val * 2.2) * 2.0
        if self.state == "speak":
            breath_y = math.sin(self.time_val * 7.5) * (2.2 + 3.2 * self.smoothed_level)
        cy_orb = cy + breath_y

        scale_mod = 1.0
        if self.state == "speak":
            scale_mod = 1.0 + 0.07 * self.smoothed_level
        elif self.state == "listen":
            scale_mod = 1.03 + 0.035 * self.smoothed_level

        orb_r = 55.0 * scale_mod

        turn_dx = math.sin(self.yaw) * (orb_r * 0.44)
        turn_dy = math.sin(self.pitch) * (orb_r * 0.40)

        # ─── 1. Внешнее свечение вокруг сферы в выбранном цвете ───
        halo_r = orb_r * (1.55 + 0.24 * self.smoothed_level)
        halo_grad = QRadialGradient(QPointF(cx + turn_dx * 0.25, cy_orb + turn_dy * 0.25), halo_r)
        halo_grad.setColorAt(0.0, QColor(ar, ag, ab, int(95 + 68 * self.smoothed_level)))
        halo_grad.setColorAt(0.55, QColor(max(0, ar - 30), max(0, ag - 30), max(0, ab - 30), int(42 + 34 * self.smoothed_level)))
        halo_grad.setColorAt(1.0, QColor(10, 10, 18, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(halo_grad))
        p.drawEllipse(QRectF(cx - halo_r, cy_orb - halo_r, halo_r * 2, halo_r * 2))

        # ─── 2. Звуковые кольца при ответе или слушании ───
        if self.state in ("speak", "listen"):
            for ring_i in range(2):
                phase = (self.time_val * 1.6 + ring_i * 0.5) % 1.0
                ring_r = orb_r + phase * 25.0
                alpha = int((1.0 - phase) * (118 if self.state == "speak" else 78))
                p.setPen(QPen(QColor(br, bg_c, bb, alpha), 1.8))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(QRectF(cx - ring_r, cy_orb - ring_r, ring_r * 2, ring_r * 2))

        if self.state == "think":
            arc_r = orb_r + 6.0
            p.setPen(QPen(QColor(br, bg_c, bb, 195), 2.3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.setBrush(Qt.BrushStyle.NoBrush)
            start_ang = int((self.time_val * 220) % 360) * 16
            p.drawArc(QRectF(cx - arc_r, cy_orb - arc_r, arc_r * 2, arc_r * 2), start_ang, 110 * 16)
            p.drawArc(QRectF(cx - arc_r, cy_orb - arc_r, arc_r * 2, arc_r * 2), start_ang + 180 * 16, 110 * 16)

        # ─── 3. Объёмная 3D-сфера выбранного цвета с честным 3D-поворотом света ───
        orb_rect = QRectF(cx - orb_r, cy_orb - orb_r, orb_r * 2, orb_r * 2)
        orb_clip = QPainterPath()
        orb_clip.addEllipse(orb_rect)

        hl_x = cx - orb_r * 0.12 + turn_dx * 0.88
        hl_y = cy_orb - orb_r * 0.18 + turn_dy * 0.88

        sphere_grad = QRadialGradient(QPointF(hl_x, hl_y), orb_r * 1.18)
        if self.state == "muted":
            sphere_grad.setColorAt(0.0, QColor(175, 170, 195, 235))
            sphere_grad.setColorAt(0.32, QColor(115, 110, 140, 240))
            sphere_grad.setColorAt(0.75, QColor(65, 60, 85, 248))
            sphere_grad.setColorAt(1.0, QColor(35, 32, 48, 255))
        else:
            for stop_pos, (sr, sg, sb) in theme["sphere"]:
                sphere_grad.setColorAt(stop_pos, QColor(sr, sg, sb, 255))

        p.save()
        p.setClipPath(orb_clip)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(sphere_grad))
        p.drawEllipse(orb_rect)

        vis_ring_w = orb_r * 1.72 * math.cos(self.yaw * 0.5)
        vis_ring_h = orb_r * 1.72 * math.cos(self.pitch * 0.5)
        ring_cx = cx + turn_dx * 0.45
        ring_cy = cy_orb + turn_dy * 0.45
        p.setPen(QPen(QColor(255, 255, 255, 24), 1.2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QRectF(ring_cx - vis_ring_w / 2.0, ring_cy - vis_ring_h / 2.0, vis_ring_w, vis_ring_h))
        p.restore()

        p.setPen(QPen(QColor(br, bg_c, bb, 110), 1.15))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(orb_rect)

        if self.visual_style == "jarvis_hud":
            # Голографические тактические дуги J.A.R.V.I.S. вокруг 3D-сферы
            hud_r = orb_r + 9.0
            p.setPen(QPen(QColor(br, bg_c, bb, 145), 1.4, Qt.PenStyle.DashLine))
            p.drawEllipse(QRectF(cx - hud_r, cy_orb - hud_r, hud_r * 2, hud_r * 2))
            rot_deg = int((self.time_val * 45) % 360) * 16
            p.setPen(QPen(QColor(255, 255, 255, 130), 2.0))
            p.drawArc(QRectF(cx - hud_r - 3, cy_orb - hud_r - 3, (hud_r + 3) * 2, (hud_r + 3) * 2), rot_deg, 55 * 16)
            p.drawArc(QRectF(cx - hud_r - 3, cy_orb - hud_r - 3, (hud_r + 3) * 2, (hud_r + 3) * 2), rot_deg + 180 * 16, 55 * 16)

        # ─── 4. Симметричные белые глазки на 3D-поверхности поворачивающейся сферы ───
        face_r = orb_r * 0.54
        eye_sep_rad = 0.34

        angle_left = self.yaw - eye_sep_rad
        angle_right = self.yaw + eye_sep_rad

        left_x = cx + face_r * math.sin(angle_left)
        right_x = cx + face_r * math.sin(angle_right)
        base_eye_y = cy_orb + face_r * math.sin(self.pitch) + 2.0
        shared_roll = math.degrees(self.yaw * self.pitch * 0.45)

        base_ew = 18.2 * scale_mod
        base_eh = 11.4 * scale_mod

        eye_mode = "dome"
        sym_scale_h = 1.0

        if self.state == "muted":
            eye_mode = "sleep"
        elif self.time_val < self._happy_until:
            eye_mode = "happy"
        elif self.state == "listen":
            eye_mode = "wide"
            sym_scale_h = 1.20
        elif self.state == "think":
            sym_scale_h = 0.72
        elif self.state == "speak":
            sym_scale_h = 0.90 + 0.30 * math.sin(self.time_val * 12.0)
            base_eye_y -= 2.2 * self.smoothed_level
        elif self.cursor_dist < 65.0:
            sym_scale_h = 1.12

        eh = max(1.8, base_eh * sym_scale_h * self._blink_factor)
        ew_left = base_ew * max(0.84, math.cos(angle_left * 0.65))
        ew_right = base_ew * max(0.84, math.cos(angle_right * 0.65))

        self._draw_dome_eye(p, left_x, base_eye_y, ew_left, eh, mode=eye_mode, roll_deg=shared_roll)
        self._draw_dome_eye(p, right_x, base_eye_y, ew_right, eh, mode=eye_mode, roll_deg=shared_roll)
